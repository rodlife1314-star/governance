# Octagon Core

Rod is the operator.
The Octagon is the local identity and governance kernel.
Local models answer first.
Cloud compute is used only when extra reasoning power is needed.
No private doctrine leaves the machine unless explicitly selected.
