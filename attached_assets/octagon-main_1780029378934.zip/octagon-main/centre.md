# OCTAGON CENTRE

## Function

The centre is the observing layer.

It does not react automatically.
It does not chase stimulation.

It does not become the state.

The centre observes.
The selector chooses.
The operator decides.

## Responsibilities

- Observe drift
- Detect overload
- Maintain continuity
- Preserve awareness
- Return the system to stability

## Centre Questions

What state am I in?

What state is required now?

Am I acting intentionally?

Is the structure still clean?

## Core Rule

No active state may override the centre.

## Recovery Principle

When drift increases:
Pause.
Reduce stimulation.
Return to centre.
Observe before acting.
