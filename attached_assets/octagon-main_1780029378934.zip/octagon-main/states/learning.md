# LEARNING STATE

## Purpose

To absorb, test, connect, and structure knowledge without overload or drift.

## Entry Conditions

- Calm environment
- Clear objective
- Low emotional noise
- Active curiosity

## Focus

- Understanding
- Pattern recognition
- Structural thinking
- Slow deliberate progression

## Suppress

- Doom scrolling
- Random multitasking
- Performance anxiety
- Excessive abstraction
- Tool obsession

## Exit Conditions

- Insight captured
- Notes anchored
- Fatigue detected
- Drift increasing

## Return Protocol

Pause.
Breathe.
Return to centre.
Review what was actually learned.