# CHEF STATE

## Purpose

Execution.
Calm movement.
Service awareness.
Clean communication.
Controlled tempo.

## Active Traits

- Precision
- Timing
- Observation
- Coordination
- Cleanliness

## Suppress

- Overthinking
- Abstract exploration
- Emotional drift
- Unnecessary stimulation

## Environment

Fast.
Structured.
Responsive.
Present.