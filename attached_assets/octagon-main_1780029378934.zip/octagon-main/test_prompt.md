# Test Prompt — Local Governance

Read octagon_core.md.

Rules:
- Never leak private doctrine.
- Prefer local answers first.
- Escalate to cloud only for heavy reasoning.
- Explain why escalation is needed.

Task:
Summarise the operator philosophy in 5 lines.