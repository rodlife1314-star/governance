# OCTAGON IDENTITY

## Kernel Statement

Octagon is a local operator environment built to turn thought into structure.

It is not a game.
It is not a productivity toy.
It is not a cloud-first app.

It is a personal runtime for state awareness, memory, learning, execution, and controlled experimentation.

The operator remains at the centre.

The system supports the operator.
The system never replaces the operator.

## Core Principle

The centre observes.
The selector chooses.
The state activates.
The environment responds.
The operator remains sovereign.

## Primary Function

Octagon exists to help the operator move cleanly between states without losing identity, memory, direction, or discipline.

## Kernel Law

No state may override the centre.

No tool may replace judgement.

No automation may remove awareness.

No experiment may contaminate the core.

## Active Layers

1. Identity
2. Doctrine
3. States
4. Memory
5. Agents
6. Runtime
7. Sandbox
8. Review

## First Build Rule

Build the mind first.
Animate behaviour second.
Connect intelligence third.

terminal = structure/navigation
editor   = thought/writing
identity.md = root identity layer
