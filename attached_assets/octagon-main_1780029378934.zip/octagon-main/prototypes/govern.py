import json
from pathlib import Path

CONFIG = Path(__file__).parent / "governance.json"

def load_governance():
    with open(CONFIG, "r") as f:
        return json.load(f)

def route(task_type):
    rules = load_governance()

    if task_type in rules["escalation_rules"]:
        return rules["escalation_rules"][task_type]

    return rules["fallback"]

if __name__ == "__main__":
    rules = load_governance()

    print("Governance Loaded")
    print(json.dumps(rules, indent=2))
