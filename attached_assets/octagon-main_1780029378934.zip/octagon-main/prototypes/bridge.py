from govern import route


def process_request(task_type):
    destination = route(task_type)

    print(f"Routing to: {destination}")

    return destination


if __name__ == "__main__":
    task = input("Task Type: ")
    process_request(task)