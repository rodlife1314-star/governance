from pathlib import Path

CORE_MEMORY = Path("../memory/octagon_core.md")

def read_core():
    if CORE_MEMORY.exists():
        return CORE_MEMORY.read_text(encoding="utf-8")
    return "No core memory found."

if __name__ == "__main__":
    print("=== OCTAGON CORE ===")
    print(read_core())