# OCTAGON RUNTIME — OLLAMA CLOUD COMPUTE

## Purpose

Ollama cloud is the external compute bridge.

It allows the Octagon laptop to send selected inference tasks beyond the local machine while keeping authority local.

## Runtime Law

Ollama may process.

Ollama may respond.

Ollama may assist.

Ollama may not overwrite the kernel.

## Model Route

Primary cloud test model:

glm-5.1:cloud

Command:

ollama run glm-5.1:cloud

## Routing Logic

User thought → Local laptop → Ollama cloud → Returned response → Octagon review

The cloud is the edge.

The laptop is the kernel.

Rod is the authority.

## No-Drift Gate

Before any cloud output becomes permanent, it must pass:

1. Centre check
2. Doctrine check
3. Identity check
4. 95/5 check
5. No-drift check