# OCTAGON REVIEW

## Function

Review is the return layer.

It prevents action from becoming drift.

The operator reviews what happened, what changed, what was learned, and whether the centre remained intact.

## Review Questions

What state was active?

Was the state entered intentionally?

What was completed?

What drift appeared?

What was learned?

What must be carried forward?

What must be released?

## Reflection Law

Reflection is not rumination.

Reflection extracts learning.
Rumination repeats noise.

## Completion Check

Before closing a session, confirm:

- Current state
- Completed action
- Saved work
- Drift level
- Next clean step

## Return Line

Observe.
Extract.
Save.
Release.
Return to centre.
