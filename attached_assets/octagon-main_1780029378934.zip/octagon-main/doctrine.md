
# OCTAGON DOCTRINE

## Centre Law

The operator remains at the centre at all times.

No state, tool, automation, workflow, or agent may override conscious awareness.

## Drift Law

If structure and thought diverge, pause.

Return to centre before continuing.

## Simplicity Law

Complexity must justify existence.

If a structure does not increase clarity, stability, continuity, or capability, it should not exist.

## Sandbox Law

The sandbox exists for controlled experimentation.

Failure is permitted inside the sandbox.

Contamination of the kernel is not permitted.

## Runtime Law

Every active state must have:
- purpose
- entry condition
- focus
- suppression rule
- exit condition

## Continuity Law

The environment must preserve memory without depending on emotional state.

## Awareness Law

The operator must know:
- current state
- current objective
- current level of drift

## Suppression Law

Not every thought requires execution.

## Clean Architecture Law

Every folder, file, state, and process must justify existence.

## Return Law

After execution, return to centre.