# OCTAGON KERNEL — EDGE LOGIC

## The 95 / 5 Law

95% of the system remains stable:
- identity
- doctrine
- state memory
- operating laws
- repeatable behaviours
- protected centre

5% remains adaptive:
- ambiguity
- emergence
- sandbox thought
- external compute
- experiment
- unknown pattern recognition

The 5% Edge does not replace the centre.
It protects the centre by allowing controlled adaptation.

## Quasicrystal Principle

Order does not have to repeat to be stable.

The Octagon can contain non-repeating patterns without becoming chaotic.

This means:
- novelty is allowed
- exploration is allowed
- external intelligence is allowed
- but authority remains local

## Edge Rule

The Edge may observe, test, query, and reflect.

The Edge may not overwrite:
- identity
- doctrine
- centre
- operator authority

All external outputs must return through the Centre before becoming law.