# OCTAGON KERNEL — EXTERNAL COMPUTE LAYER

## Definition

External compute is any intelligence or processing outside the local laptop.

Examples:
- Ollama cloud models
- AI Studio
- APIs
- remote GPUs
- cloud inference
- external agents

## Authority Law

External compute is not the operator.

External compute is not the centre.

External compute is an auxiliary reasoning layer.

It may assist with:
- heavy inference
- pattern expansion
- code generation
- summarisation
- simulation
- research
- comparison

It may not define:
- identity
- doctrine
- final judgement
- moral authority
- operator state

## Routing Logic

Local laptop = kernel / centre / memory / authority

External compute = edge / acceleration / expansion

Human operator = final decision point

## Return Law

Every external output must return to the local Octagon kernel for review.

Nothing becomes permanent until it passes:
1. Centre check
2. Doctrine check
3. Identity check
4. No-drift check