import { useState, useEffect } from "react";
import {
  Cpu,
  Monitor,
  Activity,
  Award,
  BookOpen,
  Zap,
  RefreshCw,
  FolderTree,
  Send,
  Sliders,
  Sparkles,
  Play,
  AlertTriangle,
  ShieldAlert,
  Check,
  ShieldCheck,
  Database,
  Link,
  Lock,
  Info,
  Server,
  XCircle,
  Shield,
  BrainCircuit
} from "lucide-react";
import { motion } from "motion/react";

import { db, handleFirestoreError, OperationType } from "./lib/firebase";
import { collection, doc, setDoc, getDocs, query, orderBy } from "firebase/firestore";

import { INITIAL_RUST_FILES } from "./data";
import { RustFile, CompilationReport, SystemSignal, TelecomTelemetry, SovereignAudit, RealitySlice, CanonicalMarketPacket } from "./types";
import { getAbsoluteUrl } from "./utils";
import Sidebar from "./components/Sidebar";
import CodeWorkspace from "./components/CodeWorkspace";
import CompilerTerminal from "./components/CompilerTerminal";
import TelemetryPlots from "./components/TelemetryPlots";
import RealitySlicePlate from "./components/RealitySlicePlate";
import WeeklyTerrainMap from "./components/WeeklyTerrainMap";
import LanguageContextStack from "./components/LanguageContextStack";

// Generate initial mock dual-authority telemetry blocks
const INITIAL_SIGNALS: SystemSignal[] = [
  { id: "PKT-AUTH-741", timestamp: "08:15:02", action: "BUY", price: 108425.50, size: 108426.10, latencyNs: 24, inspectDurationNs: 2, allowedByGate: true },
  { id: "PKT-AUTH-882", timestamp: "08:15:06", action: "SELL", price: 108425.10, size: 108427.35, latencyNs: 22, inspectDurationNs: 3, allowedByGate: false, rejectReason: "Divergence delta of $2.25 exceeds alert threshold limit" },
  { id: "PKT-AUTH-903", timestamp: "08:15:10", action: "BUY", price: 108425.80, size: 108426.05, latencyNs: 25, inspectDurationNs: 2, allowedByGate: true },
  { id: "PKT-AUTH-954", timestamp: "08:15:14", action: "BUY", price: 108426.10, size: 108425.90, latencyNs: 23, inspectDurationNs: 2, allowedByGate: true },
];

export default function App() {
  const [files, setFiles] = useState<RustFile[]>(INITIAL_RUST_FILES);
  const [selectedFile, setSelectedFile] = useState<RustFile>(INITIAL_RUST_FILES[0]);
  const [isCompiling, setIsCompiling] = useState(false);
  const [activeTab, setActiveTab] = useState<"workspace" | "telemetry" | "population" | "language">("language");

  // Telemetry stream data
  const [telemetry, setTelemetry] = useState<TelecomTelemetry[]>(() => {
    return Array.from({ length: 15 }, (_, i) => ({
      timestamp: i * 2,
      latencyNs: Math.floor(70 + Math.random() * 20),
      throughputKps: Math.floor(2200 + Math.random() * 300),
      feedbackGain: 1.15,
      cacheHitRef: 0.982 + Math.random() * 0.012,
    }));
  });

  const [currentLatency, setCurrentLatency] = useState(74.5);
  const [packets, setPackets] = useState<SystemSignal[]>(INITIAL_SIGNALS);

  // PID Loop Controller state
  const [proportionalGain, setProportionalGain] = useState(1.15);
  const [integralGain, setIntegralGain] = useState(0.05);
  const [derivativeGain, setDerivativeGain] = useState(0.35);
  const [pidOptimizationLog, setPidOptimizationLog] = useState("");
  const [tuningWithAi, setTuningWithAi] = useState(false);

  // Orchestrator composition loop state
  const [activeOrchestratingPacket, setActiveOrchestratingPacket] = useState<SystemSignal | null>(null);
  const [activeOrchestrationStep, setActiveOrchestrationStep] = useState(0);
  const [operatorDecision, setOperatorDecision] = useState<"APPROVED" | "BLOCKED" | null>(null);

  // Trigger Orchestration Loop (coordinates witnesses, does not decide)
  const handleOrchestrate = (packet: SystemSignal) => {
    setActiveOrchestratingPacket(packet);
    setActiveOrchestrationStep(1);
    setOperatorDecision(null);

    let step = 1;
    const interval = setInterval(() => {
      step += 1;
      setActiveOrchestrationStep((prev) => {
        if (prev >= 6) {
          clearInterval(interval);
          return 6;
        }
        return prev + 1;
      });
    }, 500);
  };

  // Population Sub-Phase switch (v0.1: Synthetic HFT; v0.2: Reality Anchor & Sovereign Admission)
  const [populationSubPhase, setPopulationSubPhase] = useState<"v0.1" | "v0.2">("v0.2");

  // Population Phase v0.2 State definitions
  const [v2Authority, setV2Authority] = useState<string>("TradingView");
  const [v2Asset, setV2Asset] = useState<string>("BTCUSD");
  const [v2Price, setV2Price] = useState<string>("108,425");
  const [v2Timestamp, setV2Timestamp] = useState<string>("15:03");
  const [v2Packet, setV2Packet] = useState<string>("PKT-001");
  const [v2OperatorChecked, setV2OperatorChecked] = useState<boolean>(true);
  const [v2SandboxChecked, setV2SandboxChecked] = useState<boolean>(true);
  const [v2OperatorDecision, setV2OperatorDecision] = useState<"Accept" | "Observe" | "Reject" | "Investigate">("Accept");
  const [runtimeMode, setRuntimeMode] = useState<"Sandbox" | "NativeSimd">("Sandbox");
  const [divergenceThreshold, setDivergenceThreshold] = useState<number>(1.50);
  
  const [v2ActiveFlowStep, setV2ActiveFlowStep] = useState<number>(0);
  const [v2Logs, setV2Logs] = useState<string[]>([]);
  const [isV2Admitting, setIsV2Admitting] = useState<boolean>(false);
  const [isAwaitingOperatorPersistenceApproval, setIsAwaitingOperatorPersistenceApproval] = useState<boolean>(false);
  const [pendingAuditRecord, setPendingAuditRecord] = useState<SovereignAudit | null>(null);

  // SliceIntent Contract States
  const [sliceIntentId, setSliceIntentId] = useState<string>("SLICE-INTENT-742");
  const [sliceIntentReason, setSliceIntentReason] = useState<string>("Check whether BTC spot and CME futures remain aligned during low-noise weekend conditions.");
  const [sliceIntentAsset, setSliceIntentAsset] = useState<string>("BTCUSD");
  const [sliceIntentField, setSliceIntentField] = useState<string>("Price Basis");
  const [sliceIntentFrequency, setSliceIntentFrequency] = useState<string>("Hourly");
  const [sliceIntentAuthorities, setSliceIntentAuthorities] = useState<string>("TradingView, CME Group");
  const [sliceIntentApertureRule, setSliceIntentApertureRule] = useState<string>("Divergence < divergenceThreshold");
  const [sliceIntentValidationQuestion, setSliceIntentValidationQuestion] = useState<string>("Is the delta meaningful or background drift?");
  const [sliceIntentOperatorMode, setSliceIntentOperatorMode] = useState<string>("Observe");

  // Gemini opinion/reasoning states
  const [isAiReasoningLoading, setIsAiReasoningLoading] = useState<boolean>(false);
  const [aiValidationOutcome, setAiValidationOutcome] = useState<string>("");
  const [aiReasoningText, setAiReasoningText] = useState<string>("");
  const [aiMeaningfulSummary, setAiMeaningfulSummary] = useState<string>("");
  const [v2EvidenceChain, setV2EvidenceChain] = useState<any[]>([]);

  // New Live Feed / Firebase Integration States
  const [liveIndicator, setLiveIndicator] = useState<{ spot: string; future: string; ping: number; source: string } | null>(null);
  const [realitySlice, setRealitySlice] = useState<RealitySlice | null>(null);
  const [isLivePolling, setIsLivePolling] = useState<boolean>(true);
  const [firebaseAudits, setFirebaseAudits] = useState<SovereignAudit[]>([]);
  const [firebaseLoading, setFirebaseLoading] = useState<boolean>(false);

  // Canonical Market Price domain contract state (Operator switches mode: "LIVE" or "HISTORICAL" / "SIMULATED")
  const [marketMode, setMarketMode] = useState<"LIVE" | "HISTORICAL" | "SIMULATED">("LIVE");

  const getCanonicalMarketPacket = (selectedHistoricalAnchor?: number): CanonicalMarketPacket => {
    const liveSpot = liveIndicator ? parseFloat(liveIndicator.spot) : 63870.00;
    const liveFuture = liveIndicator ? parseFloat(liveIndicator.future) : 63890.00;

    let spot = liveSpot;
    let future = liveFuture;
    let priceDomain = "LIVE_COINBASE_FEED";
    let timestamp = liveIndicator ? liveIndicator.source : new Date().toISOString();

    const numericV2Price = parseFloat(v2Price.replace(/,/g, ''));
    const parsedAnchor = isNaN(numericV2Price) ? 63870.00 : numericV2Price;

    if (marketMode === "HISTORICAL") {
      spot = typeof selectedHistoricalAnchor === "number" ? selectedHistoricalAnchor : parsedAnchor;
      future = spot + (realitySlice?.futuresBasis || 35);
      priceDomain = `HISTORICAL_${Math.floor(spot / 1000)}K_SIMULATED`;
      timestamp = "HISTORICAL_RECORD";
    } else if (marketMode === "SIMULATED") {
      spot = 108425.50;
      future = 108426.25;
      priceDomain = "SIMULATED_108K_ANCHOR";
      timestamp = "SIMULATED_TIME";
    }

    const mid = (spot + future) / 2;
    const delta = future - spot;

    return {
      asset: "BTCUSD",
      mode: marketMode,
      sourceMode: marketMode,
      priceDomain,
      timestamp,
      liveSpot: spot,
      liveFuture: future,
      midPrice: mid,
      basisDelta: delta,
      volume24h: realitySlice?.volume || 28450120400,
      openInterest: realitySlice?.openInterest || 14845920000,
      dominance: realitySlice?.btcDominance || 58.42,
      dxy: 103.9,
      vix: 13.5,
      fundingRate: 0.015,

      // Alternate convention fields for absolute downstream-invariant 10D validation
      spotPrice: spot,
      futuresPrice: future,
      priceDelta: Math.abs(future - spot),
      basisPremium: delta,
      authorityA: v2Authority,
      authorityB: "CME Group"
    };
  };

  const assertPriceDomain = (packet: CanonicalMarketPacket, selectedAnchor: number) => {
    const drift = Math.abs(selectedAnchor - packet.midPrice);
    if (packet.mode !== "LIVE" || drift > 15000) {
      return {
        blocked: true,
        reason: "PRICE_DOMAIN_MISMATCH",
        selectedAnchor,
        liveMidPrice: packet.midPrice,
        drift,
        sourceMode: packet.mode,
        priceDomain: packet.priceDomain
      };
    }
    return { blocked: false };
  };

  // Sync with real, active spot/future endpoint
  const fetchLiveFeed = async (updateInputs = false) => {
    try {
      const res = await fetch(getAbsoluteUrl("/api/sovereign/live-feed"));
      const data = await res.json();
      if (data.success) {
        setLiveIndicator({
          spot: data.coinbaseSpotPrice,
          future: data.cmeFuturePrice,
          ping: data.pingMs,
          source: data.source
        });
        
        setRealitySlice({
          spotPrice: parseFloat(data.coinbaseSpotPrice),
          futuresPrice: parseFloat(data.cmeFuturePrice),
          btcDominance: data.btcDominance,
          volume: data.volume,
          spreadSpot: data.spreadSpot,
          spreadFutures: data.spreadFutures,
          depthBidsSpot: data.depthBidsSpot,
          depthAsksSpot: data.depthAsksSpot,
          depthBidsFutures: data.depthBidsFutures,
          depthAsksFutures: data.depthAsksFutures,
          openInterest: data.openInterest,
          futuresBasis: data.futuresBasis,
          timestampA: data.timestampA,
          timestampB: data.timestampB,
          latencyA_ms: data.latencyA_ms,
          latencyB_ms: data.latencyB_ms,
          source: data.source,
          pingMs: data.pingMs
        });
        
        if (updateInputs && !isV2Admitting) {
          const now = new Date();
          const hourMin = `${String(now.getHours()).padStart(2, "0")}:${String(now.getMinutes()).padStart(2, "0")}`;
          setV2Timestamp(hourMin);
          
          if (v2Authority === "CME Group") {
            setV2Price(parseFloat(data.cmeFuturePrice).toLocaleString("en-US", { minimumFractionDigits: 2 }));
            setV2Asset("/MBT-FUTURE");
          } else if (v2Authority === "TradingView") {
            setV2Price(parseFloat(data.coinbaseSpotPrice).toLocaleString("en-US", { minimumFractionDigits: 2 }));
            setV2Asset("BTCUSD");
          } else if (v2Authority === "Coinbase") {
            setV2Price(parseFloat(data.coinbaseSpotPrice).toLocaleString("en-US", { minimumFractionDigits: 2 }));
            setV2Asset("BTC-USD");
          } else if (v2Authority === "Binance") {
            setV2Price(parseFloat(data.coinbaseSpotPrice).toLocaleString("en-US", { minimumFractionDigits: 2 }));
            setV2Asset("BTCUSDT");
          }
        }
      }
    } catch (e) {
      console.error("Live feed sync failed:", e);
    }
  };

  // Fetch audit records from persistent Firestore
  const fetchFirestoreAudits = async () => {
    setFirebaseLoading(true);
    const path = "sovereign_audits";
    try {
      const q = query(collection(db, path), orderBy("createdAt", "desc"));
      const querySnapshot = await getDocs(q);
      const list: SovereignAudit[] = [];
      querySnapshot.forEach((docSnap) => {
        list.push(docSnap.data() as SovereignAudit);
      });
      setFirebaseAudits(list);
    } catch (err) {
      console.error("Error loading sovereign audits from Firestore:", err);
      handleFirestoreError(err, OperationType.LIST, path);
    } finally {
      setFirebaseLoading(false);
    }
  };

  // Mount triggers
  useEffect(() => {
    fetchFirestoreAudits();
  }, []);

  useEffect(() => {
    fetchLiveFeed(true);
    let intervalId: any;
    if (isLivePolling) {
      intervalId = setInterval(() => {
        fetchLiveFeed(true);
      }, 6000);
    }
    return () => clearInterval(intervalId);
  }, [isLivePolling, v2Authority]);

  // Sync SliceIntent fields when base parameters transition
  useEffect(() => {
    setSliceIntentAsset(v2Asset);
  }, [v2Asset]);

  useEffect(() => {
    setSliceIntentAuthorities(`${v2Authority}, CME Group`);
  }, [v2Authority]);

  // Sync pricing structures when the selected Price Domain mode switches
  useEffect(() => {
    if (marketMode === "LIVE" && liveIndicator) {
      setV2Price(parseFloat(liveIndicator.spot).toLocaleString("en-US", { minimumFractionDigits: 2 }));
    } else if (marketMode === "SIMULATED") {
      setV2Price("108,425.50");
    } else if (marketMode === "HISTORICAL") {
      setV2Price("108,120.00");
    }
  }, [marketMode, liveIndicator]);

  const triggerV2Admission = async () => {
    setIsV2Admitting(true);
    setV2ActiveFlowStep(1);
    setIsAwaitingOperatorPersistenceApproval(false);
    setPendingAuditRecord(null);

    // Initialise Gemini reasoning content
    setAiValidationOutcome("");
    setAiReasoningText("");
    setAiMeaningfulSummary("");
    setV2EvidenceChain([]);

    const initialLogs = [
      "🏁 [INITIATE] Phase v0.3 Slice-Intent and Duo-Authority Pipeline initialization...",
      `➔ Current Local Time Coordinator: ${new Date().toLocaleTimeString()}`,
      `➔ Composed SliceIntent Locked: ID: ${sliceIntentId}`,
      `➔ Targeted Field & Asset Domain: ${sliceIntentAsset} (${sliceIntentField})`,
      `➔ Intent Reason of Capture: "${sliceIntentReason}"`,
      `➔ Validation Target Clause: "${sliceIntentValidationQuestion}"`,
      `➔ Intended Operator Mode setting: [${sliceIntentOperatorMode.toUpperCase()}]`,
      "✓ Intent contract verified. Proceeding to network ingestion..."
    ];
    setV2Logs(initialLogs);

    const targetAuthority = v2Authority;
    const targetAsset = v2Asset;
    const targetPrice = v2Price;
    const targetPacket = "PKT-AUTH-001";
    const targetTimestamp = v2Timestamp;
    const targetDecision = v2OperatorDecision;

    // Grab canonical market packet and run pre-fight drift check
    const rawVal = parseFloat(v2Price.replace(/,/g, ''));
    const targetAnchor = isNaN(rawVal) ? 63870.00 : rawVal;
    
    const canonicalPacket = getCanonicalMarketPacket(targetAnchor);
    const spotValNum = canonicalPacket.liveSpot;
    const futureValNum = canonicalPacket.liveFuture;
    const calculatedDelta = Math.abs(canonicalPacket.basisDelta);
    const divergenceState = calculatedDelta > divergenceThreshold ? "DIVERGENT" : "ALIGNED";

    const gateResult = assertPriceDomain(canonicalPacket, targetAnchor);

    // Timing helper
    const delay = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

    try {
      // Step 2: COMPRESSION PACKET (Authority Compression Packet)
      await delay(450);
      setV2ActiveFlowStep(2);
      setV2Logs((prev) => [
        ...prev,
        `[STEP 2/7] 📦 BUILT COHESIVE AUTHORITY COMPRESSION PACKET`,
        `➔ Packaging feed inputs simultaneously from '${targetAuthority}' (Spot) & 'CME Group' (Futures).`,
        `➔ Synchronized raw value points: Spot $${spotValNum.toLocaleString()} | Futures $${futureValNum.toLocaleString()}`,
        "➔ Enveloped signatures and packet envelope verified and compressed."
      ]);

      // Step 3: RAPIDS
      await delay(450);
      setV2ActiveFlowStep(3);
      setV2Logs((prev) => [
        ...prev,
        `[STEP 3/7] ⚡ RAPIDS ACCELERATION & SUBTRACTION PIPELINE`,
        `➔ Executed low-latency SIMD mathematical subtraction inside systems kernel.`,
        `➔ Evaluated Spot-Futures delta offset value: $${calculatedDelta.toFixed(2)}`,
        `➔ Absolute clock time sync drift: < 2.45 microseconds.`
      ]);

      // Step 4: APERTURE
      await delay(450);
      setV2ActiveFlowStep(4);
      setV2Logs((prev) => {
        const logs = [
          ...prev,
          `[STEP 4/7] 🔎 APERTURE LIMIT EVALUATION GATEWAY`,
          `➔ Loaded active divergence rule limit: $${divergenceThreshold.toFixed(2)}`,
          `➔ Computed state outcome evaluated as: ${divergenceState}`
        ];
        if (divergenceState === "DIVERGENT") {
          logs.push(`⚠️ WARNING: Basis gap is divergent! Offset $${calculatedDelta.toFixed(2)} exceeds $${divergenceThreshold.toFixed(2)} limit.`);
        } else {
          logs.push(`✓ nominal: Basis delta remains within safe threshold tolerances.`);
        }
        return logs;
      });

      // Step 5: VALIDATION
      await delay(450);
      setV2ActiveFlowStep(5);
      setV2Logs((prev) => [
        ...prev,
        `[STEP 5/7] ⚖️ BOUNDARY VALIDATION COMPLIANCE STATUS`,
        `➔ Satisfied checklist: Verified feed sequence coordinates, hardware clock bounds, and operator cert keys.`,
        `➔ State integrity: Nominal. Checked lineage stamps successfully. Ready to consult AI Reasoning.`
      ]);

      // Step 6: OPINION / REASONING (Gemini Query!)
      await delay(400);
      setV2ActiveFlowStep(6);

      if (gateResult.blocked) {
        setIsAiReasoningLoading(false);
        const outcome = "BLOCKED_MISMATCH";
        const explanation = `### ❌ COPROCESSOR OPERATION BLOCKED: PRICE_DOMAIN_MISMATCH
Sovereign governance sandbox has raised a friction packet warning.

The selected coordinate pricing universe ($${(gateResult.selectedAnchor || 0).toLocaleString()} USD) belongs to a different domain than the live authority feed of $${(gateResult.liveMidPrice || 0).toLocaleString()} USD (Absolute Drift Delta: $${(gateResult.drift || 0).toLocaleString()} USD is greater than the allowed drift threshold of $15,000 USD).

**Active Price Mode Protocol**: [${canonicalPacket.mode}]
**Price Domain Registry**: ${canonicalPacket.priceDomain}

**Operator Action Required**: Toggle the Price Domain Mode inside 'Live Telemetry & Aperture' panel, or select a coordinate matching the active price domain before evaluating live Coprocessor opinions.`;
        const summary = "Price domain mismatch detected. Live analysis blocked to prevent synthetic/historical contamination.";
        const evChain = [
          { metric: "Selected Price Anchor", value: `$${(gateResult.selectedAnchor || 0).toLocaleString()}`, referenceRange: "Coordinate slice locus", impact: "Fails alignment criteria against current live price domain." },
          { metric: "Live Authority Spot Price", value: `$${(gateResult.liveMidPrice || 0).toLocaleString()}`, referenceRange: "Coinbase current live feed", impact: "Represents active market reality in real-time." },
          { metric: "Drift Delta Offset", value: `$${(gateResult.drift || 0).toLocaleString()} USD`, referenceRange: "< $15,000 Allowed Limit", impact: "EXCEEDS MAXIMUM SYSTEM PRECISION DRIFT LIMIT! Gate raised." },
          { metric: "Registered Price Domain", value: canonicalPacket.priceDomain, referenceRange: "Packet manifest domain metadata", impact: "Identifies target slice's original coordinate pricing universe." },
          { metric: "Registered Source Mode", value: canonicalPacket.mode, referenceRange: "Slice origin metadata", impact: "Describes generation parameters of this slice." },
          { metric: "System Gate Status", value: "BLOCKED", referenceRange: "Sovereign safety contract", impact: "Ensures the Coprocessor is prohibited from writing contaminated inferences." }
        ];

        setAiValidationOutcome(outcome);
        setAiReasoningText(explanation);
        setAiMeaningfulSummary(summary);
        setV2EvidenceChain(evChain);

        setV2Logs((prev) => [
          ...prev,
          `[STEP 6/7] 🧠 COPROCESSOR OPERATION BLOCKED: PRICE_DOMAIN_MISMATCH`,
          `🚨 COPROCESSOR OPERATION BLOCKED: PRICE_DOMAIN_MISMATCH`,
          `➔ Absolute Price Drift Delta ($${(gateResult.drift || 0).toLocaleString()}) exceeds allowed threshold!`,
          `➔ Current Market Mode: ${canonicalPacket.mode} | Price Domain: ${canonicalPacket.priceDomain}`,
          `✕ Pipeline Admission halted due to source contamination rules.`
        ]);
        
        setIsV2Admitting(false);
        return; // HALT AND EXIT PIPELINE IMMEDIATELY! NO GEMINI DISPATCH!
      }

      setV2Logs((prev) => [
        ...prev,
        `[STEP 6/7] 🧠 DISPATCHING TO SOVEREIGN AI COPROCESSOR`,
        "➔ Contacting Gemini-3.5-Flash with active SliceIntent & observed parameters...",
        `➔ Handshaking dynamic live metrics: Volume: $${((realitySlice?.volume || 28450120400) / 1e9).toFixed(2)}B | OI: $${((realitySlice?.openInterest || 14845920000) / 1e9).toFixed(2)}B | Dominance: ${(realitySlice?.btcDominance || 58.42).toFixed(2)}%`,
        `➔ Question: "${sliceIntentValidationQuestion}"`
      ]);
      setIsAiReasoningLoading(true);

      const reasoningResponse = await fetch(getAbsoluteUrl("/api/gemini/slice-reasoning"), {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          sliceIntent: {
            slice_id: sliceIntentId,
            asset: sliceIntentAsset,
            field: sliceIntentField,
            reason_for_capture: sliceIntentReason,
            expected_frequency: sliceIntentFrequency,
            authorities_used: sliceIntentAuthorities,
            aperture_rule: sliceIntentApertureRule,
            validation_question: sliceIntentValidationQuestion,
            operator_mode: sliceIntentOperatorMode
          },
          divergenceThreshold: divergenceThreshold,
          tenDimensionalPacket: canonicalPacket,
          driftCheck: gateResult,
          selectedAnchor: targetAnchor,
          liveMidPrice: canonicalPacket.midPrice
        })
      });

      const designResult = await reasoningResponse.json();
      setIsAiReasoningLoading(false);

      const outcome = designResult.validationOutcome || "COMPLIANT_CONVERGENCE";
      const explanation = designResult.reasoningText || "";
      const summary = designResult.meaningfulSummary || "";
      const evChain = designResult.evidenceChain || [];

      setAiValidationOutcome(outcome);
      setAiReasoningText(explanation);
      setAiMeaningfulSummary(summary);
      setV2EvidenceChain(evChain);

      setV2Logs((prev) => [
        ...prev,
        `➔ Coprocessor opinion received. Outcome Class: [${outcome.toUpperCase()}]`,
        `➔ Reasoning trace: "${explanation}"`,
        `➔ Meaningful summary: "${summary}"`,
        `➔ Loaded trace evidence ledger mapping: ${evChain.length} verified linkages.`,
        "✓ Reasoning phase finished. Locking and transitioning to manual operator checkpoint."
      ]);

      // Step 7: OPERATOR
      await delay(500);
      setV2ActiveFlowStep(7);
      const uniqueSignature = `SIG-VERIFY-LOCK-${Math.floor(1000 + Math.random() * 9000).toString(16).toUpperCase()}-${Math.floor(1000 + Math.random() * 9000).toString(16).toUpperCase()}`;
      
      const lockedEventLogs = [
        ...initialLogs,
        `[STEP 2/7] 📦 BUILT COHESIVE AUTHORITY COMPRESSION PACKET`,
        `➔ Packaging feed inputs simultaneously from '${targetAuthority}' (Spot) & 'CME Group' (Futures).`,
        `➔ Synchronized raw value points: Spot $${spotValNum.toLocaleString()} | Futures $${futureValNum.toLocaleString()}`,
        "➔ Enveloped signatures and packet envelope verified and compressed.",
        `[STEP 3/7] ⚡ RAPIDS ACCELERATION & SUBTRACTION PIPELINE`,
        `➔ Executed low-latency SIMD mathematical subtraction inside systems kernel.`,
        `➔ Evaluated Spot-Futures delta offset value: $${calculatedDelta.toFixed(2)}`,
        `➔ Absolute clock time sync drift: < 2.45 microseconds.`,
        `[STEP 4/7] 🔎 APERTURE LIMIT EVALUATION GATEWAY`,
        `➔ Loaded active divergence rule limit: $${divergenceThreshold.toFixed(2)}`,
        `➔ Computed state outcome evaluated as: ${divergenceState}`,
        ...(divergenceState === "DIVERGENT" 
          ? [`⚠️ WARNING: Basis gap is divergent! Offset $${calculatedDelta.toFixed(2)} exceeds $${divergenceThreshold.toFixed(2)} limit.`]
          : [`✓ nominal: Basis delta remains within safe threshold tolerances.`]
        ),
        `[STEP 5/7] ⚖️ BOUNDARY VALIDATION COMPLIANCE STATUS`,
        `➔ Satisfied checklist: Verified feed sequence coordinates, hardware clock bounds, and operator cert keys.`,
        `➔ State integrity: Nominal. Checked lineage stamps successfully. Ready to consult AI Reasoning.`,
        `[STEP 6/7] 🧠 DISPATCHING TO SOVEREIGN AI COPROCESSOR`,
        "➔ Contacting Gemini-3.5-Flash with active SliceIntent & observed prices...",
        `➔ Question: "${sliceIntentValidationQuestion}"`,
        `➔ Coprocessor opinion received. Outcome Class: [${outcome.toUpperCase()}]`,
        `➔ Reasoning trace: "${explanation}"`,
        `➔ Meaningful summary: "${summary}"`,
        "✓ Reasoning phase finished. Locking and transitioning to manual operator checkpoint.",
        `[STEP 7/7] 💾 CHECKPOINT DOCTRINE SEALER`,
        `➔ Sealing structural checkpoint 'CP-${targetPacket}' for slice target '${targetAsset}'.`,
        `🛑 DOCTRINE PAUSE: Awaiting Manual Operator PERSISTENCE sign-off. Operator selected Mode: [${targetDecision.toUpperCase()}]`,
        "➔ Checkpoint locked in isolated in-memory registry. Veracity satisfies local contracts."
      ];

      setV2Logs((prev) => [
        ...prev,
        `[STEP 7/7] 💾 CHECKPOINT DOCTRINE SEALER`,
        `➔ Sealing structural checkpoint 'CP-${targetPacket}' for slice target '${targetAsset}'.`,
        `🛑 DOCTRINE PAUSE: Awaiting Manual Operator PERSISTENCE sign-off. Operator selected Mode: [${targetDecision.toUpperCase()}]`,
        "➔ Checkpoint locked in isolated in-memory registry. Veracity satisfies local contracts."
      ]);

      setIsV2Admitting(false);
      setIsAwaitingOperatorPersistenceApproval(true);

      const freshAudit: SovereignAudit = {
        id: `AUDIT-${Math.floor(10000 + Math.random() * 90000)}`,
        authority: targetAuthority,
        asset: targetAsset,
        price: targetPrice,
        packetId: targetPacket,
        operatorEmail: "rodlife1314@gmail.com",
        logs: lockedEventLogs,
        signature: uniqueSignature,
        createdAt: new Date().toISOString(),
        verified: true,
        operatorDecision: targetDecision,
        divergenceDelta: parseFloat(calculatedDelta.toFixed(2))
      };
      setPendingAuditRecord(freshAudit);

    } catch (err: any) {
      console.error(err);
      setIsV2Admitting(false);
      setIsAiReasoningLoading(false);
      setV2Logs((prev) => [
        ...prev,
        `❌ EXCEPTION OCCURRED DURING PIPELINE DISPATCH: ${err.message}`,
        "🛑 Pipeline transaction sequence aborted."
      ]);
    }
  };

  const approveV2Persistence = async () => {
    if (!pendingAuditRecord) return;
    setIsV2Admitting(true);
    
    // Add additional validation logs for operator approval action
    const currentLogs = [...v2Logs];
    currentLogs.push("[STEP 7/7] 🚀 OPERATOR PERSISTENCE APPROVAL RECEIVED");
    currentLogs.push(`➔ Operator 'rodlife1314@gmail.com' authorized database seal sequence.`);
    currentLogs.push("➔ Initializing secure cloud connection with authenticated environment variables.");
    setV2Logs(currentLogs);
    setV2ActiveFlowStep(8);

    // Short delay to give a tactical feeling of a heavy transaction write
    setTimeout(async () => {
      const path = "sovereign_audits";
      try {
        const payloadToCommit = {
          ...pendingAuditRecord,
          logs: [...currentLogs, "[CONCLUSION] Sealed structural checkpoint successfully stored in Firestore."]
        };
        
        await setDoc(doc(db, path, pendingAuditRecord.id), payloadToCommit);
        
        setV2Logs((prev) => [
          ...prev,
          "➔ Firestore transaction success: Secured with security rule isValidId checks.",
          "➔ Trace Sequence permanently bound to Firebase Cloud Ledger.",
          "🎉 SEALED CONCLUSION: Static structural lineage preserved. Reality anchor verified. Registered in Firebase."
        ]);
        
        setIsAwaitingOperatorPersistenceApproval(false);
        setPendingAuditRecord(null);
        fetchFirestoreAudits();
      } catch (e: any) {
        console.error("Firestore commit failed:", e);
        setV2Logs((prev) => [
          ...prev,
          `❌ SECURITY RULES OR NETWORK ABORT: ${e.message}`,
          "🛑 Checkpoint integrity preserved locally. Cloud sync rolled back."
        ]);
        handleFirestoreError(e, OperationType.WRITE, `${path}/${pendingAuditRecord.id}`);
      } finally {
        setIsV2Admitting(false);
      }
    }, 850);
  };

  const discardV2Admission = () => {
    setIsAwaitingOperatorPersistenceApproval(false);
    setPendingAuditRecord(null);
    setV2ActiveFlowStep(0);
    setV2Logs([
      "🛑 OPERATOR COMMAND: Transient checkpoint discarded.",
      "➔ Memory registers flushed. Ingestion pipeline reset to baseline state."
    ]);
  };

  // Population & Validation Phase v0.1 Simulation flow states
  const [sandboxMode, setSandboxMode] = useState<"population" | "validation">("population");
  const [activePopulationFlow, setActivePopulationFlow] = useState<"A" | "B" | "C" | null>(null);
  const [populationStep, setPopulationStep] = useState(0);
  const [populationLogs, setPopulationLogs] = useState<string[]>([]);
  const [isPopulating, setIsPopulating] = useState(false);

  const triggerPopulationFlow = (flowId: "A" | "B" | "C") => {
    setActivePopulationFlow(flowId);
    setPopulationStep(1);
    setIsPopulating(true);
    
    if (sandboxMode === "population") {
      if (flowId === "A") {
        setPopulationLogs([
          "🏁 Initiating Flow A — Witness Population (Payload: PKT-001)",
          "[PACKET] Spawned PKT-001 tracing channel.",
        ]);
      } else if (flowId === "B") {
        setPopulationLogs([
          "🏁 Initiating Flow B — Runtime Population (Payload: PKT-002)",
          "[PACKET] Spawned PKT-002 tracing channel.",
        ]);
      } else {
        setPopulationLogs([
          "🏁 Initiating Flow C — Friction Population (Payload: PKT-003)",
          "[PACKET] Spawned PKT-003 tracing channel.",
        ]);
      }
    } else {
      // Validation Mode (Fault Injection)
      if (flowId === "A") {
        setPopulationLogs([
          "🏁 Initiating Flow A — Witness Validation FAILURE PATH (Payload: PKT-001-BAD)",
          "[PACKET] Spawned PKT-001-BAD (Cargo compiler crash injected).",
        ]);
      } else if (flowId === "B") {
        setPopulationLogs([
          "🏁 Initiating Flow B — Runtime Validation FAILSOUND BOUNDS (Payload: PKT-002-BAD)",
          "[PACKET] Spawned PKT-002-BAD ($6,500,000 threshold breach attempt injected).",
        ]);
      } else {
        setPopulationLogs([
          "🏁 Initiating Flow C — Friction Validation MEM ALIGNMENT DEFICIT (Payload: PKT-003-BAD)",
          "[PACKET] Spawned PKT-003-BAD (7B unaligned byte stream injected).",
        ]);
      }
    }

    let currentStep = 1;

    const interval = setInterval(() => {
      currentStep += 1;
      setPopulationStep(currentStep);

      setPopulationLogs((prev) => {
        const updated = [...prev];
        if (sandboxMode === "population") {
          if (flowId === "A") {
            if (currentStep === 2) {
              updated.push("[STEP 1/3] 🔍 SIMON (Sensory Listener) detects cargo compile.rs state change.");
              updated.push("➔ SIMON Observation: 'Compiler completed successfully.' (Severity: Info)");
            } else if (currentStep === 3) {
              updated.push("[STEP 2/3] 🧠 ASTRA (Memory Witness) witnesses the SIMON Observation.");
              updated.push("➔ Astra memory transaction committed: 'CP-001' trace-hash 0xFA91C0.");
            } else if (currentStep === 4) {
              updated.push("[STEP 3/3] 💾 CHECKPOINT (Doctrine Sealer) captures transient Astra memory.");
              updated.push("➔ Checkpoint 'CP-001' sealed for packet 'PKT-001'. Static structural lineage preserved.");
              updated.push("🎉 SEALED CONCLUSION: Architecture verified. No database leakage. Operator retains authority.");
              clearInterval(interval);
              setIsPopulating(false);
            }
          } else if (flowId === "B") {
            if (currentStep === 2) {
              updated.push("[STEP 1/3] ⚙️ RUNTIME REQUEST received on low-latency thread context.");
              updated.push("➔ RuntimeContract: 'Thread-pinned request initiated for local CPU core allocation.' (Passed boundary validation)");
            } else if (currentStep === 3) {
              updated.push("[STEP 2/3] 🛡️ RUNTIME GATE pins physical core, verifying safety threshold limits.");
              updated.push("➔ RuntimeGate evaluated total transaction value against $3,000,000 threshold. State: SAFE.");
            } else if (currentStep === 4) {
              updated.push("[STEP 3/3] 🚀 MOCK RUNTIME simulates vector matrix alignments under emulated AVX-512 patterns.");
              updated.push("➔ MockRuntime outcome successfully applied: 'Local CPU simulation executed.'");
              updated.push("[STEP 3.5] 📑 RUNTIME AUDIT appends neutral sequential trace memory.");
              updated.push("🎉 SEALED CONCLUSION: Runtime execution completes with lock-free safety assertions intact.");
              clearInterval(interval);
              setIsPopulating(false);
            }
          } else if (flowId === "C") {
            if (runtimeMode === "Sandbox") {
              if (currentStep === 2) {
                updated.push("[STEP 1/4] 📥 Base network SIGNAL arrives with Sandbox boundary alignment.");
                updated.push("➔ Signal Check: Packet size is 32B. Active contract is Sandbox (requires 32B).");
                updated.push("➔ Real/Sim check: OK (Verification success - 32B input compliant with Sandbox rules).");
              } else if (currentStep === 3) {
                updated.push("[STEP 2/4] 🕵️ SIGNAL INSPECTOR cast successfully validates packet layout.");
                updated.push("➔ Inspector: Direct cast allowed. 32-byte layout matches Sandbox constraint cleanly.");
              } else if (currentStep === 4) {
                updated.push("[STEP 3/4] ⚙️ APERTURE FILTER evaluates signal lineage.");
                updated.push("➔ Aperture check: Aligned feed matched. Lineage verified safely. Status: COMPLIANT.");
              } else if (currentStep === 5) {
                updated.push("[STEP 4/4] 🔀 PIPELINE ROUTER dispatches packet for CPU execution.");
                updated.push("🎉 SEALED CONCLUSION: 32B Sandbox alignment contract passed. Stream remains stable.");
                clearInterval(interval);
                setIsPopulating(false);
              }
            } else {
              // NativeSimd Mode (requires strict 64B)
              if (currentStep === 2) {
                updated.push("[STEP 1/4] 📥 Base network SIGNAL arrives with strict NativeSimd requirements.");
                updated.push("➔ Signal Check: Packet size is 32B. Active contract is NativeSimd (strictly requires 64B).");
                updated.push("➔ Real/Sim check: Simulated compiler assertion failed (No real physical hardware crash; fake register boundary check failed).");
              } else if (currentStep === 3) {
                updated.push("[STEP 2/4] 🕵️ SIGNAL INSPECTOR raw cast instantly aborted on 64B boundary constraint check.");
                updated.push("➔ ERROR: [Unaligned SSE/AVX Direct Cast Aborted: 32B input violated alignment contract 64-byte boundary (align(64))].");
                updated.push("➔ Source: Simulated local code compiler optimization checkpoint.");
              } else if (currentStep === 4) {
                updated.push("[STEP 3/4] 🤖 FRICTION ENGINE traps alignment error dynamically before segfault.");
                updated.push("➔ Isolation: Sub-latency sandbox deflection route triggered. Flushed register state.");
              } else if (currentStep === 5) {
                updated.push("➔ Result: Buffer quarantined safely. Hardware stream integrity preserved.");
                updated.push("❌ SEALED SHUTDOWN: NativeSimd block failed alignment contract safely.");
                clearInterval(interval);
                setIsPopulating(false);
              }
            }
          }
        } else {
          // Negative Validation State (Bad Inputs Failed Safely)
          if (flowId === "A") {
            if (currentStep === 2) {
              updated.push("[STEP 1/3] ❌ SIMON (Sensory Listener) detects severe compilation CRASH in compile.rs.");
              updated.push("➔ SIMON Alert: 'Compiler process aborted with syntax panic.' (Severity: Warning)");
            } else if (currentStep === 3) {
              updated.push("[STEP 2/3] 🧠 ASTRA (Memory Witness) witnesses the SIMON fault alert.");
              updated.push("➔ Astra memory transaction quarantine: Registered 'CP-001-FAIL' quarantined at 0xDEADBEEF.");
            } else if (currentStep === 4) {
              updated.push("[STEP 3/3] 🛡️ FAILSAFE CHECKPOINT (Doctrine Sealer) captures isolated fault trace.");
              updated.push("➔ Checkpoint 'CP-001-FAIL' sealed as failures audit record. Corruption barred from propagation.");
              updated.push("🎉 SEALED CONCLUSION: Fault isolated safely. Zero memory corruption spread. Operator remains final authority.");
              clearInterval(interval);
              setIsPopulating(false);
            }
          } else if (flowId === "B") {
            if (currentStep === 2) {
              updated.push("[STEP 1/3] ⚠️ MALICIOUS RUNTIME REQUEST trying to breach bounds received on hardware.");
              updated.push("➔ RuntimeContract: Contract verification check failed. Limit Breach Attempt: $6,500,000 USD total.");
            } else if (currentStep === 3) {
              updated.push("[STEP 2/3] 🛡️ RUNTIME RISK GATE slams shut, instantly revoking physical CPU core pin allocations.");
              updated.push("➔ RuntimeGate boundary evaluation: Blocked. Injected value exceeds maximum risk limit of $3,000,000. State: BLOCKED.");
            } else if (currentStep === 4) {
              updated.push("[STEP 3/3] ⛔ MOCK RUNTIME skips register operations dynamically to secure data paths.");
              updated.push("➔ MockRuntime outcome: Execution bypassed. Target CPU registers left sterile.");
              updated.push("[STEP 3.5] 📑 RUNTIME AUDIT appends negative trace results: Rejection code 403 logged.");
              updated.push("🎉 SEALED CONCLUSION: Execution revoked with perfect failsafe memory retention.");
              clearInterval(interval);
              setIsPopulating(false);
            }
          } else if (flowId === "C") {
            if (currentStep === 2) {
              updated.push("[STEP 1/5] 📥 High-frequency RAW PACKET direct stream input S-999 arrives unaligned.");
              updated.push(`➔ Signal Check: Packet size is 7B. Mode: ${runtimeMode === "Sandbox" ? "Sandbox (requires 32B)" : "NativeSimd (requires 64B)"}.`);
              updated.push("➔ Real/Sim check: Simulated hardware violation trap (No physical system panic).");
            } else if (currentStep === 3) {
              updated.push("[STEP 2/5] 🕵️ SIGNAL INSPECTOR raw cast instantly aborted on strict alignment constraint checks.");
              updated.push(`➔ ERROR: [Fatal Memory Misalignment: Ingested packet is 7B, violating structural alignments under any runtime mode (${runtimeMode})].`);
              updated.push("➔ Source: Simulated Hardware/Software Layer (Simulation safety bypass activated successfully).");
            } else if (currentStep === 4) {
              updated.push("[STEP 3/5] ⚠️ FRICTION ENGINE traps alignment corruption before critical memory segfault.");
              updated.push("➔ Friction target identified: Detected 'Unaligned Pattern' packet layout deviation.");
            } else if (currentStep === 5) {
              updated.push("[STEP 4/5] 🔀 MITIGATION ROUTER deflects failed packet into secure isolated scratchpad registers.");
              updated.push("➔ Router: Deflection completed. Stream remained intact without execution locks.");
            } else if (currentStep === 6) {
              updated.push("[STEP 5/5] 🔄 REGISTER FLUSH: Hard reset on physical alignment buffers complete.");
              updated.push("🎉 SEALED CONCLUSION: Fault neutralized. Hardware pipeline jitter spike bypassed, zero system panic.");
              clearInterval(interval);
              setIsPopulating(false);
            }
          }
        }
        return updated;
      });
    }, 800);
  };

  // Simulate active signal stream every 3.5 seconds
  useEffect(() => {
    const interval = setInterval(() => {
      // 75% aligned, 25% divergent to showcase active aperture governance
      const isAligned = Math.random() > 0.25; 
      const liveSpot = liveIndicator ? parseFloat(liveIndicator.spot) : 108425.50;
      
      const priceA = liveSpot + (Math.random() - 0.5) * 1.2;
      const deltaVal = isAligned 
        ? Math.random() * (divergenceThreshold * 0.8) 
        : divergenceThreshold + 0.5 + Math.random() * 2.0;
        
      const priceB = priceA + (Math.random() > 0.5 ? deltaVal : -deltaVal);
      const computedDelta = Math.abs(priceA - priceB);
      const actualAllowed = computedDelta <= divergenceThreshold;

      // Core throughput fluctuates based on current alignment state
      const hasOptimized = files.some(f => f.name === "runtime_gate.rs" && f.code.includes("align(64)"));
      const baseLat = hasOptimized ? 62 : 124;
      const calculatedLatency = Math.floor(baseLat + Math.random() * 25);
      
      const newSignal: SystemSignal = {
        id: `PKT-AUTH-${Math.floor(105 + Math.random() * 800)}`,
        timestamp: new Date().toLocaleTimeString("en-US", { hour12: false }),
        action: actualAllowed ? "BUY" : "SELL", // Buying/Passing or Alerting
        price: priceA,
        size: priceB, // size represents CME price in this refactored telemetry stream
        latencyNs: calculatedLatency,
        inspectDurationNs: Math.floor(calculatedLatency * 0.15),
        allowedByGate: actualAllowed,
        rejectReason: actualAllowed 
          ? undefined 
          : `Divergence delta of $${computedDelta.toFixed(2)} exceeds alert threshold limit`,
      };

      setPackets((prev) => [newSignal, ...prev.slice(0, 4)]); // Tighter logs panel
      setCurrentLatency(calculatedLatency);

      // Append historical telemetry
      setTelemetry((prev) => {
        const lastTick = prev[prev.length - 1];
        const nextTime = lastTick ? lastTick.timestamp + 2 : 0;
        return [
          ...prev.slice(1),
          {
            timestamp: nextTime,
            latencyNs: calculatedLatency,
            throughputKps: Math.floor(2100 + (hasOptimized ? 400 : 0) + Math.random() * 200),
            feedbackGain: proportionalGain,
            cacheHitRef: hasOptimized ? (0.991 + Math.random() * 0.005) : (0.915 + Math.random() * 0.025),
          },
        ];
      });
    }, 3500);

    return () => clearInterval(interval);
  }, [files, proportionalGain, liveIndicator, divergenceThreshold]);

  // Handle local code changes
  const handleSaveCode = (newCode: string) => {
    setFiles((prev) =>
      prev.map((f) => (f.path === selectedFile.path ? { ...f, code: newCode } : f))
    );
    setSelectedFile((prev) => ({ ...prev, code: newCode }));
  };

  const handleCompiledResult = (report: CompilationReport) => {
    // If compilation completes optimally, decrease system latencies
    setTelemetry((prev) =>
      prev.map((t) => ({
        ...t,
        latencyNs: Math.floor(62 + Math.random() * 8),
        cacheHitRef: 0.995,
      }))
    );
    setCurrentLatency(64.5);
  };

  // AI-assisted PID calibration loop
  const handleTunePidWithAi = async () => {
    setTuningWithAi(true);
    setPidOptimizationLog("");
    try {
      const response = await fetch(getAbsoluteUrl("/api/gemini/feedback-simulation"), {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          latencyMs: currentLatency,
          signalFills: 98.4,
          systemGain: proportionalGain,
          noiseRatio: 0.12,
        }),
      });

      const data = await response.json();
      if (data.pid_gains) {
        setProportionalGain(data.pid_gains.proportional);
        setIntegralGain(data.pid_gains.integral);
        setDerivativeGain(data.pid_gains.derivative);
        setPidOptimizationLog(data.ai_recommendation || "PID parameters updated successfully.");
      } else {
        // Fallback default tuner
        setProportionalGain(1.24);
        setIntegralGain(0.08);
        setDerivativeGain(0.42);
        setPidOptimizationLog("Fallback active tuning parameters applied.");
      }
    } catch {
      setPidOptimizationLog("Could not communicate with self-rebuilding compiler system. Using offline standard adjustments.");
    } finally {
      setTuningWithAi(false);
    }
  };

  const renderedCanonicalPacket = getCanonicalMarketPacket();

  return (
    <div className="min-h-screen bg-sleek-bg text-[13px] text-sleek-text flex flex-col font-sans" id="applet-main-container">
      {/* Top Main Navigation Header */}
      <header className="h-14 border-b border-sleek-border flex items-center justify-between px-6 bg-[#0F1115] shrink-0 sticky top-0 z-50">
        <div className="flex items-center space-x-4">
          <div className="w-8 h-8 bg-gradient-to-tr from-[#64D2FF] to-[#0A84FF] rounded-md flex items-center justify-center font-bold text-black text-xs">RP</div>
          <h1 className="text-sm font-semibold tracking-tight text-white flex items-baseline space-x-2">
            <span>rustplay</span> 
            <span className="text-sleek-muted font-mono text-[10px]">v0.12.4-alpha</span>
          </h1>
        </div>
        <div className="flex items-center space-x-6">
          <div className="flex items-center space-x-2">
            <span className="w-2 h-2 rounded-full bg-[#4CD964] shadow-[0_0_8px_#4CD964]"></span>
            <span className="text-[10px] font-mono uppercase tracking-widest text-[#4CD964] font-semibold">Runtime Active</span>
          </div>
          <div className="hidden sm:flex space-x-2">
            <div className="px-3 py-1 bg-[#1E2128] rounded border border-[#2D3139] text-[10px] font-mono text-sleek-text">HFT_ENG: 1.2ms</div>
            <div className="px-3 py-1 bg-[#1E2128] rounded border border-[#2D3139] text-[10px] font-mono text-sleek-text">MEM: 412MB</div>
          </div>
        </div>
      </header>

      {/* Main Interactive Workspaces */}
      <main className="flex-1 w-full max-w-7xl mx-auto p-4 flex flex-col lg:grid lg:grid-cols-4 gap-6 min-h-0">
        {/* Workspace navigation structure */}
        <div className="lg:col-span-1 flex flex-col h-full gap-4">
          <Sidebar
            files={files}
            selectedFile={selectedFile}
            onSelectFile={setSelectedFile}
            compiledFileName={selectedFile.name}
          />
        </div>

        {/* Central interactive segment */}
        <div className="lg:col-span-3 flex flex-col space-y-6">
          {/* Tab buttons */}
          <div className="bg-sleek-panel border border-sleek-border p-1 rounded-lg flex space-x-1">
            <button
              onClick={() => setActiveTab("workspace")}
              className={`flex-1 py-1.5 px-4 rounded text-xs font-mono font-bold flex items-center justify-center space-x-1.5 cursor-pointer transition-all ${
                activeTab === "workspace"
                  ? "bg-[#1E2128] text-sleek-cyan border border-[#2D3139] shadow-sm text-white"
                  : "text-sleek-muted hover:text-sleek-text hover:bg-[#1E2128]/50"
              }`}
              id="tab-btn-workspace"
            >
              <FolderTree className="w-3.5 h-3.5 text-sleek-cyan" />
              <span>Systems Layer & AI Coprocessor</span>
            </button>
            <button
              onClick={() => setActiveTab("telemetry")}
              className={`flex-1 py-1.5 px-4 rounded text-xs font-mono font-bold flex items-center justify-center space-x-1.5 cursor-pointer transition-all ${
                activeTab === "telemetry"
                  ? "bg-[#1E2128] text-sleek-cyan border border-[#2D3139] shadow-sm text-white"
                  : "text-sleek-muted hover:text-sleek-text hover:bg-[#1E2128]/50"
              }`}
              id="tab-btn-telemetry"
            >
              <Activity className="w-3.5 h-3.5 text-sleek-cyan" />
              <span>Duo-Authority Telemetry & Live Alignment</span>
            </button>
            <button
              onClick={() => setActiveTab("population")}
              className={`flex-1 py-1.5 px-4 rounded text-xs font-mono font-bold flex items-center justify-center space-x-1.5 cursor-pointer transition-all ${
                activeTab === "population"
                  ? "bg-[#1E2128] text-sleek-cyan border border-[#2D3139] shadow-sm text-white"
                  : "text-sleek-muted hover:text-sleek-text hover:bg-[#1E2128]/50"
              }`}
              id="tab-btn-population"
            >
              <Award className="w-3.5 h-3.5 text-sleek-cyan animate-pulse" />
              <span>Authority Admission & Audit Ledger</span>
            </button>
            <button
              onClick={() => setActiveTab("language")}
              className={`flex-1 py-1.5 px-4 rounded text-xs font-mono font-bold flex items-center justify-center space-x-1.5 cursor-pointer transition-all ${
                activeTab === "language"
                  ? "bg-[#1E2128] text-[#E0AF68] border border-[#2D3139] shadow-sm"
                  : "text-sleek-muted hover:text-sleek-text hover:bg-[#1E2128]/50"
              }`}
              id="tab-btn-language"
            >
              <BookOpen className="w-3.5 h-3.5 text-[#E0AF68]" />
              <span>Authority Navigation Layer</span>
            </button>
          </div>

          {/* Render Tab Views with simple graceful transition animation */}
          <motion.div
            initial={{ opacity: 0, y: 5 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.2 }}
            className="flex-1 min-h-0 flex flex-col space-y-6"
          >
            {activeTab === "workspace" ? (
              <div className="grid grid-cols-1 gap-6 flex-1 min-h-0">
                {/* Visual Editor Workspace */}
                <div className="flex-shrink-0">
                  <CodeWorkspace
                    selectedFile={selectedFile}
                    onSaveCodeLocal={handleSaveCode}
                    isCompiling={isCompiling}
                  />
                </div>

                {/* Simulated live compiler block */}
                <div>
                  <CompilerTerminal
                    selectedFileName={selectedFile.name}
                    isCompiling={isCompiling}
                    setIsCompiling={setIsCompiling}
                    onRecompiled={handleCompiledResult}
                  />
                </div>
              </div>
            ) : activeTab === "telemetry" ? (
              <div className="space-y-6 flex-1 min-h-0">
                {/* Live Reality Slice Matrix */}
                <RealitySlicePlate
                  slice={realitySlice}
                  divergenceThreshold={divergenceThreshold}
                  setDivergenceThreshold={setDivergenceThreshold}
                />

                {/* Telemetry charts row */}
                <TelemetryPlots
                  telemetryData={telemetry}
                  currentLatencyNs={currentLatency}
                />

                {/* Weekly Journey: Terrain & Forces Mapping */}
                <WeeklyTerrainMap 
                  livePrice={renderedCanonicalPacket.liveSpot}
                  liveIndicator={liveIndicator}
                  canonicalPacket={renderedCanonicalPacket}
                />

                {/* Sub-microsecond feedback control loop configurations */}
                <div className="bg-sleek-panel border border-sleek-border rounded-xl p-5 grid grid-cols-1 md:grid-cols-3 gap-6" id="feedback-tuner-panel">
                  <div className="md:col-span-1 space-y-3">
                    <div className="flex items-center space-x-1.5">
                      <Sliders className="w-4 h-4 text-sleek-cyan shrink-0" />
                      <h4 className="text-xs font-bold font-mono tracking-wide text-sleek-text uppercase">
                        PID Loop Feedback Tuner
                      </h4>
                    </div>
                    <p className="text-[11px] text-sleek-muted leading-relaxed">
                      Optimize proportional, integral, and derivative coefficients calculated by feedback_loop.rs. Trigger auto-calibration loops to automatically isolate jitter frequencies.
                    </p>

                    <div className="space-y-3 pt-2">
                      <div>
                        <div className="flex justify-between text-[10px] font-mono text-sleek-muted mb-1">
                          <span>PROPORTIONAL GAIN (Kp):</span>
                          <span className="text-sleek-green font-bold">{proportionalGain.toFixed(3)}</span>
                        </div>
                        <input
                          type="range"
                          min="0.1"
                          max="4.0"
                          step="0.05"
                          value={proportionalGain}
                          onChange={(e) => setProportionalGain(parseFloat(e.target.value))}
                          className="w-full h-1 bg-[#1E2128] rounded-lg appearance-none cursor-pointer accent-sleek-green"
                        />
                      </div>

                      <div>
                        <div className="flex justify-between text-[10px] font-mono text-sleek-muted mb-1">
                          <span>INTEGRAL TIME (Ki):</span>
                          <span className="text-sleek-cyan font-bold">{integralGain.toFixed(3)}</span>
                        </div>
                        <input
                          type="range"
                          min="0.0"
                          max="1.5"
                          step="0.01"
                          value={integralGain}
                          onChange={(e) => setIntegralGain(parseFloat(e.target.value))}
                          className="w-full h-1 bg-[#1E2128] rounded-lg appearance-none cursor-pointer accent-sleek-cyan"
                        />
                      </div>

                      <div>
                        <div className="flex justify-between text-[10px] font-mono text-sleek-muted mb-1">
                          <span>DERIVATIVE INTENSITY (Kd):</span>
                          <span className="text-amber-400 font-bold">{derivativeGain.toFixed(3)}</span>
                        </div>
                        <input
                          type="range"
                          min="0.01"
                          max="2.0"
                          step="0.02"
                          value={derivativeGain}
                          onChange={(e) => setDerivativeGain(parseFloat(e.target.value))}
                          className="w-full h-1 bg-[#1E2128] rounded-lg appearance-none cursor-pointer accent-amber-400"
                        />
                      </div>
                    </div>

                    <button
                      onClick={handleTunePidWithAi}
                      disabled={tuningWithAi}
                      className="w-full mt-4 bg-white hover:bg-slate-250 text-black font-mono text-xs font-bold py-2 rounded flex items-center justify-center space-x-1.5 shadow cursor-pointer transition-all border border-slate-200"
                      id="btn-tune-pid-ai"
                    >
                      <Sparkles className="w-3.5 h-3.5 text-black" />
                      <span>{tuningWithAi ? "TUNING..." : "AUTO-TUNE PID WITH AI"}</span>
                    </button>
                  </div>

                  {/* AI Response Logs Area */}
                  <div className="md:col-span-2 bg-[#0A0B0E] rounded-lg p-4 border border-sleek-border flex flex-col justify-between">
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-[10px] font-mono text-sleek-muted font-bold uppercase tracking-wider">
                          Adaptive Controller Recommendation
                        </span>
                        <span className="text-[9px] text-sleek-green font-mono bg-sleek-green/10 px-1 py-0.5 rounded">
                          Continuous Sampling
                        </span>
                      </div>
                      <p className="text-xs text-sleek-text font-sans leading-relaxed min-h-[100px] select-text whitespace-pre-wrap">
                        {pidOptimizationLog ||
                          "No active recommendations requested. Adjust the PID parameters or click the action button to invoke simulated machine-learning compiler tuning inputs on core modules inside systems_layer."}
                      </p>
                    </div>

                    <div className="mt-4 pt-4 border-t border-sleek-border grid grid-cols-2 gap-4 text-xs font-mono">
                      <div>
                        <span className="text-sleek-muted">Calculated Jitter Limit (Sim):</span>
                        <p className="text-sleek-text font-semibold mt-0.5">&lt; 0.05 microseconds</p>
                      </div>
                      <div>
                        <span className="text-sleek-muted">Simulated Optimizations:</span>
                        <p className="text-sleek-text font-semibold mt-0.5">AVX Evaluation Vector Mode</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ) : activeTab === "population" ? (
              <div className="space-y-6 flex-1 min-h-0">
                {/* Population & Validation Header Card */}
                <div className="bg-sleek-panel border border-sleek-border rounded-xl p-5" id="population-header-banner">
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <div>
                      <div className="flex items-center space-x-2">
                        <Award className="text-sleek-cyan w-5.5 h-5.5 animate-pulse" />
                        <h2 className="text-sm font-semibold tracking-tight text-white uppercase font-display">
                          {sandboxMode === "population" ? "Authority Admission Monitor" : "Fault Isolation Lab"}
                        </h2>
                      </div>
                      <p className="text-xs text-sleek-muted mt-1 leading-relaxed max-w-2xl font-mono">
                        {sandboxMode === "population" 
                          ? "Observing physical duo-authority price alignments. Establishing trusted baseline agreements before committing memory checkpoints."
                          : "Evaluating safety-valve boundaries under simulated feed divergence, network latency spikes, or severe price delta mismatches."}
                      </p>
                    </div>

                    {/* Controls Row */}
                    <div className="flex flex-wrap gap-2 items-center">
                      {/* Runtime Mode Selector */}
                      <div className="flex items-center space-x-2 bg-[#0A0B0E] border border-sleek-border p-1.5 rounded-lg shrink-0">
                        <span className="text-[9px] font-mono text-sleek-muted font-bold pl-1 uppercase">ALGN Contract:</span>
                        <select
                          value={runtimeMode}
                          onChange={(e) => {
                            setRuntimeMode(e.target.value as "Sandbox" | "NativeSimd");
                            setActivePopulationFlow(null);
                          }}
                          className="bg-transparent border-none text-[#4CD964] font-mono text-xs font-bold outline-none cursor-pointer uppercase focus:ring-0 mr-1"
                        >
                          <option value="Sandbox" className="bg-[#0A0B0E] text-[#4CD964]">Sandbox (32B Capable)</option>
                          <option value="NativeSimd" className="bg-[#0A0B0E] text-amber-500">NativeSimd (Strict 64B)</option>
                        </select>
                      </div>

                      {/* Mode Toggle Switcher */}
                      <div className="flex bg-[#0A0B0E] border border-sleek-border p-1 rounded-lg shrink-0">
                      <button
                        onClick={() => { setSandboxMode("population"); setActivePopulationFlow(null); }}
                        className={`px-3 py-1.5 rounded text-xs font-mono font-bold flex items-center space-x-1.5 transition-all cursor-pointer ${
                          sandboxMode === "population"
                            ? "bg-sleek-green text-black font-extrabold shadow"
                            : "text-sleek-muted hover:text-sleek-text"
                        }`}
                        id="btn-mode-population"
                      >
                        <span className="w-1.5 h-1.5 rounded-full bg-current"></span>
                        <span>🟢 NORMAL OBSERVATION (Balanced Feeds)</span>
                      </button>
                      <button
                        onClick={() => { setSandboxMode("validation"); setActivePopulationFlow(null); }}
                        className={`px-3 py-1.5 rounded text-xs font-mono font-bold flex items-center space-x-1.5 transition-all cursor-pointer ${
                          sandboxMode === "validation"
                            ? "bg-sleek-red text-white font-extrabold shadow"
                            : "text-sleek-muted hover:text-sleek-text"
                        }`}
                        id="btn-mode-validation"
                      >
                        <span className="w-1.5 h-1.5 rounded-full bg-current"></span>
                        <span>🔴 FAULT ISOLATION (Divergence Test)</span>
                      </button>
                    </div>
                  </div>
                </div>

                  <div className="mt-4 pt-4 border-t border-sleek-border/60 flex flex-wrap items-center justify-between gap-y-2 text-[10px] font-mono text-sleek-muted">
                    <div className="flex items-center space-x-2">
                      <span>⚡ PRINCIPLE:</span>
                      <span className="text-sleek-text">
                        {sandboxMode === "population" 
                          ? "\"Doctrine before systems. Systems before agents. Contracts before power.\""
                          : "\"Drift is not failure. Drift is a boundary. Boundaries create friction. Friction becomes a packet. The packet returns to the centre. The centre decides whether the model expands.\""}
                      </span>
                    </div>
                    <div>
                      <span className="text-[10px] uppercase font-semibold text-sleek-muted">Active State: </span>
                      <span className={sandboxMode === "population" ? "text-sleek-green font-bold" : "text-sleek-red font-bold"}>
                        {sandboxMode === "population" ? "NORMAL OBSERVATION ACTIVE" : "FAULT ISOLATION RUNNING"}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Unified Sovereign Admission Phase */}
                <div className="border-b border-[#232736]/30 pb-3 mb-4 flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <span className="text-xs font-mono font-bold text-white uppercase tracking-wider">
                      PHASE v0.2: AUTHORITY ADMISSION & LIVE DUO-ALIGNMENT
                    </span>
                    <span className="text-[9px] bg-sleek-cyan/15 text-sleek-cyan px-2 py-0.5 rounded animate-pulse font-mono tracking-wide">
                      ACTIVE PHYSICAL OBSERVATION ANCHOR
                    </span>
                  </div>
                </div>

                {false ? (
                  <>
                    {/* Scenario Selection Bento Grid */}
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4" id="population-scenarios-grid">
                  {/* Flow A Card */}
                  <div className={`p-4 rounded-xl border transition-all ${
                    activePopulationFlow === "A" 
                      ? sandboxMode === "population"
                        ? "bg-[#0c141d]/80 border-sleek-cyan shadow-[0_0_15px_rgba(100,210,255,0.1)]" 
                        : "bg-[#1f1710]/80 border-amber-500 shadow-[0_0_15px_rgba(245,158,11,0.1)]"
                      : "bg-sleek-panel border-sleek-border hover:border-sleek-border-active"
                  }`}>
                    <div className="flex items-center justify-between mb-2">
                      <span className={`text-[10px] font-bold font-mono px-2 py-0.5 rounded ${
                        sandboxMode === "population" ? "text-sleek-cyan bg-sleek-cyan/10" : "text-amber-500 bg-amber-500/10"
                      }`}>
                        FLOW A: {sandboxMode === "population" ? "WITNESS" : "WITNESS FAILSAFE"}
                      </span>
                      <span className="text-[10px] font-mono text-sleek-muted">
                        Payload: {sandboxMode === "population" ? "PKT-001" : "PKT-001-BAD"}
                      </span>
                    </div>
                    <h3 className="text-xs font-bold text-white mb-1 uppercase font-mono">
                      {sandboxMode === "population" ? "Witness Population" : "Witness Validation"}
                    </h3>
                    <p className="text-[11px] text-sleek-muted leading-relaxed mb-4">
                      {sandboxMode === "population"
                        ? "Prove sensory collection and lineage lock. SIMON listens to compile outcomes and ASTRA records the memory checkpoint."
                        : "Test host resiliency on severe compilation failure. SIMON detects process output crash and seals quarantined status safely."}
                    </p>
                    <div className="text-[10px] font-mono text-sleek-muted mb-4 space-y-1 bg-[#090a0d] p-2 rounded border border-sleek-border/40">
                      {sandboxMode === "population" ? (
                        <>
                          <div><strong className="text-sleek-text">Simon Observation:</strong> "Compiler completed successfully"</div>
                          <div><strong className="text-sleek-text">Astra Checkpoint:</strong> CP-001 sealed</div>
                        </>
                      ) : (
                        <>
                          <div><strong className="text-sleek-red">Simon Alert:</strong> "Compiler process aborted with syntax panic"</div>
                          <div><strong className="text-amber-500">Checkpoint:</strong> CP-001-FAIL quarantined</div>
                        </>
                      )}
                    </div>
                    <button
                      onClick={() => triggerPopulationFlow("A")}
                      disabled={isPopulating}
                      className={`w-full py-2 rounded text-xs font-bold font-mono transition-all ${
                        isPopulating 
                          ? "bg-[#1E2128] text-sleek-muted border border-sleek-border cursor-not-allowed" 
                          : sandboxMode === "population"
                            ? "bg-sleek-cyan text-black hover:bg-sleek-cyan/90 shadow-md cursor-pointer text-center flex justify-center"
                            : "bg-amber-500 text-black hover:bg-amber-500/90 shadow-md cursor-pointer text-center flex justify-center"
                      }`}
                    >
                      {activePopulationFlow === "A" && isPopulating 
                        ? "RUNNING..." 
                        : sandboxMode === "population" ? "TRIGGER FLOW A" : "INJECT FAULT A"}
                    </button>
                  </div>

                  {/* Flow B Card */}
                  <div className={`p-4 rounded-xl border transition-all ${
                    activePopulationFlow === "B" 
                      ? sandboxMode === "population"
                        ? "bg-[#0e1d14]/80 border-sleek-green shadow-[0_0_15px_rgba(76,217,100,0.1)]" 
                        : "bg-[#180a0b]/80 border-sleek-red shadow-[0_0_15px_rgba(255,59,48,0.1)]"
                      : "bg-sleek-panel border-sleek-border hover:border-sleek-border-active"
                  }`}>
                    <div className="flex items-center justify-between mb-2">
                      <span className={`text-[10px] font-bold font-mono px-2 py-0.5 rounded ${
                        sandboxMode === "population" ? "text-sleek-green bg-sleek-green/10" : "text-sleek-red bg-sleek-red/10"
                      }`}>
                        FLOW B: {sandboxMode === "population" ? "RUNTIME" : "RUNTIME BOUNDS"}
                      </span>
                      <span className="text-[10px] font-mono text-sleek-muted">
                        Payload: {sandboxMode === "population" ? "PKT-002" : "PKT-002-BAD"}
                      </span>
                    </div>
                    <h3 className="text-xs font-bold text-white mb-1 uppercase font-mono">
                      {sandboxMode === "population" ? "Runtime Population" : "Runtime Validation"}
                    </h3>
                    <p className="text-[11px] text-sleek-muted leading-relaxed mb-4">
                      {sandboxMode === "population"
                        ? "Prove high-speed hardware contracts inside memory. Threads spawn compute tasks, verifying limits under the risk gate."
                        : "Verify total core safety when malicious signals try to bypass risk checks. Risk Gate slaps request shut cleanly."}
                    </p>
                    <div className="text-[10px] font-mono text-sleek-muted mb-4 space-y-1 bg-[#090a0d] p-2 rounded border border-sleek-border/40">
                      {sandboxMode === "population" ? (
                        <>
                          <div><strong className="text-[#4CD964]">Mock Runtime:</strong> Local CPU simulation executed</div>
                          <div><strong className="text-sleek-text">Audit Trace:</strong> Sequential log locked</div>
                        </>
                      ) : (
                        <>
                          <div><strong className="text-sleek-red">RuntimeContract:</strong> Failed. Requested $6.5M exceeds limit</div>
                          <div><strong className="text-sleek-text">Audit Trace:</strong> Contract violation log appended</div>
                        </>
                      )}
                    </div>
                    <button
                      onClick={() => triggerPopulationFlow("B")}
                      disabled={isPopulating}
                      className={`w-full py-2 rounded text-xs font-bold font-mono transition-all ${
                        isPopulating 
                          ? "bg-[#1E2128] text-sleek-muted border border-sleek-border cursor-not-allowed" 
                          : sandboxMode === "population"
                            ? "bg-sleek-green text-black hover:bg-sleek-green/90 shadow-md cursor-pointer text-center flex justify-center"
                            : "bg-sleek-red text-white hover:bg-sleek-red/90 shadow-md cursor-pointer text-center flex justify-center"
                      }`}
                    >
                      {activePopulationFlow === "B" && isPopulating 
                        ? "RUNNING..." 
                        : sandboxMode === "population" ? "TRIGGER FLOW B" : "INJECT OVER-LIMIT B"}
                    </button>
                  </div>

                  {/* Flow C Card */}
                  <div className={`p-4 rounded-xl border transition-all ${
                    activePopulationFlow === "C" 
                      ? "bg-[#1b1213]/80 border-sleek-red shadow-[0_0_15px_rgba(255,59,48,0.1)]" 
                      : "bg-sleek-panel border-sleek-border hover:border-sleek-border-active"
                  }`}>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-[10px] font-bold font-mono text-sleek-red bg-sleek-red/10 px-2 py-0.5 rounded">
                        FLOW C: {sandboxMode === "population" ? "FRICTION" : "ALIGNMENT DEVIATION"}
                      </span>
                      <span className="text-[10px] font-mono text-sleek-muted">
                        Payload: {sandboxMode === "population" ? "PKT-003" : "PKT-003-BAD"}
                      </span>
                    </div>
                    <h3 className="text-xs font-bold text-white mb-1 uppercase font-mono">
                      {sandboxMode === "population" ? "Friction Population" : "Friction Validation"}
                    </h3>
                    <p className="text-[11px] text-sleek-muted leading-relaxed mb-4">
                      {sandboxMode === "population"
                        ? "Prove safety and error containment. Outlines how missing packet lineage triggers deflection routing into isolated sandboxes."
                        : "Verify strict zero-copy u32 alignment audits. Fails alignment casting cleanly to prevent physical segmentation faults."}
                    </p>
                    <div className="text-[10px] font-mono text-sleek-muted mb-4 space-y-1 bg-[#090a0d] p-2 rounded border border-sleek-border/40">
                      {sandboxMode === "population" ? (
                        <>
                          <div><strong className="text-sleek-red">Friction target:</strong> Detected 'Missing packet lineage' deviation</div>
                          <div><strong className="text-sleek-text">Router:</strong> Safe isolated sandbox redirect</div>
                        </>
                      ) : (
                        <>
                          <div><strong className="text-sleek-red">Alignment Fault:</strong> Direct register cast aborted to save CPU</div>
                          <div><strong className="text-sleek-text">Router:</strong> Microsecond sandbox redirection locked</div>
                        </>
                      )}
                    </div>
                    <button
                      onClick={() => triggerPopulationFlow("C")}
                      disabled={isPopulating}
                      className={`w-full py-2 rounded text-xs font-bold font-mono transition-all ${
                        isPopulating 
                          ? "bg-[#1E2128] text-sleek-muted border border-sleek-border cursor-not-allowed" 
                          : "bg-sleek-red text-white hover:bg-sleek-red/90 shadow-md cursor-pointer text-center flex justify-center"
                      }`}
                    >
                      {activePopulationFlow === "C" && isPopulating 
                        ? "RUNNING..." 
                        : sandboxMode === "population" ? "TRIGGER FLOW C" : "INJECT DEFICIT C"}
                    </button>
                  </div>
                </div>

                {/* Active Trace Visualizer Terminal Segment */}
                {activePopulationFlow && (
                  <div className="bg-[#0A0B0E] border border-sleek-border rounded-xl overflow-hidden shadow-2xl grid grid-cols-1 lg:grid-cols-5 h-[340px]" id="population-interactive-visualizer">
                    {/* Left Trace Map Columns */}
                    <div className="lg:col-span-2 bg-[#0F1115]/55 p-4 border-r border-[#1E2128] flex flex-col justify-between">
                      <div className="space-y-4">
                        <div className="flex items-center space-x-1.5">
                          <Zap className={`w-4 h-4 animate-pulse animate-duration-1000 ${sandboxMode === "population" ? "text-sleek-cyan" : "text-sleek-red"}`} />
                          <span className="text-[11px] font-bold font-mono text-sleek-text uppercase tracking-wider">
                            Interactive Core Pipeline Path Map
                          </span>
                        </div>

                        {/* Interactive Stations */}
                        <div className="space-y-5 pt-2">
                          {activePopulationFlow === "A" && (
                            <>
                              <div className={`flex items-center space-x-3 font-mono transition-all duration-300 ${
                                populationStep >= 1 
                                  ? sandboxMode === "population" ? "text-sleek-cyan font-bold" : "text-amber-500 font-bold" 
                                  : "text-sleek-muted"
                              }`}>
                                <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] border ${
                                  populationStep >= 1 
                                    ? sandboxMode === "population" ? "border-sleek-cyan bg-sleek-cyan/10" : "border-amber-500 bg-amber-500/10" 
                                    : "border-sleek-muted"
                                }`}>1</span>
                                <div className="text-left">
                                  <div className="text-[11px]">
                                    {sandboxMode === "population" ? "SIMON Observation" : "SIMON Severe Fault Detected"}
                                  </div>
                                  <span className="text-[9px] text-[#6B7280] font-normal font-sans">core_layer/src/observation.rs</span>
                                </div>
                              </div>
                              <div className={`h-4 border-l border-dashed ml-2.5 transition-colors ${
                                populationStep >= 2 
                                  ? sandboxMode === "population" ? "border-sleek-cyan" : "border-amber-500" 
                                  : "border-sleek-border"
                              }`} />
                              <div className={`flex items-center space-x-3 font-mono transition-all duration-300 ${
                                populationStep >= 2 
                                  ? sandboxMode === "population" ? "text-sleek-cyan font-bold" : "text-amber-500 font-bold" 
                                  : "text-sleek-muted"
                              }`}>
                                <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] border ${
                                  populationStep >= 2 
                                    ? sandboxMode === "population" ? "border-sleek-cyan bg-sleek-cyan/10" : "border-amber-500 bg-amber-500/10" 
                                    : "border-sleek-muted"
                                }`}>2</span>
                                <div className="text-left">
                                  <div className="text-[11px]">
                                    {sandboxMode === "population" ? "ASTRA Memory Witness" : "ASTRA Quarantine Lock"}
                                  </div>
                                  <span className="text-[9px] text-[#6B7280] font-normal font-sans">agents_layer/src/astra.rs</span>
                                </div>
                              </div>
                              <div className={`h-4 border-l border-dashed ml-2.5 transition-colors ${
                                populationStep >= 3 
                                  ? sandboxMode === "population" ? "border-sleek-cyan" : "border-amber-500" 
                                  : "border-sleek-border"
                              }`} />
                              <div className={`flex items-center space-x-3 font-mono transition-all duration-300 ${
                                populationStep >= 3 
                                  ? sandboxMode === "population" ? "text-sleek-cyan font-bold" : "text-amber-500 font-bold" 
                                  : "text-sleek-muted"
                              }`}>
                                <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] border ${
                                  populationStep >= 3 
                                    ? sandboxMode === "population" ? "border-sleek-cyan bg-sleek-cyan/10" : "border-amber-500 bg-amber-500/10" 
                                    : "border-sleek-muted"
                                }`}>3</span>
                                <div className="text-left">
                                  <div className="text-[11px]">
                                    {sandboxMode === "population" ? "CHECKPOINT License Seal" : "CHECKPOINT Quarantine Seal"}
                                  </div>
                                  <span className="text-[9px] text-[#6B7280] font-normal font-sans">core_layer/src/checkpoint.rs</span>
                                </div>
                              </div>
                            </>
                          )}

                          {activePopulationFlow === "B" && (
                            <>
                              <div className={`flex items-center space-x-3 font-mono transition-all duration-300 ${
                                populationStep >= 1 
                                  ? sandboxMode === "population" ? "text-sleek-green font-bold" : "text-sleek-red font-bold" 
                                  : "text-sleek-muted"
                              }`}>
                                <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] border ${
                                  populationStep >= 1 
                                    ? sandboxMode === "population" ? "border-sleek-green bg-sleek-green/10" : "border-sleek-red bg-sleek-red/10" 
                                    : "border-sleek-muted"
                                }`}>1</span>
                                <div className="text-left">
                                  <div className="text-[11px]">
                                    {sandboxMode === "population" ? "RuntimeRequest Interface" : "RuntimeRequest Limits Breached"}
                                  </div>
                                  <span className="text-[9px] text-[#6B7280] font-normal font-sans">systems_layer/src/runtime_contract.rs</span>
                                </div>
                              </div>
                              <div className={`h-4 border-l border-dashed ml-2.5 transition-colors ${
                                populationStep >= 2 
                                  ? sandboxMode === "population" ? "border-sleek-green" : "border-sleek-red" 
                                  : "border-sleek-border"
                              }`} />
                              <div className={`flex items-center space-x-3 font-mono transition-all duration-300 ${
                                populationStep >= 2 
                                  ? sandboxMode === "population" ? "text-sleek-green font-bold" : "text-sleek-red font-bold" 
                                  : "text-sleek-muted"
                              }`}>
                                <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] border ${
                                  populationStep >= 2 
                                    ? sandboxMode === "population" ? "border-sleek-green bg-sleek-green/10" : "border-sleek-red bg-sleek-red/10" 
                                    : "border-sleek-muted"
                                }`}>2</span>
                                <div className="text-left">
                                  <div className="text-[11px]">
                                    {sandboxMode === "population" ? "Hardware Risk Gate" : "Hardware Gate Shutdown"}
                                  </div>
                                  <span className="text-[9px] text-[#6B7280] font-normal font-sans">systems_layer/src/runtime_gate.rs</span>
                                </div>
                              </div>
                              <div className={`h-4 border-l border-dashed ml-2.5 transition-colors ${
                                populationStep >= 3 
                                  ? sandboxMode === "population" ? "border-sleek-green" : "border-sleek-red" 
                                  : "border-sleek-border"
                              }`} />
                              <div className={`flex items-center space-x-3 font-mono transition-all duration-300 ${
                                populationStep >= 3 
                                  ? sandboxMode === "population" ? "text-sleek-green font-bold" : "text-sleek-red font-bold" 
                                  : "text-sleek-muted"
                              }`}>
                                <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] border ${
                                  populationStep >= 3 
                                    ? sandboxMode === "population" ? "border-sleek-green bg-sleek-green/10" : "border-sleek-red bg-sleek-red/10" 
                                    : "border-sleek-muted"
                                }`}>3</span>
                                <div className="text-left">
                                  <div className="text-[11px]">
                                    {sandboxMode === "population" ? "SIMD Mock Runtime registers" : "AVX-512 Compile Execution Bypassed"}
                                  </div>
                                  <span className="text-[9px] text-[#6B7280] font-normal font-sans">systems_layer/src/compute_runtime.rs</span>
                                </div>
                              </div>
                              <div className={`h-4 border-l border-dashed ml-2.5 transition-colors ${
                                populationStep >= 3.5 
                                  ? sandboxMode === "population" ? "border-sleek-green" : "border-sleek-red" 
                                  : "border-sleek-border"
                              }`} />
                              <div className={`flex items-center space-x-3 font-mono transition-all duration-300 ${
                                populationStep >= 4 
                                  ? sandboxMode === "population" ? "text-sleek-green font-bold" : "text-sleek-red font-bold" 
                                  : "text-sleek-muted"
                              }`}>
                                <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] border ${
                                  populationStep >= 4 
                                    ? sandboxMode === "population" ? "border-sleek-green bg-sleek-green/10" : "border-sleek-red bg-sleek-red/10" 
                                    : "border-sleek-muted"
                                }`}>4</span>
                                <div className="text-left">
                                  <div className="text-[11px]">
                                    {sandboxMode === "population" ? "Runtime Audit Sequential Trace" : "Quarantined Audit Contract Log"}
                                  </div>
                                  <span className="text-[9px] text-[#6B7280] font-normal font-sans">systems_layer/src/runtime_audit.rs</span>
                                </div>
                              </div>
                            </>
                          )}

                          {activePopulationFlow === "C" && (
                            <>
                              <div className={`flex items-center space-x-3 font-mono transition-all duration-300 ${populationStep >= 1 ? "text-sleek-red font-bold" : "text-sleek-muted"}`}>
                                <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] border ${
                                  populationStep >= 1 ? "border-sleek-red bg-sleek-red/10" : "border-sleek-muted"
                                }`}>1</span>
                                <div className="text-left">
                                  <div className="text-[11px]">
                                    {sandboxMode === "population" ? "Signal Packet Input Stream" : "7B Unaligned Payload Ingestion"}
                                  </div>
                                  <span className="text-[9px] text-[#6B7280] font-normal font-sans">systems_layer/src/signal.rs</span>
                                </div>
                              </div>
                              <div className={`h-3 border-l border-dashed ml-2.5 transition-colors ${populationStep >= 2 ? "border-sleek-red" : "border-sleek-border"}`} />
                              <div className={`flex items-center space-x-3 font-mono transition-all duration-300 ${populationStep >= 2 ? "text-sleek-red font-bold" : "text-sleek-muted"}`}>
                                <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] border ${
                                  populationStep >= 2 ? "border-sleek-red bg-sleek-red/10" : "border-sleek-muted"
                                }`}>2</span>
                                <div className="text-left">
                                  <div className="text-[11px]">
                                    {sandboxMode === "population" ? "SignalInspector raw cast" : "SignalInspector Direct Cast ABORTED"}
                                  </div>
                                  <span className="text-[9px] text-[#6B7280] font-normal font-sans">systems_layer/src/signal_inspector.rs</span>
                                </div>
                              </div>
                              <div className={`h-3 border-l border-dashed ml-2.5 transition-colors ${populationStep >= 3 ? "border-sleek-red" : "border-sleek-border"}`} />
                              <div className={`flex items-center space-x-3 font-mono transition-all duration-300 ${populationStep >= 3 ? "text-sleek-red font-bold" : "text-sleek-muted"}`}>
                                <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] border ${
                                  populationStep >= 3 ? "border-sleek-red bg-sleek-red/10" : "border-sleek-muted"
                                }`}>3</span>
                                <div className="text-left">
                                  <div className="text-[11px]">
                                    Friction Deviation Engine
                                  </div>
                                  <span className="text-[9px] text-[#6B7280] font-normal font-sans">systems_layer/src/friction.rs</span>
                                </div>
                              </div>
                              <div className={`h-3 border-l border-dashed ml-2.5 transition-colors ${populationStep >= 4 ? "border-sleek-red" : "border-sleek-border"}`} />
                              <div className={`flex items-center space-x-3 font-mono transition-all duration-300 ${populationStep >= 4 ? "text-sleek-red font-bold" : "text-sleek-muted"}`}>
                                <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] border ${
                                  populationStep >= 4 ? "border-sleek-red bg-sleek-red/10" : "border-sleek-muted"
                                }`}>4</span>
                                <div className="text-left">
                                  <div className="text-[11px]">
                                    {sandboxMode === "population" ? "Mitigation Sandboxed Router" : "Mitigation Sandbox Deflection"}
                                  </div>
                                  <span className="text-[9px] text-[#6B7280] font-normal font-sans">systems_layer/src/router.rs</span>
                                </div>
                              </div>
                              <div className={`h-3 border-l border-dashed ml-2.5 transition-colors ${populationStep >= 4.5 ? "border-sleek-red" : "border-sleek-border"}`} />
                              <div className={`flex items-center space-x-3 font-mono transition-all duration-300 ${populationStep >= 5 ? "text-sleek-red font-bold" : "text-sleek-muted"}`}>
                                <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] border ${
                                  populationStep >= 5 ? "border-[#FF3B30] bg-[#FF3B30]/10" : "border-sleek-muted"
                                }`}>5</span>
                                <div className="text-left">
                                  <div className="text-[11px]">
                                    {sandboxMode === "population" ? "Rigid Register Cycle Reset" : "Alignment Buffers Hard Flush"}
                                  </div>
                                  <span className="text-[9px] text-[#6B7280] font-normal font-sans">System Hardware Level</span>
                                </div>
                              </div>
                            </>
                          )}
                        </div>
                      </div>

                      <div className="mt-4 pt-4 border-t border-sleek-border text-[10px] font-mono text-[#6B7280]">
                        <span>SIMULATOR STATUS: STAGES LINKED DETERMINISTICALLY</span>
                      </div>
                    </div>

                    {/* Right Emulated Output Logs Console */}
                    <div className="lg:col-span-3 p-4 flex flex-col justify-between bg-[#07090C] font-mono whitespace-pre-wrap select-text text-left">
                      <div className="space-y-1.5 overflow-y-auto max-h-[250px]" id="experiments-terminal-logs">
                        {populationLogs.map((log, lidx) => {
                          let color = "text-sleek-text";
                          if (log.startsWith("🏁") || log.startsWith("[PACKET]")) color = "text-[#6B7280]";
                          else if (log.includes("SIMON Observation") || log.includes("Astra memory")) color = "text-sleek-cyan font-semibold";
                          else if (log.includes("CP-001")) {
                            color = log.includes("FAIL") ? "text-amber-500 font-semibold" : "text-sleek-cyan";
                          }
                          else if (log.includes("SAFE") || log.includes("MockRuntime") || log.includes("passed boundary")) color = "text-[#4CD964]";
                          else if (log.includes("Missing packet lineage") || log.includes("Friction target") || log.includes("ALERT") || log.includes("deflected") || log.includes("breach") || log.includes("CRASH") || log.includes("aborted") || log.includes("Limit Contract Rejection") || log.includes("unaligned") || log.includes("aborted") || log.includes("Alignment Fault") || log.includes("quarantine")) {
                            color = "text-sleek-red";
                          }
                          else if (log.startsWith("🎉")) color = "text-[#4CD964] font-bold mt-2 border-t border-[#4CD964]/10 pt-2 block";

                          return (
                            <div key={lidx} className={`text-xs ${color}`}>
                              {log}
                            </div>
                          );
                        })}
                      </div>

                      <div className="mt-4 pt-3 border-t border-[#1E2128]/40 flex items-center justify-between text-[10px] text-[#6B7280]">
                        <span>OUT: TARGET/WITNESS_STREAM.LOG</span>
                        <span>LINEAGE CHECKPOINT LOCKED</span>
                      </div>
                    </div>
                  </div>
                )}
                  </>
                ) : (
                  <>
                    <div className="grid grid-cols-1 lg:grid-cols-5 gap-6 text-left" id="population-v2-grid">
                      {/* Left Column: SliceIntent & Operator Validation Admission Form (2/5 span) */}
                      <div className="lg:col-span-2 bg-[#12141C] border border-[#232736] rounded-xl p-5 flex flex-col justify-between space-y-4">
                        <div className="space-y-4">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center space-x-2">
                              <Shield className="text-sleek-cyan w-4 h-4" />
                              <h3 className="text-xs font-bold text-white uppercase font-mono tracking-wider">1. SliceIntent Contract</h3>
                            </div>
                            <span className="text-[8px] font-mono text-sleek-cyan bg-sleek-cyan/10 px-1.5 py-0.5 rounded uppercase tracking-wider font-semibold">Active Primitive</span>
                          </div>

                          {/* Dynamic SliceIntent Fields */}
                          <div className="bg-[#181A25] border border-[#2d3247]/60 rounded-lg p-3 space-y-3 text-xs font-sans">
                            <div className="grid grid-cols-2 gap-2">
                              <div>
                                <label className="text-sleek-muted block mb-0.5 uppercase font-semibold text-[8px] tracking-wide font-mono">Slice ID:</label>
                                <input
                                  type="text"
                                  value={sliceIntentId}
                                  onChange={(e) => setSliceIntentId(e.target.value)}
                                  className="w-full bg-[#12141C] border border-[#232736] p-1.5 rounded text-white font-mono text-[11px]"
                                  placeholder="SLICE-INTENT-742"
                                />
                              </div>
                              <div>
                                <label className="text-sleek-muted block mb-0.5 uppercase font-semibold text-[8px] tracking-wide font-mono">Expected Freq:</label>
                                <input
                                  type="text"
                                  value={sliceIntentFrequency}
                                  onChange={(e) => setSliceIntentFrequency(e.target.value)}
                                  className="w-full bg-[#12141C] border border-[#232736] p-1.5 rounded text-white font-mono text-[11px]"
                                  placeholder="Hourly"
                                />
                              </div>
                            </div>

                            <div>
                              <label className="text-sleek-muted block mb-0.5 uppercase font-semibold text-[8px] tracking-wide font-mono">Reason for Capture:</label>
                              <textarea
                                value={sliceIntentReason}
                                onChange={(e) => setSliceIntentReason(e.target.value)}
                                className="w-full bg-[#12141C] border border-[#232736] p-1.5 rounded text-white text-[11px] leading-snug resize-none h-14"
                                placeholder="Why was this slice captured? What question is it answering?"
                              />
                            </div>

                            <div className="grid grid-cols-2 gap-2">
                              <div>
                                <label className="text-sleek-muted block mb-0.5 uppercase font-semibold text-[8px] tracking-wide font-mono">Validation Question:</label>
                                <input
                                  type="text"
                                  value={sliceIntentValidationQuestion}
                                  onChange={(e) => setSliceIntentValidationQuestion(e.target.value)}
                                  className="w-full bg-[#12141C] border border-[#232736] p-1.5 rounded text-white text-[11px]"
                                  placeholder="Is the delta meaningful or drift?"
                                />
                              </div>
                              <div>
                                <label className="text-sleek-muted block mb-0.5 uppercase font-semibold text-[8px] tracking-wide font-mono">Operator Mode:</label>
                                <select
                                  value={sliceIntentOperatorMode}
                                  onChange={(e) => setSliceIntentOperatorMode(e.target.value)}
                                  className="w-full bg-[#12141C] border border-[#232736] p-1.5 rounded text-white text-[11px] cursor-pointer"
                                >
                                  <option value="Observe">Observe</option>
                                  <option value="Enforce">Enforce</option>
                                  <option value="Override">Override</option>
                                </select>
                              </div>
                            </div>
                          </div>

                          <div className="flex items-center space-x-2">
                            <Cpu className="text-sleek-cyan w-4 h-4" />
                            <h3 className="text-xs font-bold text-white uppercase font-mono tracking-wider">2. Live Telemetry & Aperture</h3>
                          </div>

                          {/* Live Feed Status Bar */}
                          <div className="bg-[#1A1D29] border border-[#2d3247]/60 rounded-lg p-2.5 space-y-2 text-xs font-mono">
                            <div className="flex items-center justify-between">
                              <span className="text-[9px] text-sleek-muted uppercase font-bold flex items-center space-x-1.5 leading-none font-mono">
                                <span className="w-1.5 h-1.5 rounded-full bg-sleek-green animate-pulse"></span>
                                <span>LIVE EXTERNAL FEED STATUS</span>
                              </span>
                              <button
                                onClick={() => setIsLivePolling(!isLivePolling)}
                                className={`text-[8px] px-1.5 py-0.5 rounded font-bold uppercase transition-colors cursor-pointer ${
                                  isLivePolling 
                                    ? "bg-[#4CD964]/10 text-[#4CD964] border border-[#4CD964]/20" 
                                    : "bg-[#252836] text-sleek-muted border border-sleek-muted/15"
                                }`}
                              >
                                {isLivePolling ? "● LIVE SYNC" : "○ PAUSED"}
                              </button>
                            </div>
                            
                            <div className="grid grid-cols-2 gap-2 text-[10px] pt-1">
                              <div className="bg-[#12141C] p-1.5 rounded border border-[#232736]/40">
                                <span className="text-[#6B7280] block text-[8px] uppercase font-semibold">Coinbase Spot (TV)</span>
                                <span className="text-white font-bold block mt-0.5">
                                  ${renderedCanonicalPacket.liveSpot.toLocaleString(undefined, {minimumFractionDigits: 2})}
                                </span>
                              </div>
                              <div className="bg-[#12141C] p-1.5 rounded border border-[#232736]/40">
                                <span className="text-[#6B7280] block text-[8px] uppercase font-semibold">CME Futures Basis</span>
                                <span className="text-sleek-cyan font-bold block mt-0.5">
                                  ${renderedCanonicalPacket.liveFuture.toLocaleString(undefined, {minimumFractionDigits: 2})}
                                </span>
                              </div>
                            </div>

                            {/* AUTHORITY PRICE DOMAIN MODE SELECTOR */}
                            <div className="border-t border-[#2d3247]/40 pt-2 flex flex-col space-y-1.5">
                              <span className="text-[8px] text-sleek-muted uppercase font-bold tracking-wider font-mono">
                                CANONICAL PRICE DOMAIN MODE
                              </span>
                              <div className="grid grid-cols-3 gap-1">
                                {(["LIVE", "HISTORICAL", "SIMULATED"] as const).map((mode) => (
                                  <button
                                    key={mode}
                                    onClick={() => setMarketMode(mode)}
                                    className={`text-[8px] py-1 rounded font-bold uppercase transition-all duration-150 cursor-pointer text-center border ${
                                      marketMode === mode
                                        ? "bg-sleek-cyan/15 text-sleek-cyan border-sleek-cyan/40 shadow-sm"
                                        : "bg-[#12141C] text-sleek-muted border-[#232736] hover:text-white hover:border-[#353b52]"
                                    }`}
                                  >
                                    {mode}
                                  </button>
                                ))}
                              </div>
                              <div className="bg-[#0D1017] text-[8px] p-2 rounded border border-[#232736]/50 text-slate-400 font-mono flex flex-col space-y-0.5">
                                <div className="flex justify-between">
                                  <span>Active Registry:</span>
                                  <span className="text-white font-bold">{renderedCanonicalPacket.priceDomain}</span>
                                </div>
                                <div className="flex justify-between">
                                  <span>Canonical Spot:</span>
                                  <span className="text-sleek-cyan font-bold">${renderedCanonicalPacket.liveSpot.toLocaleString(undefined, {minimumFractionDigits: 2})}</span>
                                </div>
                                <div className="flex justify-between">
                                  <span>Canonical Basis:</span>
                                  <span className="text-amber-400 font-bold">${renderedCanonicalPacket.basisDelta.toLocaleString(undefined, {minimumFractionDigits: 2})}</span>
                                </div>
                              </div>
                            </div>

                            {/* SIMON LIVE DUO-AUTHORITY COMPRESSION PACKET STRUCT */}
                            <div className="bg-[#090A0E] border border-amber-500/10 rounded-lg p-2.5 space-y-1 font-mono text-[9px] text-[#A9B1D6]">
                              <div className="flex items-center justify-between text-[10px] pb-1 border-b border-[#232736]/50">
                                <span className="text-sleek-cyan font-bold flex items-center space-x-1">
                                  <Cpu className="w-3.5 h-3.5 text-sleek-cyan" />
                                  <span>struct: AuthorityCompressionPacket</span>
                                </span>
                                <span className={`px-1 rounded text-[8px] font-bold ${
                                  Math.abs(renderedCanonicalPacket.basisDelta) > divergenceThreshold
                                    ? "bg-sleek-red/15 text-sleek-red animate-pulse"
                                    : "bg-sleek-green/15 text-[#4CD964]"
                                }`}>
                                  {Math.abs(renderedCanonicalPacket.basisDelta) > divergenceThreshold ? "DIVERGENT" : "ALIGNED"}
                                </span>
                              </div>
                              <div className="pt-1 select-all space-y-1 text-left">
                                <div><span className="text-sleek-muted">packet_id:</span> <span className="text-[#4CD964]">"PKT-AUTH-001"</span></div>
                                <div><span className="text-sleek-muted">asset:</span> <span className="text-[#E0AF68]">"{sliceIntentAsset}"</span></div>
                                <div className="grid grid-cols-2">
                                  <div><span className="text-sleek-muted">authority_a:</span> <span className="text-amber-400 font-bold">"{renderedCanonicalPacket.authorityA}"</span></div>
                                  <div><span className="text-sleek-muted">authority_b:</span> <span className="text-sleek-cyan font-bold">"CME"</span></div>
                                </div>
                                <div className="grid grid-cols-2">
                                  <div><span className="text-sleek-muted">price_a:</span> <span className="text-white font-bold">${renderedCanonicalPacket.liveSpot.toFixed(2)}</span></div>
                                  <div><span className="text-sleek-muted">price_b:</span> <span className="text-white font-bold">${renderedCanonicalPacket.liveFuture.toFixed(2)}</span></div>
                                </div>
                                <div className="grid grid-cols-2">
                                  <div><span className="text-sleek-muted">timestamp_a:</span> <span>"{renderedCanonicalPacket.timestamp}"</span></div>
                                  <div><span className="text-sleek-muted">timestamp_b:</span> <span>"{renderedCanonicalPacket.timestamp}"</span></div>
                                </div>
                                <div className="pt-1.5 mt-1 border-t border-[#232736]/40 flex justify-between items-center">
                                  <div>
                                    <span className="text-sleek-muted">price_delta_offset:</span>{" "}
                                    <span className={`font-bold ${
                                      Math.abs(renderedCanonicalPacket.basisDelta) > divergenceThreshold
                                        ? "text-sleek-red"
                                        : "text-[#4CD964]"
                                    }`}>
                                      ${Math.abs(renderedCanonicalPacket.basisDelta).toFixed(2)}
                                    </span>
                                  </div>
                                  <div className="text-[8px] text-sleek-muted">
                                    LAT_DELTA: <span className="text-sleek-cyan">~2.4ms</span>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>

                          {/* Centerpiece Aperture Controller: Divergence Threshold */}
                          <div className="bg-[#12141C] border border-sleek-cyan/30 rounded-xl p-3.5 space-y-2 relative overflow-hidden shadow-[0_0_20px_rgba(100,210,255,0.08)] select-none">
                            <div className="absolute top-0 right-0 h-full w-24 bg-gradient-to-l from-sleek-cyan/5 to-transparent pointer-events-none"></div>
                            
                            <div className="flex justify-between items-start">
                              <div className="space-y-0.5 text-left">
                                <span className="text-sleek-cyan font-bold text-[9px] tracking-widest uppercase font-mono block">
                                  ⚖️ APERTURE GATEWAY LIMIT
                                </span>
                                <span className="text-[8px] text-sleek-muted italic leading-tight block">
                                  Defining the boundary between Reality Anchor & Divergence.
                                </span>
                              </div>
                              <div className="bg-[#1C3E3E]/60 border border-sleek-cyan/30 rounded px-2 py-0.5 text-right shrink-0">
                                <span className="text-[7px] text-[#A1A1AA] block tracking-wide font-mono uppercase">LIMIT</span>
                                <span className="text-sleek-cyan font-extrabold font-mono text-[10px] tracking-wide block leading-none">
                                  ${divergenceThreshold.toFixed(2)}
                                </span>
                              </div>
                            </div>

                            <div className="space-y-1 relative">
                              <input 
                                type="range"
                                min="0.10"
                                max="5.00"
                                step="0.10"
                                value={divergenceThreshold}
                                onChange={(e) => setDivergenceThreshold(parseFloat(e.target.value))}
                                className="w-full accent-sleek-cyan cursor-pointer h-1.5 bg-[#090A0E] border border-[#232736] rounded-lg appearance-none"
                              />
                            </div>

                            <div className="bg-[#090A0E]/80 border border-sleek-border/40 rounded p-2 flex items-center justify-between text-[9px] font-mono text-left">
                              <span className="text-sleek-muted font-sans text-[8px]">ACTIVE FORMULA STATUS:</span>
                              <span className={`font-semibold shrink-0 uppercase tracking-wide flex items-center ${
                                Math.abs(renderedCanonicalPacket.basisDelta) > divergenceThreshold
                                  ? "text-sleek-red"
                                  : "text-[#4CD964]"
                              }`}>
                                <span className="w-1.5 h-1.5 rounded-full bg-current mr-1 animate-pulse"></span>
                                {Math.abs(renderedCanonicalPacket.basisDelta) > divergenceThreshold
                                  ? `DIVERGENT ($${Math.abs(renderedCanonicalPacket.basisDelta).toFixed(2)})`
                                  : `ALIGNED ($${Math.abs(renderedCanonicalPacket.basisDelta).toFixed(2)})`}
                              </span>
                            </div>
                          </div>

                          <div className="space-y-3 font-mono text-[11px]">
                            {/* Authority Source Selector */}
                            <div>
                              <label className="text-sleek-muted block mb-1 uppercase font-semibold text-[10px]">DATA SOURCE AUTHORITY:</label>
                              <select 
                                value={v2Authority} 
                                onChange={(e) => setV2Authority(e.target.value)}
                                className="w-full bg-[#1A1D29] border border-[#2d3247] p-2 rounded text-white focus:outline-none focus:border-sleek-cyan cursor-pointer text-xs"
                              >
                                <option value="TradingView">TradingView (RapidAPI Feed)</option>
                                <option value="CME Group">CME Group (Chicago Mercantile Exchange)</option>
                                <option value="Coinbase">Coinbase Pro Websocket</option>
                                <option value="Binance">Binance Spot Rest API</option>
                                <option value="Custom">Custom Signed External Feed</option>
                              </select>
                            </div>

                            {/* Asset Identifier */}
                            <div>
                              <label className="text-sleek-muted block mb-1 uppercase font-semibold text-[10px]">ASSET IDENTIFIER / SYMBOL:</label>
                              <input 
                                type="text" 
                                value={v2Asset} 
                                onChange={(e) => setV2Asset(e.target.value)}
                                className="w-full bg-[#1A1D29] border border-[#2d3247] p-2 rounded text-white focus:outline-none focus:border-sleek-cyan text-xs font-bold"
                                placeholder="e.g. BTCUSD"
                              />
                            </div>

                            {/* Operator Decision Choice on Divergence */}
                            <div>
                              <label className="text-sleek-muted block mb-1 uppercase font-semibold text-[10px]">OPERATOR DECISION ON LIMITS:</label>
                              <select 
                                value={v2OperatorDecision} 
                                onChange={(e) => setV2OperatorDecision(e.target.value as any)}
                                className="w-full bg-[#1A1D29] border border-sleek-cyan/30 p-2 rounded text-[#4CD964] font-bold focus:outline-none focus:border-sleek-cyan cursor-pointer text-xs uppercase"
                              >
                                <option value="Accept">Accept (Continuous Sync)</option>
                                <option value="Observe">Observe (Consensus Alert Only)</option>
                                <option value="Reject">Reject (Flush pipeline cache)</option>
                                <option value="Investigate">Investigate (Trigger deep diagnostic)</option>
                              </select>
                            </div>

                            {/* Security Affiliations */}
                            <div className="space-y-2 pt-2 border-t border-[#232736]">
                              <label className="flex items-start space-x-2 cursor-pointer select-none">
                                <input 
                                  type="checkbox" 
                                  checked={v2OperatorChecked} 
                                  onChange={(e) => setV2OperatorChecked(e.target.checked)}
                                  className="mt-0.5 rounded border-[#2E313E] bg-[#1A1D29] text-sleek-cyan accent-sleek-cyan cursor-pointer"
                                />
                                <span className="text-[10px] text-sleek-text leading-snug font-sans">
                                  Operator Affirmation: "I certify that I verified and choose to admit this reality anchor."
                                </span>
                              </label>
                            </div>
                          </div>
                        </div>

                        <div className="pt-4">
                          {isAwaitingOperatorPersistenceApproval ? (
                            <div className="bg-[#131E2B] border border-sleek-cyan/35 rounded-lg p-3 space-y-2.5 animate-pulse-subtle">
                              <div className="flex items-center space-x-1.5 text-sleek-cyan text-[11px] font-mono font-bold uppercase leading-none font-sans">
                                <ShieldCheck className="w-4 h-4 text-sleek-cyan shrink-0 animate-bounce" />
                                <span>Governance Gate: Persistence Approval Required</span>
                              </div>
                              <p className="text-[10px] text-[#A0AEC0] leading-normal font-sans">
                                Checkpoint validated, reasoning fetched and sealed in sandboxed memory. Verify telemetry and analytical reasoning opinion before writing to persistent ledger.
                              </p>
                              <div className="grid grid-cols-2 gap-2">
                                <button
                                  onClick={approveV2Persistence}
                                  disabled={isV2Admitting}
                                  className="w-full py-2 bg-[#4CD964] hover:bg-[#3db853] text-black rounded font-mono font-bold text-[10px] cursor-pointer transition-colors shadow-md flex items-center justify-center space-x-1"
                                >
                                  <Database className="w-3 h-3 shrink-0" />
                                  <span>{isV2Admitting ? "WRITING..." : "APPROVE & COMMIT"}</span>
                                </button>
                                <button
                                  onClick={discardV2Admission}
                                  disabled={isV2Admitting}
                                  className="w-full py-2 bg-[#FF3B30]/10 hover:bg-[#FF3B30]/20 text-[#FF3B30] border border-[#FF3B30]/30 rounded font-mono font-bold text-[10px] cursor-pointer transition-colors flex items-center justify-center space-x-1"
                                >
                                  <XCircle className="w-3 h-3 shrink-0" />
                                  <span>FLUSH CACHE</span>
                                </button>
                              </div>
                            </div>
                          ) : (
                            <button
                              onClick={triggerV2Admission}
                              disabled={isV2Admitting || !v2OperatorChecked}
                              className={`w-full py-2.5 rounded font-mono font-bold text-xs cursor-pointer transition-all ${
                                isV2Admitting 
                                  ? "bg-[#1E2128] text-sleek-muted border border-[#2D3139] cursor-not-allowed"
                                  : !v2OperatorChecked
                                    ? "bg-sleek-muted/10 text-sleek-muted border border-sleek-border cursor-not-allowed"
                                    : "bg-white text-black hover:bg-slate-200 shadow-lg border border-slate-300 flex items-center justify-center space-x-2 font-sans text-xs"
                              }`}
                            >
                              <Zap className="w-3.5 h-3.5" />
                              <span>{isV2Admitting ? "ADMITTING & BINDING..." : "ADMIT & RECORD TRUST ANCHOR"}</span>
                            </button>
                          )}
                        </div>
                      </div>

                    {/* Right Column: Execution Map & Terminal Logs (3/5 span) */}
                    <div className="lg:col-span-3 flex flex-col space-y-4 font-sans">
                      {/* Execution map */}
                      <div className="bg-[#0A0B0F]/90 border border-sleek-border rounded-xl p-4 flex-1 flex flex-col justify-between">
                        <div className="space-y-2">
                          <div className="flex items-center justify-between">
                            <span className="text-[10px] font-mono text-sleek-muted uppercase tracking-wider font-bold block">
                              Admissions Pipeline Hierarchy
                            </span>
                            <span className="text-[9px] text-[#4CD964] font-mono bg-sleek-green/5 px-1.5 py-0.5 rounded border border-sleek-green/15 flex items-center space-x-1 max-w-fit">
                              <span className="w-1.5 h-1.5 rounded-full bg-sleek-green animate-ping"></span>
                              <span>Operator Validation Arbiter</span>
                            </span>
                          </div>

                          {/* Interactive flow map diagram */}
                          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-2 pt-4">
                            {[
                              { name: "1. INTENT", desc: sliceIntentId, step: 1, subtext: "SliceIntent" },
                              { name: "2. PACKET", desc: "AUTH-001", step: 2, subtext: "Compression" },
                              { name: "3. RAPIDS", desc: "Math Engine", step: 3, subtext: "SIMD Subtraction" },
                              { name: "4. APERTURE", desc: `$${divergenceThreshold.toFixed(2)} Limit`, step: 4, subtext: "Boundary Gate" },
                              { name: "5. VALIDATION", desc: "Sig Verified", step: 5, subtext: "Hardware Clock" },
                              { name: "6. GEMINI CO", desc: aiValidationOutcome ? aiValidationOutcome : isAiReasoningLoading ? "Thinking..." : "Awaiting...", step: 6, subtext: "AI Reasoning" },
                              { name: "7. OPERATOR", desc: v2OperatorDecision, step: 7, subtext: "Commit Ledger" }
                            ].map((item, idx) => {
                              const isPassed = v2ActiveFlowStep >= item.step;
                              const isActive = v2ActiveFlowStep === item.step;
                              return (
                                <div 
                                  key={idx} 
                                  className={`p-2 rounded border text-left font-mono transition-all duration-300 flex flex-col justify-between h-[64px] ${
                                    isActive
                                      ? "bg-sleek-cyan/10 border-sleek-cyan shadow-[0_0_10px_rgba(100,210,255,0.15)] scale-[1.02]"
                                      : isPassed 
                                        ? "bg-[#0f241d]/40 border-sleek-green/40 opacity-90"
                                        : "bg-[#07090c] border-[#1e222e] opacity-40"
                                  }`}
                                >
                                  <div>
                                    <div className="text-[7.5px] text-sleek-muted shrink-0 truncate uppercase font-bold leading-none">{item.name}</div>
                                    <div className={`text-[9.5px] font-bold truncate mt-1 ${isPassed ? "text-white" : "text-sleek-muted"}`}>{item.desc}</div>
                                  </div>
                                  <span className="text-[8px] text-[#6B7280] font-sans truncate block leading-none">{item.subtext}</span>
                                </div>
                              );
                            })}
                          </div>
                        </div>

                        {/* Real-time Gemini Coprocessor Opinion Card */}
                        {(isAiReasoningLoading || aiReasoningText) && (
                          <div className="mt-4 bg-[#141824] border border-sleek-cyan/20 rounded-xl p-4 space-y-3 animate-fade-in text-left">
                            <div className="flex items-center justify-between border-b border-white/5 pb-2">
                              <div className="flex items-center space-x-2">
                                <BrainCircuit className="text-purple-400 w-4 h-4 animate-pulse" />
                                <span className="text-xs font-mono font-bold text-white uppercase tracking-wider">
                                  Coprocessor Definition Alignment
                                </span>
                              </div>
                              {isAiReasoningLoading ? (
                                <span className="text-[9px] font-mono text-purple-400 animate-pulse bg-purple-400/10 px-1.5 py-0.5 rounded uppercase tracking-wider font-semibold">
                                  Consulting Gemini...
                                </span>
                              ) : (
                                <span className={`text-[9px] font-mono px-2 py-0.5 rounded uppercase tracking-wider font-extrabold ${
                                  aiValidationOutcome === "ALIGNED" || aiValidationOutcome === "COMPLIANT_CONVERGENCE"
                                    ? "bg-[#4CD964]/10 text-[#4CD964]"
                                    : aiValidationOutcome === "REASONABLE_VARIANCE"
                                      ? "bg-amber-400/10 text-amber-400"
                                      : "bg-sleek-red/10 text-sleek-red"
                                }`}>
                                  Outcome: {aiValidationOutcome}
                                </span>
                              )}
                            </div>

                            {isAiReasoningLoading ? (
                              <div className="py-4 flex flex-col items-center justify-center space-y-2 text-xs text-sleek-muted font-mono">
                                <RefreshCw className="w-5 h-5 animate-spin text-purple-400" />
                                <span>Generating dynamic opinion over intent contract...</span>
                              </div>
                            ) : (
                              <div className="space-y-3">
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
                                  <div className="bg-[#0D1017] p-2.5 rounded-lg border border-white/5 font-sans">
                                    <span className="text-[#8A95A5] uppercase font-bold text-[8.5px] block tracking-wide font-mono mb-1">
                                      Validation Question Response:
                                    </span>
                                    <p className="text-white text-[11px] font-semibold leading-relaxed italic">
                                      "{aiMeaningfulSummary}"
                                    </p>
                                  </div>
                                  <div className="bg-[#0D1017] p-2.5 rounded-lg border border-white/5 font-sans">
                                    <span className="text-[#8A95A5] uppercase font-bold text-[8.5px] block tracking-wide font-mono mb-1">
                                      Active Intent Context Checked:
                                    </span>
                                    <p className="text-slate-300 text-[11px] leading-relaxed">
                                      Targeting <strong className="text-white font-mono">{sliceIntentAsset}</strong> with validation question: <em className="text-sleek-cyan">"{sliceIntentValidationQuestion}"</em> under <strong className="text-amber-400 font-mono">{sliceIntentOperatorMode}</strong> mode.
                                    </p>
                                  </div>
                                </div>

                                <div className="bg-[#0D1017] p-3 rounded-lg border border-purple-500/10 font-sans text-xs">
                                  <div className="text-[8.5px] uppercase font-bold font-mono text-purple-300 mb-1 tracking-wider">
                                    Trace Analytical Argumentation:
                                  </div>
                                  <p className="text-slate-300 leading-relaxed text-[11px]">
                                    {aiReasoningText}
                                  </p>
                                </div>

                                {v2EvidenceChain && v2EvidenceChain.length > 0 && (
                                  <div className="bg-[#0D1017] p-3 rounded-lg border border-purple-500/10 font-sans text-xs">
                                    <div className="text-[8.5px] uppercase font-bold font-mono text-purple-300 mb-2 tracking-wider border-b border-white/5 pb-1 flex justify-between items-center">
                                      <span>🔍 TRACE EVIDENCE CHAIN (METRIC IMPACT LEDGER):</span>
                                      <span className="text-purple-400 font-mono text-[8px] bg-purple-500/10 px-1 py-0.5 rounded font-bold">100% Traceable</span>
                                    </div>
                                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                                      {v2EvidenceChain.map((ev, idx) => (
                                        <div key={idx} className="bg-[#141824]/60 p-2 rounded border border-white/5 space-y-1 text-left">
                                          <div className="flex justify-between items-center border-b border-white/5 pb-1">
                                            <span className="font-mono text-[9.5px] text-white font-bold">{ev.metric}</span>
                                            <span className="font-mono text-[9px] text-sleek-cyan bg-sleek-cyan/10 px-1 rounded">{ev.value}</span>
                                          </div>
                                          <div className="text-[9px] text-[#8A95A5]">
                                            Limit Range: <span className="text-slate-300 italic font-medium">{ev.referenceRange}</span>
                                          </div>
                                          <p className="text-[9px] text-slate-400 font-sans leading-relaxed pt-1 border-t border-white/5 mt-1">
                                            {ev.impact}
                                          </p>
                                        </div>
                                      ))}
                                    </div>
                                  </div>
                                )}
                              </div>
                            )}
                          </div>
                        )}

                        <div className="mt-4 pt-1 flex items-center justify-between text-[10px] font-mono text-[#6B7280]">
                          <span>PIPELINE: TRUST ANCHOR ACTIVE</span>
                          <span>OPERATOR APPROVED INTEGRITY</span>
                        </div>
                      </div>

                      {/* Console Logger */}
                      <div className="bg-[#050608] border border-sleek-border rounded-xl p-4 h-[210px] flex flex-col justify-between font-mono">
                        <div className="space-y-2 overflow-y-auto max-h-[145px] select-text text-left w-full" id="v2-console-logs">
                          {v2Logs.length === 0 ? (
                            <div className="text-sleek-muted text-xs italic flex items-center justify-center h-full pt-12">
                              Awaiting Operator validation admission... Choose parameters and trigger admission to see compliance check logs.
                            </div>
                          ) : (
                            v2Logs.map((log, index) => {
                              let color = "text-sleek-text";
                              if (log.startsWith("🏁") || log.startsWith("➔")) color = "text-[#6B7280]";
                              else if (log.includes("👤 OPERATOR") || log.includes("Rule:")) color = "text-purple-400 font-semibold";
                              else if (log.includes("SIMON")) color = "text-sleek-cyan font-semibold";
                              else if (log.includes("ASTRA")) color = "text-amber-500 font-semibold";
                              else if (log.includes("CHECKPOINT")) color = "text-sleek-green font-semibold";
                              else if (log.startsWith("🎉")) color = "text-[#4CD964] font-bold pt-1.5 border-t border-[#4CD964]/10 block mt-1.5";

                              return (
                                <div key={index} className="text-[11px] leading-relaxed">
                                  <span className={color}>{log}</span>
                                </div>
                              );
                            })
                          )}
                        </div>

                        <div className="mt-3 pt-3 border-t border-[#1E2128]/40 flex items-center justify-between text-[9px] text-[#5A6070]">
                          <span>LOGSTREAM: SYSTEM/CONSENSUS_AUDIT.LOG</span>
                          <span>FEED VALIDATION ACTIVE</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Sovereign Audit Ledger (Firebase Secured) */}
                  <div className="bg-[#12141C] border border-[#232736] rounded-xl p-5 mt-6 space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <Database className="text-[#4CD964] w-4.5 h-4.5" />
                        <h3 className="text-xs font-bold text-white uppercase font-mono tracking-wider flex items-center">
                          Immutable Consensus Audit Ledger <span className="text-[#6B7280] font-normal text-[10px] pl-2">— Firebase Cloud Storage</span>
                        </h3>
                      </div>

                      <div className="flex items-center space-x-3">
                        <button
                          onClick={fetchFirestoreAudits}
                          disabled={firebaseLoading}
                          className="bg-[#1A1D29] hover:bg-[#252836] text-[10px] text-[#A0AEC0] border border-[#2d3247] px-2.5 py-1 rounded font-mono font-bold flex items-center space-x-1.5 transition-colors cursor-pointer"
                        >
                          <RefreshCw className={`w-3 h-3 ${firebaseLoading ? 'animate-spin' : ''}`} />
                          <span>REFRESH LEDGER</span>
                        </button>
                      </div>
                    </div>

                    {firebaseLoading && firebaseAudits.length === 0 ? (
                      <div className="py-12 flex flex-col items-center justify-center space-y-2 text-xs text-[#6B7280]">
                        <RefreshCw className="w-5 h-5 animate-spin text-[#4CD964]" />
                        <span>Streaming audited ledger registers from cloud sandbox...</span>
                      </div>
                    ) : firebaseAudits.length === 0 ? (
                      <div className="py-12 flex flex-col items-center justify-center border border-dashed border-[#232736] rounded-lg text-xs text-[#6B7280]">
                        <Database className="w-6 h-6 mb-2 text-[#232736]" />
                        <span>No transaction envelopes recorded in persistent storage yet.</span>
                        <span className="text-[10px] mt-0.5 text-center">Choose parameters and admit a signal above to witness live cloud auditing.</span>
                      </div>
                    ) : (
                      <div className="overflow-x-auto border border-[#1E2128]/80 rounded-lg">
                        <table className="w-full text-left border-collapse text-xs font-mono">
                          <thead>
                            <tr className="bg-[#171923] text-sleek-muted border-b border-[#232736] text-[10px]">
                              <th className="p-3 uppercase font-semibold">Logged Timestamp</th>
                              <th className="p-3 uppercase font-semibold">Ledger Block ID</th>
                              <th className="p-3 uppercase font-semibold">Authority</th>
                              <th className="p-3 uppercase font-semibold">Symbol</th>
                              <th className="p-3 uppercase font-semibold text-right">Verified Price</th>
                              <th className="p-3 uppercase font-semibold">Operator Arbiter</th>
                              <th className="p-3 uppercase font-semibold text-center">G-Signature Seal</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-[#1D202F]">
                            {firebaseAudits.map((item) => {
                              const amount = parseFloat(item.price.replace(/,/g, ''));
                              return (
                                <tr key={item.id} className="hover:bg-[#1A1D29]/40 transition-colors">
                                  <td className="p-3 text-[#A0AEC0] whitespace-nowrap">
                                    {new Date(item.createdAt).toLocaleString()}
                                  </td>
                                  <td className="p-3 text-white font-bold whitespace-nowrap">
                                    <span className="bg-[#2B2D42] text-[#A0AEC0] px-1.5 py-0.5 rounded text-[10px]">
                                      {item.id}
                                    </span>
                                  </td>
                                  <td className="p-3 text-[#64D2FF] font-semibold whitespace-nowrap">{item.authority}</td>
                                  <td className="p-3 text-white whitespace-nowrap">{item.asset}</td>
                                  <td className="p-3 text-[#4CD964] font-bold text-right whitespace-nowrap">
                                    ${isNaN(amount) ? item.price : amount.toLocaleString(undefined, {minimumFractionDigits: 2})}
                                  </td>
                                  <td className="p-3 text-[#A0AEC0] whitespace-nowrap inline-flex items-center space-x-1.5 pt-4">
                                    <span className="w-1.5 h-1.5 rounded-full bg-purple-400"></span>
                                    <span>{item.operatorEmail}</span>
                                  </td>
                                  <td className="p-3 text-center whitespace-nowrap">
                                    <span className="inline-flex items-center space-x-1 text-[#4CD964] bg-[#4CD964]/10 px-2 py-0.5 rounded-full border border-[#4CD964]/20 text-[10px] font-semibold">
                                      <ShieldCheck className="w-3.5 h-3.5" />
                                      <span>SECURED</span>
                                    </span>
                                  </td>
                                </tr>
                              );
                            })}
                          </tbody>
                        </table>
                      </div>
                    )}
                  </div>
                  </>
                )}
              </div>
            ) : (
              <LanguageContextStack />
            )}
          </motion.div>

          {/* Active Dual-Authority Telemetry Stream Panel */}
          <div className="bg-sleek-panel border border-sleek-border rounded-xl p-4 shrink-0 shadow-xl" id="hft-incoming-packets-stream">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center space-x-2">
                <Activity className="text-sleek-cyan w-4.5 h-4.5 animate-pulse" />
                <h4 className="text-xs font-bold font-mono tracking-wider text-sleek-text uppercase flex items-center gap-1.5">
                  ⚖️ REALITY OBSERVATION DECK: DUAL-AUTHORITY REAL-TIME ALIGNMENT STREAM
                </h4>
              </div>
              <div className="flex items-center space-x-2 text-[10px] font-mono">
                <span className="text-sleek-muted">Aperture Threshold:</span>
                <span className="text-[#30D5C8] font-bold">${divergenceThreshold.toFixed(2)}</span>
                <span className="w-1.5 h-1.5 rounded-full bg-sleek-green animate-pulse"></span>
                <span className="text-sleek-green uppercase font-bold tracking-wider text-[9px]">Live Link Active</span>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs font-mono">
                <thead>
                  <tr className="border-b border-sleek-border text-sleek-muted">
                    <th className="pb-2 font-mono uppercase text-[9px] tracking-wider">Telemetry ID</th>
                    <th className="pb-2 font-mono uppercase text-[9px] tracking-wider">Asset</th>
                    <th className="pb-2 font-mono uppercase text-[9px] tracking-wider">Authority A (TradingView)</th>
                    <th className="pb-2 font-mono uppercase text-[9px] tracking-wider">Authority B (CME Future)</th>
                    <th className="pb-2 font-mono uppercase text-[9px] tracking-wider">Price Delta</th>
                    <th className="pb-2 font-mono uppercase text-[9px] tracking-wider">Feed Latency</th>
                    <th className="pb-2 font-mono uppercase text-[9px] tracking-wider">Aperture Alignment Status</th>
                    <th className="pb-2 font-mono uppercase text-[9px] tracking-wider text-right">Witness Loop</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-sleek-border/40">
                  {packets.map((sig, idx) => {
                    const deltaVal = Math.abs(sig.price - sig.size);
                    const isAligned = deltaVal <= divergenceThreshold;
                    
                    return (
                      <tr key={idx} className="hover:bg-[#1E2128]/30 transition-colors">
                        <td className="py-2.5 text-sleek-text font-semibold">{sig.id}</td>
                        <td className="py-2.5">
                          <span className="bg-[#1A1D29] border border-[#2d3247] px-1.5 py-0.5 rounded text-[10px] text-white font-bold">
                            BTCUSD
                          </span>
                        </td>
                        <td className="py-2.5 text-[#E0AF68] font-bold">
                          ${sig.price.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                        </td>
                        <td className="py-2.5 text-sleek-cyan font-bold">
                          ${sig.size.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                        </td>
                        <td className="py-2.5">
                          <span className={`font-bold ${isAligned ? "text-sleek-green" : "text-sleek-red"}`}>
                            ${deltaVal.toFixed(2)}
                          </span>
                        </td>
                        <td className="py-2.5">
                          <span className="inline-block px-1.5 py-0.5 rounded bg-[#101217] border border-[#232736]/50 text-[#8F94A5] text-[10px] font-mono font-medium leading-none">
                            {sig.latencyNs}ns <span className="text-[8px] text-[#5A6070] font-normal font-sans">(jitter)</span>
                          </span>
                        </td>
                        <td className="py-2.5">
                          {isAligned ? (
                            <span className="text-sleek-green font-extrabold bg-sleek-green/10 border border-[#4CD964]/20 py-0.5 px-2 rounded text-[9px] uppercase tracking-wider">
                              ● ALIGNED
                            </span>
                          ) : (
                            <span className="text-sleek-red font-extrabold bg-sleek-red/10 border border-sleek-red/20 py-0.5 px-2 rounded text-[9px] uppercase tracking-wider animate-pulse">
                              ⚠️ DIVERGENT
                            </span>
                          )}
                        </td>
                        <td className="py-2.5 text-right">
                          <button
                            onClick={() => handleOrchestrate(sig)}
                            className="bg-sleek-cyan/15 hover:bg-sleek-cyan/25 text-sleek-cyan border border-sleek-cyan/30 px-2.2 py-1 rounded text-[9px] font-bold tracking-wider cursor-pointer font-sans transition-colors"
                          >
                            COMMIT SLICE
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            {activeOrchestratingPacket && (
              <div className="mt-5 pt-5 border-t border-sleek-border/70 animate-fade-in" id="orchestrator-loop-dashboard">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center space-x-2">
                    <Sparkles className="text-sleek-cyan w-4 h-4 animate-pulse" />
                    <span className="text-xs font-bold font-mono tracking-wide text-sleek-text uppercase">
                      ORCHESTRATOR TRACE CONSOLE: Orchestration Loop v0.1
                    </span>
                  </div>
                  <button
                    onClick={() => setActiveOrchestratingPacket(null)}
                    className="text-[10px] text-sleek-muted hover:text-sleek-text bg-[#1E2128] border border-[#2D3139] px-2 py-0.5 rounded font-mono transition-colors cursor-pointer"
                  >
                    CLOSE TRACE
                  </button>
                </div>

                {/* Vertical Stepper / Cascade diagram */}
                <div className="grid grid-cols-1 lg:grid-cols-6 gap-3 mb-4">
                  {/* Step 1: SIMON */}
                  <div className={`p-3 rounded-lg border transition-all ${
                    activeOrchestrationStep >= 1 ? "bg-[#0c141d]/80 border-sleek-cyan/40" : "bg-[#090a0d] border-sleek-border opacity-40"
                  }`}>
                    <div className="flex items-center justify-between mb-1.5">
                      <span className="text-[10px] font-bold font-mono text-sleek-cyan">STEP 1: SIMON</span>
                      <span className="text-[9px] bg-sleek-cyan/10 text-sleek-cyan px-1.5 py-0.2 rounded font-sans uppercase font-bold text-[8px]">Listens</span>
                    </div>
                    <p className="text-[11px] text-sleek-text leading-tight mb-2 font-mono">
                      {activeOrchestrationStep >= 1 ? `Heard signal ${activeOrchestratingPacket.id} Action: ${activeOrchestratingPacket.action}.` : "Waiting for sensory input loop..."}
                    </p>
                    <span className="text-[9px] font-mono text-sleek-muted block">witness: simon.rs</span>
                  </div>

                  {/* Step 2: HERMES */}
                  <div className={`p-3 rounded-lg border transition-all ${
                    activeOrchestrationStep >= 2 ? "bg-[#0c141d]/80 border-sleek-cyan/40" : "bg-[#090a0d] border-sleek-border opacity-40"
                  }`}>
                    <div className="flex items-center justify-between mb-1.5">
                      <span className="text-[10px] font-bold font-mono text-sleek-cyan">STEP 2: HERMES</span>
                      <span className="text-[9px] bg-blue-500/10 text-blue-400 px-1.5 py-0.2 rounded font-sans uppercase font-bold text-[8px]">Retrieves</span>
                    </div>
                    <p className="text-[11px] text-sleek-text leading-tight mb-2 font-mono">
                      {activeOrchestrationStep >= 2 ? `Verified boundary threshold limit rules for USD value.` : "Pending DB/memory read..."}
                    </p>
                    <span className="text-[9px] font-mono text-sleek-muted block">witness: hermes.rs</span>
                  </div>

                  {/* Step 3: ASTRA */}
                  <div className={`p-3 rounded-lg border transition-all ${
                    activeOrchestrationStep >= 3 ? "bg-[#0c141d]/80 border-sleek-cyan/40" : "bg-[#090a0d] border-sleek-border opacity-40"
                  }`}>
                    <div className="flex items-center justify-between mb-1.5">
                      <span className="text-[10px] font-bold font-mono text-sleek-cyan">STEP 3: ASTRA</span>
                      <span className="text-[9px] bg-amber-500/10 text-amber-400 px-1.5 py-0.2 rounded font-sans uppercase font-bold text-[8px]">Remembers</span>
                    </div>
                    <p className="text-[11px] text-sleek-text leading-tight mb-2 font-mono">
                      {activeOrchestrationStep >= 3 ? `Generated memory-commit trace: 0xC0FFEE.` : "Pending trace lock..."}
                    </p>
                    <span className="text-[9px] font-mono text-sleek-muted block">witness: astra.rs</span>
                  </div>

                  {/* Step 4: CHECKPOINT */}
                  <div className={`p-3 rounded-lg border transition-all ${
                    activeOrchestrationStep >= 4 ? "bg-[#0c2a20]/80 border-sleek-green/40" : "bg-[#090a0d] border-sleek-border opacity-40"
                  }`}>
                    <div className="flex items-center justify-between mb-1.5">
                      <span className="text-[10px] font-bold font-mono text-sleek-green">STEP 4: SEALS</span>
                      <span className="text-[9px] bg-sleek-green/10 text-sleek-green px-1.5 py-0.2 rounded font-sans uppercase font-bold text-[8px]">Checkpoint</span>
                    </div>
                    <p className="text-[11px] text-sleek-text leading-tight mb-2 font-mono">
                      {activeOrchestrationStep >= 4 ? `Sealed lineage checkpoint ID CHKP-${activeOrchestratingPacket.id.substring(4)}.` : "Awaiting checkpointing..."}
                    </p>
                    <span className="text-[9px] font-mono text-sleek-muted block">core: checkpoint.rs</span>
                  </div>

                  {/* Step 5: RUNTIME AUDIT */}
                  <div className={`p-3 rounded-lg border transition-all ${
                    activeOrchestrationStep >= 5 ? "bg-[#0c2a20]/80 border-sleek-green/40" : "bg-[#090a0d] border-sleek-border opacity-40"
                  }`}>
                    <div className="flex items-center justify-between mb-1.5">
                      <span className="text-[10px] font-bold font-mono text-sleek-green">STEP 5: TRACES</span>
                      <span className="text-[9px] bg-sleek-green/10 text-sleek-green px-1.5 py-0.2 rounded font-sans uppercase font-bold text-[8px]">Audit</span>
                    </div>
                    <p className="text-[11px] text-sleek-text leading-tight mb-2 font-mono">
                      {activeOrchestrationStep >= 5 ? `Sequential Audit trace locked. Decision flag remains clean.` : "Pending execution memory..."}
                    </p>
                    <span className="text-[9px] font-mono text-sleek-muted block">systems: runtime_audit.rs</span>
                  </div>

                  {/* Step 6: OPERATOR DECISION */}
                  <div className={`p-3 rounded-lg border transition-all ${
                    activeOrchestrationStep >= 6 ? "bg-[#18111a]/80 border-purple-500/40" : "bg-[#090a0d] border-sleek-border opacity-40"
                  }`}>
                    <div className="flex items-center justify-between mb-1.5">
                      <span className="text-[10px] font-bold font-mono text-purple-400">STEP 6: GATE</span>
                      <span className="text-[9px] bg-purple-500/10 text-purple-400 px-1.5 py-0.2 rounded font-sans uppercase font-bold text-[8px]">Operator</span>
                    </div>
                    <p className="text-[11px] text-sleek-text leading-tight mb-2 font-mono">
                      {activeOrchestrationStep >= 6 ? `Orchestrated. Awaiting Operator decision.` : "Awaiting witnesses..."}
                    </p>
                    <span className="text-[9px] font-mono text-sleek-muted block">decision: operator</span>
                  </div>
                </div>

                {/* Final Interactive Command Bar demonstrating rule: "Orchestrator coordinates, does not decide." */}
                {activeOrchestrationStep >= 6 && (
                  <div className="bg-[#101217] border border-sleek-border rounded-lg p-3.5 flex flex-col sm:flex-row items-center justify-between gap-3">
                    <div className="text-left font-mono text-xs">
                      <p className="text-[#E2E8F0] font-semibold">
                        Trace Complete for Telemetry Stream Slice <span className="text-sleek-cyan">{activeOrchestratingPacket.id}</span> (Aperture Delta: ${Math.abs(activeOrchestratingPacket.price - activeOrchestratingPacket.size).toFixed(2)})
                      </p>
                      <p className="text-[10px] text-sleek-muted mt-0.5">
                        Witnesses (SIMON, HERMES, ASTRA) have reported. Lineage checklist preserved. No automatic execution.
                      </p>
                      <span className="text-[10px] text-purple-400 font-bold tracking-wider mt-1 block uppercase">
                        ➔ LAW: ORCHESTRATOR COORDINATES. ORCHESTRATOR DOES NOT DECIDE.
                      </span>
                    </div>

                    <div className="flex space-x-2 shrink-0">
                      {operatorDecision === null ? (
                        <>
                          <button
                            onClick={() => setOperatorDecision("APPROVED")}
                            className="bg-sleek-green hover:bg-sleek-green/90 text-black font-bold px-4 py-1.5 rounded transition-all cursor-pointer text-xs uppercase font-sans shadow-lg tracking-wider"
                          >
                            ALLOW EXECUTION
                          </button>
                          <button
                            onClick={() => setOperatorDecision("BLOCKED")}
                            className="bg-sleek-red hover:bg-sleek-red/90 text-white font-bold px-4 py-1.5 rounded transition-all cursor-pointer text-xs uppercase font-sans shadow-lg tracking-wider"
                          >
                            BLOCK EXECUTION
                          </button>
                        </>
                      ) : (
                        <div className={`px-4 py-1.5 rounded border font-bold text-center flex items-center space-x-2 text-xs font-mono uppercase tracking-wider ${
                          operatorDecision === "APPROVED"
                            ? "bg-sleek-green/10 text-sleek-green border-sleek-green/30"
                            : "bg-sleek-red/10 text-sleek-red border-sleek-red/30"
                        }`}>
                          <span className="w-1.5 h-1.5 rounded-full animate-ping bg-current"></span>
                          <span>OPERATOR STATE: {operatorDecision}</span>
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </main>

      {/* Status Bar */}
      <footer className="bg-[#0A0B0E] border-t border-sleek-border px-6 py-3 text-[10px] text-sleek-muted font-mono flex flex-col md:flex-row md:items-center md:justify-between gap-2 shrink-0">
        <div>
          <span>CONNECTED PREVIEW CLIENT | TARGET: 0.0.0.0:3000 | LTO PIPELINES ACTIVE</span>
        </div>
        <div className="flex items-center space-x-4">
          <span>COMPILER MEMORY CHECK: PASS</span>
          <span>SYSTEM TEMPERATURE: 38.4°C</span>
        </div>
      </footer>
    </div>
  );
}
