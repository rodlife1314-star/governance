import { useState } from "react";
import {
  Wind,
  Compass,
  ArrowRight,
  TrendingUp,
  BrainCircuit,
  Radio,
  Clock,
  Gauge,
  Activity,
  ChevronRight,
  Sparkles,
  HelpCircle,
  Database,
  ArrowDownRight,
  ArrowUpRight,
  RefreshCw,
  Scale,
  Settings,
  Shield,
  Layers,
  Fingerprint
} from "lucide-react";
import {
  ResponsiveContainer,
  ComposedChart,
  Line,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend
} from "recharts";
import { CanonicalMarketPacket } from "../types";
import { getAbsoluteUrl } from "../utils";

// 9-Step Governance Hierarchy
const GOVERNANCE_STEPS = [
  { key: "reality", number: "01", name: "Reality", desc: "Infinite Raw Data Field" },
  { key: "slice", number: "02", name: "Slice", desc: "Select Boundary Coordinate" },
  { key: "feeler", number: "03", name: "Feelers", desc: "6-Dimensional Sensor Winds" },
  { key: "compression", number: "04", name: "Compression", desc: "Monday ➔ Friday Packets" },
  { key: "aperture", number: "05", name: "Aperture", desc: "Filter Out Background Noise" },
  { key: "validation", number: "06", name: "Validation", desc: "Pre-Flight Contract Verification" },
  { key: "opinion", number: "07", name: "Opinion", desc: "AI Coprocessor Pilot Telemetry" },
  { key: "operator", number: "08", name: "Operator", desc: "Manual Grounding & Auth" },
  { key: "memory", number: "09", name: "Memory", desc: "Persistent Ledger Broadcast" }
];

// Unified coordinate point inside any Slice (bounded section of reality)
interface SubdivisionPoint {
  label: string; // e.g. "Mon", "Hour 12:00", "Week 1", "Jan"
  date: string;  // e.g. "June 08", "12:00 PM", "May 01-05", "Jan 2026"
  spotPrice: number;
  futuresBasis: number; // premium/discount value
  volumeB: number; // Volume in Billions
  openInterestB: number; // Open interest in Billions
  dominancePercent: number;
  dxyIndex: number;
  vixValue: number;
  fundingRatePercent: number;
  windForce: string; // Primary force driving this point
  windIntensity: "Calm" | "Light" | "Moderate" | "Gale" | "Storm";
}

// Bounded Reality Slice (formerly WeeklyPacket but generalized for any scale)
interface SovereignSlicePacket {
  id: string;
  scale: "day" | "week" | "month" | "macro";
  scaleLabel: string;
  range: string;
  title: string;
  backgroundNoiseLevel: string;
  fieldStabilityScore: number;
  priceDomain: string; // The price space the slice operates within (e.g. HISTORICAL_108K_SIMULATED, LIVE_FEED_ALIGNED)
  feedTimestamp: string; // ISO or human indicator of when the slice's base parameters were established
  sourceMode: string; // Coordinate generation profile parameter
  startState: {
    spot: number;
    basis: number;
    oi: number;
    dominance: number;
  };
  endState: {
    spot: number;
    basis: number;
    oi: number;
    dominance: number;
  };
  primaryDrivers: string[];
  largestDriftEvent: string;
  largestConvergenceEvent: string;
  subdivisions: SubdivisionPoint[];
}

// Complete Multi-Scale Registry representing bounded pieces of reality
const SOVEREIGN_SLICES_REGISTRY: SovereignSlicePacket[] = [
  // ================= DAY SLICES =================
  {
    id: "SLICE-DAY-JUN-10",
    scale: "day",
    scaleLabel: "Day Slice (Hourly Delta)",
    range: "Wednesday, June 10, 2026 (00:00 - 24:00)",
    title: "Wednesday CME Rollover Windstorm (Micro-Temporal)",
    backgroundNoiseLevel: "Low-Medium (0.24%)",
    fieldStabilityScore: 92.1,
    priceDomain: "HISTORICAL_108K_SIMULATED",
    feedTimestamp: "2026-06-10T20:00:00Z",
    sourceMode: "CME_RO_WINDSTORM",
    startState: {
      spot: 107100,
      basis: 60,
      oi: 14.1,
      dominance: 58.7
    },
    endState: {
      spot: 108300,
      basis: 140,
      oi: 14.9,
      dominance: 59.2
    },
    primaryDrivers: [
      "Institutional contract rollovers forced immediate demand spikes on futures books.",
      "Arbitrage desks temporarily hit throughput bottlenecks, driving basis premium to $140 peak.",
      "VIX rose 1.4 points as spot volumes contracted during regional liquidity transition drafts."
    ],
    largestDriftEvent: "12:00-14:00: Immediate rollover surge where CME premium expanded by +$80 ahead of spot matching velocity.",
    largestConvergenceEvent: "20:00-24:00: Post-settlement calm, basis compressed back down as arbitrage bots locked risk-free spreads.",
    subdivisions: [
      {
        label: "00:00",
        date: "Start",
        spotPrice: 107100,
        futuresBasis: 60,
        volumeB: 3.5,
        openInterestB: 14.1,
        dominancePercent: 58.7,
        dxyIndex: 103.9,
        vixValue: 12.1,
        fundingRatePercent: 0.022,
        windForce: "Baseline Alignment",
        windIntensity: "Calm"
      },
      {
        label: "04:00",
        date: "Night",
        spotPrice: 107250,
        futuresBasis: 75,
        volumeB: 4.8,
        openInterestB: 14.2,
        dominancePercent: 58.8,
        dxyIndex: 103.8,
        vixValue: 12.2,
        fundingRatePercent: 0.024,
        windForce: "Tokyo Open Accumulation",
        windIntensity: "Light"
      },
      {
        label: "08:00",
        date: "London Buy",
        spotPrice: 107600,
        futuresBasis: 90,
        volumeB: 8.5,
        openInterestB: 14.5,
        dominancePercent: 59.0,
        dxyIndex: 103.6,
        vixValue: 12.5,
        fundingRatePercent: 0.028,
        windForce: "Europe Rollover Frontrun",
        windIntensity: "Moderate"
      },
      {
        label: "12:00",
        date: "CME Rollover",
        spotPrice: 108100,
        futuresBasis: 125,
        volumeB: 12.1,
        openInterestB: 14.8,
        dominancePercent: 59.1,
        dxyIndex: 103.5,
        vixValue: 13.0,
        fundingRatePercent: 0.032,
        windForce: "Structural Premium Divergence",
        windIntensity: "Gale"
      },
      {
        label: "16:00",
        date: "US Noon Peak",
        spotPrice: 108300,
        futuresBasis: 140,
        volumeB: 15.4,
        openInterestB: 14.9,
        dominancePercent: 59.2,
        dxyIndex: 103.5,
        vixValue: 13.5,
        fundingRatePercent: 0.035,
        windForce: "Peak Basis Rollover Disconnect",
        windIntensity: "Storm"
      },
      {
        label: "20:00",
        date: "US Close",
        spotPrice: 108250,
        futuresBasis: 85,
        volumeB: 10.2,
        openInterestB: 14.9,
        dominancePercent: 59.2,
        dxyIndex: 103.4,
        vixValue: 12.9,
        fundingRatePercent: 0.026,
        windForce: "Post-Settlement Liquidity Ease",
        windIntensity: "Moderate"
      },
      {
        label: "24:00",
        date: "End Pivot",
        spotPrice: 108120,
        futuresBasis: 65,
        volumeB: 6.1,
        openInterestB: 14.8,
        dominancePercent: 59.1,
        dxyIndex: 103.4,
        vixValue: 12.6,
        fundingRatePercent: 0.020,
        windForce: "Midnight Arbitrage Anchor",
        windIntensity: "Light"
      }
    ]
  },
  {
    id: "SLICE-DAY-JUN-08",
    scale: "day",
    scaleLabel: "Day Slice (Hourly Delta)",
    range: "Monday, June 08, 2026 (00:00 - 24:00)",
    title: "Monday Ground-State Alignment (Level Flight-path)",
    backgroundNoiseLevel: "Negligible (0.05%)",
    fieldStabilityScore: 99.4,
    priceDomain: "HISTORICAL_106K_SIMULATED",
    feedTimestamp: "2026-06-08T20:00:00Z",
    sourceMode: "MONDAY_GROUND_STATE",
    startState: {
      spot: 106100,
      basis: 15,
      oi: 13.5,
      dominance: 58.2
    },
    endState: {
      spot: 106420,
      basis: 35,
      oi: 13.8,
      dominance: 58.4
    },
    primaryDrivers: [
      "Smooth weekend reintegration with no outstanding geopolitical triggers.",
      "VIX steady below 13, creating low-pressure thermal grids for automated spot buying.",
      "DXY flatlining in a narrow horizontal coordinate range."
    ],
    largestDriftEvent: "16:00: Sudden $20 basis lift on minor CME options re-hedging.",
    largestConvergenceEvent: "22:00: Full recovery to horizontal base, futures spreads locked tight with spot.",
    subdivisions: [
      {
        label: "00:00",
        date: "Start",
        spotPrice: 106100,
        futuresBasis: 15,
        volumeB: 2.1,
        openInterestB: 13.5,
        dominancePercent: 58.2,
        dxyIndex: 104.2,
        vixValue: 12.8,
        fundingRatePercent: 0.010,
        windForce: "Quiet Reintegration",
        windIntensity: "Calm"
      },
      {
        label: "06:00",
        date: "Asia",
        spotPrice: 106200,
        futuresBasis: 18,
        volumeB: 3.2,
        openInterestB: 13.6,
        dominancePercent: 58.3,
        dxyIndex: 104.2,
        vixValue: 12.6,
        fundingRatePercent: 0.012,
        windForce: "Asia Flat Airway",
        windIntensity: "Calm"
      },
      {
        label: "12:00",
        date: "London",
        spotPrice: 106350,
        futuresBasis: 22,
        volumeB: 5.4,
        openInterestB: 13.7,
        dominancePercent: 58.4,
        dxyIndex: 104.1,
        vixValue: 12.5,
        fundingRatePercent: 0.014,
        windForce: "Slight European Premium",
        windIntensity: "Light"
      },
      {
        label: "18:00",
        date: "US Open",
        spotPrice: 106420,
        futuresBasis: 35,
        volumeB: 7.9,
        openInterestB: 13.8,
        dominancePercent: 58.4,
        dxyIndex: 104.2,
        vixValue: 12.4,
        fundingRatePercent: 0.015,
        windForce: "Moderate Premium Base",
        windIntensity: "Light"
      },
      {
        label: "24:00",
        date: "End Pivot",
        spotPrice: 106390,
        futuresBasis: 28,
        volumeB: 4.1,
        openInterestB: 13.8,
        dominancePercent: 58.4,
        dxyIndex: 104.1,
        vixValue: 12.3,
        fundingRatePercent: 0.013,
        windForce: "Calm Ground State",
        windIntensity: "Calm"
      }
    ]
  },

  // ================= WEEK SLICES =================
  {
    id: "SLICE-WEEK-26",
    scale: "week",
    scaleLabel: "Weekly Slice (Daily Compression)",
    range: "June 08 - June 12, 2026",
    title: "CME Contango Premium Breeze (Institutional Flight-path)",
    backgroundNoiseLevel: "Low (0.32%)",
    fieldStabilityScore: 96.5,
    priceDomain: "HISTORICAL_108K_SIMULATED",
    feedTimestamp: "2026-06-12T20:00:00Z",
    sourceMode: "WEEKLY_CONTANGO_WAVES",
    startState: {
      spot: 106420,
      basis: 35,
      oi: 13.8,
      dominance: 58.4
    },
    endState: {
      spot: 109250,
      basis: 25,
      oi: 15.2,
      dominance: 59.8
    },
    primaryDrivers: [
      "CME basis premium sustained in structural contango, driven by strong spot ETF inflows.",
      "DXY Index retreated from 104.2 to 102.8, easing global cash constraints and unlocking buy-side liquidity.",
      "Bitcoin dominance expanded dynamically to 59.8%, sucking capital velocity out of altcoin ecosystems."
    ],
    largestDriftEvent: "Wednesday derivative rollover caused a temporary disconnect where CME futures traded at an aggressive +$140 basis premium.",
    largestConvergenceEvent: "Friday afternoon spot buying absorbed the premium offset, squeezing the basis back down to a nominal, balanced $25 before close.",
    subdivisions: [
      {
        label: "Monday",
        date: "June 08",
        spotPrice: 106420,
        futuresBasis: 35,
        volumeB: 24.5,
        openInterestB: 13.8,
        dominancePercent: 58.4,
        dxyIndex: 104.2,
        vixValue: 12.4,
        fundingRatePercent: 0.015,
        windForce: "DXY Retrack & Base Inflow",
        windIntensity: "Moderate"
      },
      {
        label: "Tuesday",
        date: "June 09",
        spotPrice: 107100,
        futuresBasis: 60,
        volumeB: 28.2,
        openInterestB: 14.1,
        dominancePercent: 58.7,
        dxyIndex: 103.9,
        vixValue: 12.1,
        fundingRatePercent: 0.022,
        windForce: "Leverage Build & Basis Surge",
        windIntensity: "Gale"
      },
      {
        label: "Wednesday",
        date: "June 10",
        spotPrice: 108300,
        futuresBasis: 140,
        volumeB: 34.1,
        openInterestB: 14.9,
        dominancePercent: 59.2,
        dxyIndex: 103.5,
        vixValue: 13.5,
        fundingRatePercent: 0.035,
        windForce: "Rollover Contango Disconnect",
        windIntensity: "Storm"
      },
      {
        label: "Thursday",
        date: "June 11",
        spotPrice: 108750,
        futuresBasis: 80,
        volumeB: 27.8,
        openInterestB: 15.0,
        dominancePercent: 59.5,
        dxyIndex: 103.1,
        vixValue: 12.8,
        fundingRatePercent: 0.025,
        windForce: "Arbitrage Settlement",
        windIntensity: "Moderate"
      },
      {
        label: "Friday",
        date: "June 12",
        spotPrice: 109250,
        futuresBasis: 25,
        volumeB: 31.5,
        openInterestB: 15.2,
        dominancePercent: 59.8,
        dxyIndex: 102.8,
        vixValue: 11.9,
        fundingRatePercent: 0.012,
        windForce: "Spot Delta Equilibrium",
        windIntensity: "Light"
      }
    ]
  },
  {
    id: "SLICE-WEEK-25",
    scale: "week",
    scaleLabel: "Weekly Slice (Daily Compression)",
    range: "June 01 - June 05, 2026",
    title: "Macro-Turbulence Gale (US CPI Volatility Flight-path)",
    backgroundNoiseLevel: "Severe & High (2.85%)",
    fieldStabilityScore: 72.4,
    priceDomain: "HISTORICAL_112K_SIMULATED",
    feedTimestamp: "2026-06-05T20:00:00Z",
    sourceMode: "MACRO_TURBULENCE_GALE",
    startState: {
      spot: 112500,
      basis: 40,
      oi: 16.5,
      dominance: 57.2
    },
    endState: {
      spot: 105100,
      basis: -110,
      oi: 12.4,
      dominance: 56.4
    },
    primaryDrivers: [
      "CPI print sparked heavy fear, sending VIX climbing from 13.2 to 19.8 and crushing macro-liquidity.",
      "Extreme capital liquidations occurred on unregulated spot venues, while CME futures remained highly sticky.",
      "Funding rates flipped dark negative, signifying massive retail panic-scrambles and futures discounting."
    ],
    largestDriftEvent: "Tuesday US CPI release sparked a major spot slide; CME traders lagged, resulting in a divergent -$310 futures-under-spot discount.",
    largestConvergenceEvent: "Thursday afternoon CME options settlement forced delta hedgers to aggressively cover, converging the raw discount basis back to -$35.",
    subdivisions: [
      {
        label: "Monday",
        date: "June 01",
        spotPrice: 112500,
        futuresBasis: 40,
        volumeB: 21.0,
        openInterestB: 16.5,
        dominancePercent: 57.2,
        dxyIndex: 102.5,
        vixValue: 13.2,
        fundingRatePercent: 0.010,
        windForce: "Steady Pre-Event Calm",
        windIntensity: "Calm"
      },
      {
        label: "Tuesday",
        date: "June 02",
        spotPrice: 106400,
        futuresBasis: -310,
        volumeB: 48.9,
        openInterestB: 13.2,
        dominancePercent: 56.8,
        dxyIndex: 104.1,
        vixValue: 19.8,
        fundingRatePercent: -0.045,
        windForce: "CPI Macro Shock-Wave",
        windIntensity: "Storm"
      },
      {
        label: "Wednesday",
        date: "June 03",
        spotPrice: 104800,
        futuresBasis: -190,
        volumeB: 41.2,
        openInterestB: 12.1,
        dominancePercent: 56.5,
        dxyIndex: 104.5,
        vixValue: 18.5,
        fundingRatePercent: -0.060,
        windForce: "De-leveraging Crosswinds",
        windIntensity: "Gale"
      },
      {
        label: "Thursday",
        date: "June 04",
        spotPrice: 105300,
        futuresBasis: -35,
        volumeB: 29.5,
        openInterestB: 12.3,
        dominancePercent: 56.6,
        dxyIndex: 104.2,
        vixValue: 16.1,
        fundingRatePercent: -0.015,
        windForce: "Options Settlement Correction",
        windIntensity: "Moderate"
      },
      {
        label: "Friday",
        date: "June 05",
        spotPrice: 105100,
        futuresBasis: -110,
        volumeB: 33.4,
        openInterestB: 12.4,
        dominancePercent: 56.4,
        dxyIndex: 104.4,
        vixValue: 17.0,
        fundingRatePercent: -0.030,
        windForce: "Consolidation Drift",
        windIntensity: "Gale"
      }
    ]
  },

  // ================= MONTH SLICES =================
  {
    id: "SLICE-MONTH-JUN",
    scale: "month",
    scaleLabel: "Monthly Slice (Weekly Integration)",
    range: "June 01 - June 30, 2026",
    title: "June 2026 Integration (Dynamic Contango Waves)",
    backgroundNoiseLevel: "Moderate (1.15%)",
    fieldStabilityScore: 88.2,
    priceDomain: "HISTORICAL_112K_SIMULATED",
    feedTimestamp: "2026-06-30T20:00:00Z",
    sourceMode: "MONTHLY_CONTANGO_WAVES",
    startState: {
      spot: 112500,
      basis: 40,
      oi: 16.5,
      dominance: 57.2
    },
    endState: {
      spot: 114300,
      basis: 55,
      oi: 15.9,
      dominance: 60.1
    },
    primaryDrivers: [
      "A systematic spot price bottom crawled steadily upward after recovering from the Week 1 CPI storm.",
      "Extreme buy-side spot ETF accumulation through Weeks 2 & 3 restored deep capital reserves.",
      "CME basis premiums resolved from dark negative back into structural, healthy yield curves at close."
    ],
    largestDriftEvent: "Week 1 inflation prints triggered a major spot liquidation, forcing futures under spot by -$310 for 48 hours.",
    largestConvergenceEvent: "Week 4 structural arbitrage convergence, restoring the premium field balance back to a flat +$55 contango.",
    subdivisions: [
      {
        label: "Week 1",
        date: "Jun 01-05",
        spotPrice: 105100,
        futuresBasis: -110,
        volumeB: 174.5,
        openInterestB: 12.4,
        dominancePercent: 56.4,
        dxyIndex: 104.4,
        vixValue: 17.0,
        fundingRatePercent: -0.030,
        windForce: "CPI Sell-off Gale",
        windIntensity: "Storm"
      },
      {
        label: "Week 2",
        date: "Jun 08-12",
        spotPrice: 109250,
        futuresBasis: 25,
        volumeB: 144.8,
        openInterestB: 15.2,
        dominancePercent: 59.8,
        dxyIndex: 102.8,
        vixValue: 11.9,
        fundingRatePercent: 0.012,
        windForce: "ETF Capital Inflows",
        windIntensity: "Moderate"
      },
      {
        label: "Week 3",
        date: "Jun 15-19",
        spotPrice: 111100,
        futuresBasis: 45,
        volumeB: 132.4,
        openInterestB: 14.8,
        dominancePercent: 59.4,
        dxyIndex: 102.4,
        vixValue: 11.5,
        fundingRatePercent: 0.018,
        windForce: "Aesthetic Consolidation Grid",
        windIntensity: "Light"
      },
      {
        label: "Week 4",
        date: "Jun 22-26",
        spotPrice: 114300,
        futuresBasis: 55,
        volumeB: 168.1,
        openInterestB: 15.9,
        dominancePercent: 60.1,
        dxyIndex: 101.9,
        vixValue: 11.1,
        fundingRatePercent: 0.024,
        windForce: "Unified Squeeze Momentum",
        windIntensity: "Gale"
      }
    ]
  },

  // ================= MACRO CYCLES =================
  {
    id: "SLICE-CYCLE-H1",
    scale: "macro",
    scaleLabel: "Macro Cycle (Epoch Delta)",
    range: "January 01 - June 30, 2026",
    title: "H1 2026 Institutional Lift-off Cycle",
    backgroundNoiseLevel: "High Vol (3.42%)",
    fieldStabilityScore: 81.4,
    priceDomain: "HISTORICAL_88K_SIMULATED",
    feedTimestamp: "2026-06-30T20:00:00Z",
    sourceMode: "H1_INSTITUTIONAL_EPOCH",
    startState: {
      spot: 88500,
      basis: 15,
      oi: 8.4,
      dominance: 52.1
    },
    endState: {
      spot: 114300,
      basis: 55,
      oi: 15.9,
      dominance: 60.1
    },
    primaryDrivers: [
      "Secular upward trajectory driven by corporate treasury inclusion, sovereign reserves, and options listing expansion.",
      "DXY macro index locked in a long-term downtrend from 105.8 to 101.9, easing worldwide liquidity pressure.",
      "Bitcoin dominance systematically climbed from 52.1% to over 60%, consolidating altcoin capital velocity."
    ],
    largestDriftEvent: "April Halving volatility created severe block reward adjustments, driving temporary backwardation on CME contracts.",
    largestConvergenceEvent: "June Spot ETF expansion triggered unified global clearinghouse consensus, settling localized derivative premiums.",
    subdivisions: [
      {
        label: "Jan",
        date: "Jan 2026",
        spotPrice: 91200,
        futuresBasis: 20,
        volumeB: 480.0,
        openInterestB: 9.1,
        dominancePercent: 52.8,
        dxyIndex: 105.8,
        vixValue: 14.2,
        fundingRatePercent: 0.010,
        windForce: "New Year Portfolio Re-weights",
        windIntensity: "Moderate"
      },
      {
        label: "Feb",
        date: "Feb 2026",
        spotPrice: 95400,
        futuresBasis: 35,
        volumeB: 512.5,
        openInterestB: 10.4,
        dominancePercent: 53.9,
        dxyIndex: 104.9,
        vixValue: 13.5,
        fundingRatePercent: 0.015,
        windForce: "Corporate Accumulation Trade",
        windIntensity: "Moderate"
      },
      {
        label: "Mar",
        date: "Mar 2026",
        spotPrice: 101200,
        futuresBasis: 60,
        volumeB: 680.2,
        openInterestB: 11.8,
        dominancePercent: 55.4,
        dxyIndex: 103.8,
        vixValue: 12.8,
        fundingRatePercent: 0.022,
        windForce: "Options Regulatory Clearance",
        windIntensity: "Gale"
      },
      {
        label: "Apr",
        date: "Apr 2026",
        spotPrice: 98900,
        futuresBasis: -45,
        volumeB: 720.5,
        openInterestB: 10.1,
        dominancePercent: 55.1,
        dxyIndex: 104.5,
        vixValue: 16.5,
        fundingRatePercent: -0.005,
        windForce: "Halving Block Consolidation",
        windIntensity: "Gale"
      },
      {
        label: "May",
        date: "May 2026",
        spotPrice: 104350,
        futuresBasis: 5,
        volumeB: 450.9,
        openInterestB: 11.4,
        dominancePercent: 57.1,
        dxyIndex: 101.9,
        vixValue: 10.9,
        fundingRatePercent: 0.004,
        windForce: "Perfect Core Grounding",
        windIntensity: "Calm"
      },
      {
        label: "Jun",
        date: "Jun 2026",
        spotPrice: 114300,
        futuresBasis: 55,
        volumeB: 619.8,
        openInterestB: 15.9,
        dominancePercent: 60.1,
        dxyIndex: 101.9,
        vixValue: 11.1,
        fundingRatePercent: 0.024,
        windForce: "Macro Squeeze Re-acceleration",
        windIntensity: "Storm"
      }
    ]
  }
];

interface WeeklyTerrainMapProps {
  livePrice?: number;
  liveIndicator?: { spot: string; future: string; ping: number; source: string } | null;
  canonicalPacket?: CanonicalMarketPacket;
}

export default function WeeklyTerrainMap({ livePrice, liveIndicator, canonicalPacket }: WeeklyTerrainMapProps = {}) {
  const [activeScale, setActiveScale] = useState<"day" | "week" | "month" | "macro">("week");
  const [activePacketIndex, setActivePacketIndex] = useState(0); // index inside the filtered scale packets
  const [selectedSubIndex, setSelectedSubIndex] = useState(4); // index inside subdivs
  const [aiAnalysis, setAiAnalysis] = useState<string>("");
  const [aiEvidenceChain, setAiEvidenceChain] = useState<any[]>([]);
  const [isAiLoading, setIsAiLoading] = useState(false);

  // Filter registry by elected Scale
  const filteredPackets = SOVEREIGN_SLICES_REGISTRY.filter(p => p.scale === activeScale);
  // Guard bounds
  const packetIndex = activePacketIndex >= filteredPackets.length ? 0 : activePacketIndex;
  const activePacket = filteredPackets[packetIndex] || SOVEREIGN_SLICES_REGISTRY[2]; // fallback to Week 26
  
  // Ensure we don't index empty subdivisions
  const selectedSubdivisionIndex = selectedSubIndex >= activePacket.subdivisions.length 
    ? activePacket.subdivisions.length - 1 
    : selectedSubIndex;
  const selectedSubdivision = activePacket.subdivisions[selectedSubdivisionIndex] || activePacket.subdivisions[0];

  // Price Domain / Feed drift detection gate (Allowed Drift: $15,000 to manage $108k vs $63.8k)
  const activeSpot = canonicalPacket ? canonicalPacket.liveSpot : (livePrice || (liveIndicator ? parseFloat(liveIndicator.spot) : 0));
  const activeMode = canonicalPacket ? canonicalPacket.mode : "LIVE";

  const anchorPrice = selectedSubdivision ? selectedSubdivision.spotPrice : activePacket.startState.spot;
  const priceDifference = activeSpot > 0 ? Math.abs(anchorPrice - activeSpot) : 0;
  const allowedDrift = 15000;
  
  // Rule: Drift gate checks only apply if the active price regime is strictly in "LIVE" format.
  // Historical anchors shouldn't raise red-marks on historical/simulated inspections!
  const hasPriceDomainMismatch = activeMode === "LIVE" && activeSpot > 0 && priceDifference > allowedDrift;

  const handleScaleToggle = (scale: "day" | "week" | "month" | "macro") => {
    setActiveScale(scale);
    setActivePacketIndex(0);
    // set focus default coordinate to the ending anchor
    const packet = SOVEREIGN_SLICES_REGISTRY.find(p => p.scale === scale) || SOVEREIGN_SLICES_REGISTRY[2];
    setSelectedSubIndex(packet.subdivisions.length - 1);
    setAiAnalysis("");
    setAiEvidenceChain([]);
  };

  const getWindIntensityBadgeClass = (intensity: string) => {
    switch (intensity) {
      case "Storm":
        return "bg-rose-500/10 text-rose-400 border border-rose-500/20";
      case "Gale":
        return "bg-amber-500/10 text-amber-400 border border-amber-500/20";
      case "Moderate":
        return "bg-sleek-cyan/10 text-sleek-cyan border border-sleek-cyan/20";
      case "Light":
        return "bg-emerald-500/10 text-[#4CD964] border border-emerald-500/25";
      default:
        return "bg-slate-500/10 text-slate-400 border border-slate-500/15";
    }
  };

  // Run server-side Multi-Scale Gemini narrative analysis
  const triggerAiForcesAnalysis = async () => {
    setIsAiLoading(true);
    setAiAnalysis("");
    setAiEvidenceChain([]);
    try {
      const response = await fetch(getAbsoluteUrl("/api/gemini/slice-scale-analysis"), {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          scale: activeScale,
          sliceId: activePacket.id,
          title: activePacket.title,
          range: activePacket.range,
          startState: activePacket.startState,
          endState: activePacket.endState,
          primaryDrivers: activePacket.primaryDrivers,
          selectedSubdivision: selectedSubdivision,
          priceDomain: activePacket.priceDomain,
          feedTimestamp: activePacket.feedTimestamp,
          sourceMode: activePacket.sourceMode
        })
      });

      const data = await response.json();
      if (data.success) {
        setAiAnalysis(data.analysis);
        setAiEvidenceChain(data.evidenceChain || []);
      } else if (data.isBlocked) {
        setAiAnalysis(data.analysis || "System Coprocessor Blocked due to dynamic drift gate validation failure.");
        setAiEvidenceChain(data.evidenceChain || []);
      } else {
        // Fallback trace representation
        setAiAnalysis(`### ⚠️ Coprocessor Connection Offline
Sovereign local fallback simulator triggered for scale [${activeScale.toUpperCase()}]:

* **Scale Selection**: A temporal resolution of **${activeScale}** is elected because it perfectly bounds the ${activePacket.title} field sequence.
* **Feelers**: Volume ($${selectedSubdivision.volumeB}B) and Open Interest ($${selectedSubdivision.openInterestB}B) confirm a high-velocity wind force of **"${selectedSubdivision.windForce}"**.
* **Aperture & Validation**: With background noise estimated at ${activePacket.backgroundNoiseLevel} and field stability score at ${activePacket.fieldStabilityScore}%, we identify active divergence convergence cycles driving the ${Math.abs(activePacket.endState.spot - activePacket.startState.spot).toLocaleString()} USD delta.
* **Consensus Opinion**: The drift is validated as an authentic structural integration, currently grounded by the Operator.`);
        
        setAiEvidenceChain([
          { metric: "Focus price anchor", value: `$${selectedSubdivision.spotPrice.toLocaleString()}`, referenceRange: "Live temporal locus", impact: "Anchors baseline pricing at this coordinate." },
          { metric: "Futures Basis Premium", value: `$${selectedSubdivision.futuresBasis}`, referenceRange: "+$20 to +$140 dynamic", impact: `Basis premium of $${selectedSubdivision.futuresBasis} reflects relative derivatives leverage demand.` },
          { metric: "Realized Volume", value: `$${selectedSubdivision.volumeB}B`, referenceRange: "Liquidity depth indicator", impact: `Strong trading activity at $${selectedSubdivision.volumeB}B validates pricing consolidation.` },
          { metric: "Open Interest", value: `$${selectedSubdivision.openInterestB}B`, referenceRange: "Leverage density metric", impact: `Open derivatives leverage at $${selectedSubdivision.openInterestB}B shapes liquidation volatility buffers.` },
          { metric: "Fiat Pressure (DXY)", value: `${selectedSubdivision.dxyIndex}`, referenceRange: "102 - 105 index level", impact: `US Dollar Index direction at ${selectedSubdivision.dxyIndex} influences systemic risk aversion.` },
          { metric: "Macro Volatility (VIX)", value: `${selectedSubdivision.vixValue}`, referenceRange: "12 - 18 risk gauge", impact: `Capital risk appetite at ${selectedSubdivision.vixValue} regulates global spot-buying flows.` }
        ]);
      }
    } catch {
      setAiAnalysis("Failed to compile sovereign AI Coprocessor opinion on the wind field.");
      setAiEvidenceChain([
        { metric: "Focus price anchor", value: `$${selectedSubdivision.spotPrice.toLocaleString()}`, referenceRange: "Live temporal locus", impact: "Anchors baseline pricing at this coordinate." },
        { metric: "Futures Basis Premium", value: `$${selectedSubdivision.futuresBasis}`, referenceRange: "+$20 to +$140 dynamic", impact: `Basis premium of $${selectedSubdivision.futuresBasis} reflects relative derivatives leverage demand.` },
        { metric: "Realized Volume", value: `$${selectedSubdivision.volumeB}B`, referenceRange: "Liquidity depth indicator", impact: `Strong trading activity at $${selectedSubdivision.volumeB}B validates pricing consolidation.` },
        { metric: "Open Interest", value: `$${selectedSubdivision.openInterestB}B`, referenceRange: "Leverage density metric", impact: `Open derivatives leverage at $${selectedSubdivision.openInterestB}B shapes liquidation volatility buffers.` },
        { metric: "Fiat Pressure (DXY)", value: `${selectedSubdivision.dxyIndex}`, referenceRange: "102 - 105 index level", impact: `US Currency strength index at ${selectedSubdivision.dxyIndex} pressures risk asset valuations.` },
        { metric: "Macro Volatility (VIX)", value: `${selectedSubdivision.vixValue}`, referenceRange: "12 - 18 risk gauge", impact: `General volatility risk levels at ${selectedSubdivision.vixValue} govern speculative momentum.` }
      ]);
    } finally {
      setIsAiLoading(false);
    }
  };

  return (
    <div className="bg-sleek-panel border border-sleek-border rounded-xl p-5 shadow-2xl space-y-6" id="weekly-terrain-container">
      
      {/* 9-Step Governance Lineage Monitor */}
      <div className="bg-[#090A0D] border border-white/5 rounded-xl px-4 py-3 text-left">
        <div className="flex items-center justify-between mb-2">
          <span className="text-[9px] font-mono font-bold tracking-widest text-slate-400 uppercase flex items-center space-x-1.5 animate-pulse">
            <Shield className="w-3.5 h-3.5 text-emerald-400" />
            <span>Active Sovereign Governance Lineage Flow Contract</span>
          </span>
          <span className="text-[8px] font-mono font-bold text-emerald-400 bg-emerald-500/10 px-1.5 py-0.5 rounded uppercase">
            Validated
          </span>
        </div>
        
        {/* Horizontal micro-pipeline */}
        <div className="grid grid-cols-3 md:grid-cols-9 gap-2">
          {GOVERNANCE_STEPS.map((step) => {
            // Determine active/highlight states
            let isActive = false;
            if (step.key === "reality") isActive = true;
            if (step.key === "slice") isActive = true;
            if (step.key === "feeler") isActive = true;
            if (activeScale && step.key === "compression") isActive = true;
            if (selectedSubdivision && step.key === "aperture") isActive = true;
            if (step.key === "validation") isActive = true;
            if (aiAnalysis && step.key === "opinion") isActive = true;

            return (
              <div 
                key={step.key} 
                className={`p-1.5 rounded-lg border font-mono transition-all text-left flex flex-col justify-between ${
                  isActive 
                    ? "bg-slate-900 border-sleek-cyan/40 shadow-sm" 
                    : "bg-[#0A0C10] border-transparent opacity-40 hover:opacity-75"
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className={`text-[8px] font-extrabold ${isActive ? "text-sleek-cyan" : "text-slate-500"}`}>
                    {step.number}
                  </span>
                  <Fingerprint className={`w-2.5 h-2.5 ${isActive ? "text-sleek-cyan/80" : "text-slate-600"}`} />
                </div>
                <div className="mt-1">
                  <span className="text-[10px] font-bold text-white block leading-none">{step.name}</span>
                  <span className="text-[7.5px] text-slate-400 block truncate mt-0.5" title={step.desc}>
                    {step.desc}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Header section with quote and metaphor */}
      <div className="flex flex-col xl:flex-row xl:items-center justify-between pb-4 border-b border-[#232736]/40 gap-4">
        <div className="space-y-1.5 text-left">
          <div className="flex items-center space-x-2">
            <Layers className="text-amber-500 w-5 h-5" />
            <h3 className="text-xs font-bold font-mono tracking-widest text-[#E0AF68] uppercase">
              SOVEREIGN TEMPORAL SLICE FIELD EXPLORER
            </h3>
          </div>
          <p className="text-[11px] text-sleek-muted leading-relaxed max-w-3xl">
            "A slice is not defined by external divisions. A slice <strong>is</strong> a bounded section of reality chosen for observation. Day, Week, Month, and Quarter are merely different scale focal lengths of the same continuous fields."
          </p>
        </div>
        
        {/* Scale select controller tabs */}
        <div className="bg-[#101217] p-1 rounded-lg border border-[#232736] flex items-center space-x-1">
          {(["day", "week", "month", "macro"] as const).map((s) => (
            <button
              key={s}
              onClick={() => handleScaleToggle(s)}
              className={`px-3 py-1.5 rounded-md text-[10px] font-mono font-bold uppercase cursor-pointer tracking-wider transition-all flex items-center space-x-1 ${
                activeScale === s
                  ? "bg-sleek-cyan text-black font-extrabold shadow"
                  : "text-sleek-muted hover:text-white"
              }`}
            >
              <Scale className="w-3 h-3" />
              <span>{s}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Individual package registry selector row */}
      <div className="flex flex-wrap items-center gap-2 bg-[#0A0C10]/60 p-2.5 border border-[#232736]/20 rounded-xl justify-start text-left">
        <span className="text-[9px] font-mono font-bold uppercase text-slate-400 mr-2 flex items-center space-x-1">
          <Settings className="w-3 h-3 text-sleek-cyan" />
          <span>Active Bounded Packets ({activeScale.toUpperCase()} scale):</span>
        </span>
        <div className="flex items-center gap-2 flex-wrap">
          {filteredPackets.map((p, idx) => (
            <button
              key={p.id}
              onClick={() => {
                setActivePacketIndex(idx);
                setSelectedSubIndex(p.subdivisions.length - 1);
                setAiAnalysis("");
              }}
              className={`px-2.5 py-1 rounded text-[10px] font-mono font-bold uppercase cursor-pointer tracking-wide transition-all ${
                packetIndex === idx
                  ? "bg-[#E0AF68] text-black font-extrabold border-transparent"
                  : "bg-[#101217]/80 text-sleek-muted hover:text-white border border-[#232736]/40"
              }`}
            >
              📂 {p.id}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Visual Flight-path Graph & Selected Coordinate Details (7 Span) */}
        <div className="lg:col-span-8 space-y-5">
          <div className="bg-[#090A0E]/60 border border-[#232736]/40 p-4 rounded-xl space-y-4">
            <div className="flex items-center justify-between text-left">
              <span className="text-[10px] font-mono font-bold text-slate-300 uppercase flex items-center space-x-1.5">
                <Wind className="w-3.5 h-3.5 text-sleek-cyan" />
                <span>1. Continuous Field Mapping ( {activePacket.scaleLabel} )</span>
              </span>
              <span className="text-[9px] font-mono text-sleek-muted">
                {activePacket.range}
              </span>
            </div>

            {/* Price & Basis Combined Recharts Visualization */}
            <div className="h-60" id="composed-slice-chart">
              <ResponsiveContainer width="100%" height="100%">
                <ComposedChart
                  data={activePacket.subdivisions}
                  margin={{ top: 15, right: 10, left: -25, bottom: 5 }}
                >
                  <CartesianGrid strokeDasharray="3 3" stroke="#1E2128" />
                  <XAxis 
                    dataKey="label" 
                    stroke="#8A92AC" 
                    fontSize={10} 
                    fontFamily="monospace"
                  />
                  <YAxis 
                    yAxisId="price"
                    stroke="#E0AF68" 
                    fontSize={10} 
                    fontFamily="monospace"
                    domain={["auto", "auto"]}
                    tickFormatter={(v) => `$${(v / 1000).toFixed(1)}k`}
                  />
                  <YAxis 
                    yAxisId="basis"
                    orientation="right"
                    stroke="#64D2FF" 
                    fontSize={10} 
                    fontFamily="monospace"
                    domain={["auto", "auto"]}
                    tickFormatter={(v) => `$${v}`}
                  />
                  <Tooltip
                    contentStyle={{ backgroundColor: "#0F1115", borderColor: "#232736", fontFamily: "monospace", fontSize: "11px" }}
                    labelClassName="text-[#E0AF68] font-bold"
                  />
                  
                  {/* Spot flight-path */}
                  <Line
                    yAxisId="price"
                    type="monotone"
                    dataKey="spotPrice"
                    stroke="#E0AF68"
                    strokeWidth={2.5}
                    dot={{ r: 4, stroke: "#E0AF68", strokeWidth: 1, fill: "#090A0E" }}
                    activeDot={{ r: 6 }}
                    name="Spot Price (Anchor)"
                  />
                  
                  {/* CME Basis divergence winds */}
                  <Bar
                    yAxisId="basis"
                    dataKey="futuresBasis"
                    fill="#1E4D6E"
                    stroke="#30A9FF"
                    strokeWidth={1}
                    maxBarSize={30}
                    name="Basis Offset Premium / Discount ($)"
                  />
                </ComposedChart>
              </ResponsiveContainer>
            </div>

            {/* Dynamic subdivision coordinate select buttons */}
            <div className="grid grid-cols-4 md:grid-cols-7 gap-2 pt-1 text-left">
              {activePacket.subdivisions.map((d, index) => (
                <button
                  key={d.label}
                  onClick={() => setSelectedSubIndex(index)}
                  className={`p-2 rounded-lg border font-mono transition-all text-left flex flex-col justify-between cursor-pointer ${
                    selectedSubdivisionIndex === index
                      ? "bg-sleek-cyan/15 border-sleek-cyan text-white shadow"
                      : "bg-[#101217] border-[#232736]/60 text-sleek-muted hover:border-[#3a3f52] hover:text-slate-200"
                  }`}
                >
                  <div>
                    <span className="text-[10px] font-bold block truncate leading-none">{d.label}</span>
                    <span className="text-[8px] text-[gray] block mt-1 leading-none">{d.date}</span>
                  </div>
                  <div className="mt-2 pt-1 border-t border-white/5 flex items-baseline justify-between select-none">
                    <span className="text-[9px] text-[#E0AF68] font-bold">
                      ${(d.spotPrice / 1000).toFixed(1)}k
                    </span>
                    <span className={`text-[8.5px] font-bold ${d.futuresBasis >= 0 ? "text-sleek-cyan" : "text-rose-400"}`}>
                      {d.futuresBasis >= 0 ? `+${d.futuresBasis}` : d.futuresBasis}
                    </span>
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Coordinate Detail Vector Table (The Winds at Selected Coordinate) */}
          <div className="bg-[#090A0E]/40 border border-[#232736]/30 rounded-xl p-4 space-y-3">
            <div className="flex items-center justify-between border-b border-[#232736]/30 pb-2 text-left">
              <span className="text-[10px] font-mono font-bold text-white uppercase flex items-center space-x-1.5">
                <Gauge className="w-3.5 h-3.5 text-amber-400" />
                <span>2. Microstructural Wind Velocities inside Bounded Coordinates ({selectedSubdivision.label})</span>
              </span>
              <span className={`text-[9px] font-mono font-bold px-2 py-0.5 rounded uppercase font-sans ${getWindIntensityBadgeClass(selectedSubdivision.windIntensity)}`}>
                Wind: {selectedSubdivision.windForce}
              </span>
            </div>

            {/* 6-Dimensional Winds Grid */}
            <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-6 gap-3 text-left">
              <div className="bg-[#101217]/80 p-2.5 rounded-lg border border-[#232736]/40 text-left font-mono">
                <span className="text-[#8A95A5] uppercase text-[8px] tracking-wide block leading-none">Asset dominance</span>
                <span className="text-white font-bold text-xs mt-1 block">
                  {selectedSubdivision.dominancePercent.toFixed(2)}%
                </span>
                <span className="text-[7.5px] text-sleek-muted leading-none mt-0.5 block flex items-center gap-0.5">
                  <Activity className="w-2.5 h-2.5 text-sleek-muted" /> Market Share
                </span>
              </div>

              <div className="bg-[#101217]/80 p-2.5 rounded-lg border border-[#232736]/40 text-left font-mono">
                <span className="text-[#8A95A5] uppercase text-[8px] tracking-wide block leading-none">Realized Volume</span>
                <span className="text-white font-bold text-xs mt-1 block">
                  ${selectedSubdivision.volumeB.toFixed(1)}B
                </span>
                <span className="text-[7.5px] text-sleek-muted leading-none mt-0.5 block">
                  Liquidity depth
                </span>
              </div>

              <div className="bg-[#101217]/80 p-2.5 rounded-lg border border-[#232736]/40 text-left font-mono">
                <span className="text-[#8A95A5] uppercase text-[8px] tracking-wide block leading-none">Open Interest</span>
                <span className="text-pink-400 font-bold text-xs mt-1 block">
                  ${selectedSubdivision.openInterestB.toFixed(1)}B
                </span>
                <span className="text-[7.5px] text-pink-400/60 leading-none mt-0.5 block">
                  Leverage pool
                </span>
              </div>

              <div className="bg-[#101217]/80 p-2.5 rounded-lg border border-[#232736]/40 text-left font-mono">
                <span className="text-[#8A95A5] uppercase text-[8px] tracking-wide block leading-none">US Dollar dxy</span>
                <span className="text-amber-400 font-bold text-xs mt-1 block">
                  {selectedSubdivision.dxyIndex.toFixed(1)}
                </span>
                <span className="text-[7.5px] text-sleek-muted leading-none mt-0.5 block">
                  Fiat pressure
                </span>
              </div>

              <div className="bg-[#101217]/80 p-2.5 rounded-lg border border-[#232736]/40 text-left font-mono">
                <span className="text-[#8A95A5] uppercase text-[8px] tracking-wide block">Vix index</span>
                <span className="text-indigo-400 font-bold text-xs mt-1 block">
                  {selectedSubdivision.vixValue.toFixed(1)}
                </span>
                <span className="text-[7.5px] text-sleek-muted leading-none mt-0.5 block">
                  Macro risk gauge
                </span>
              </div>

              <div className="bg-[#101217]/80 p-2.5 rounded-lg border border-[#232736]/40 text-left font-mono">
                <span className="text-[#8A95A5] uppercase text-[8px] tracking-wide block">Funding rate</span>
                <span className={`font-bold text-xs mt-1 block ${selectedSubdivision.fundingRatePercent >= 0 ? "text-sleek-cyan" : "text-rose-400"}`}>
                  {selectedSubdivision.fundingRatePercent >= 0 ? `+${selectedSubdivision.fundingRatePercent}%` : `${selectedSubdivision.fundingRatePercent}%`}
                </span>
                <span className="text-[7.5px] text-sleek-muted leading-none mt-0.5 block">
                  Systemic fee
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: The Compression Packet & AI Coprocessor Opinion (5 Span) */}
        <div className="lg:col-span-4 flex flex-col justify-between space-y-4">
          
          {/* General Sovereign Compression Packet layout */}
          <div className="bg-[#0D1017] border border-[#232736]/70 rounded-xl p-4 space-y-4 flex-1 text-left">
            <div className="flex items-center justify-between border-b border-[#232736]/40 pb-2">
              <span className="text-[10px] font-mono font-bold text-slate-300 uppercase flex items-center space-x-1.5">
                <Radio className="w-3.5 h-3.5 text-amber-400" />
                <span>3. struct: SovereignCompressionPacket</span>
              </span>
              <span className="text-[8px] font-mono font-bold text-[#E0AF68] bg-[#E0AF68]/10 border border-[#E0AF68]/20 px-1 rounded uppercase">
                {activeScale} Bound
              </span>
            </div>

            <div className="space-y-3 font-mono text-[10px]">
              {/* Subject Title */}
              <div>
                <span className="text-[#8A95A5] uppercase text-[8px] tracking-widest font-bold">Packet Subject:</span>
                <p className="text-white font-bold leading-normal text-[11px] mt-0.5">{activePacket.title}</p>
              </div>

              {/* Endpoint metrics row */}
              <div className="grid grid-cols-2 gap-3 bg-[#08090C] p-2.5 border border-[#232736]/30 rounded-lg">
                <div className="space-y-1">
                  <span className="text-slate-400 text-[8px] font-bold block flex items-center gap-1">
                    <ArrowUpRight className="w-3 h-3 text-[#E0AF68]" /> ANCHOR START
                  </span>
                  <div className="text-xs font-bold text-white">${activePacket.startState.spot.toLocaleString()}</div>
                  <div className="text-[8.5px] text-sleek-muted">
                    Basis: <span className="text-sleek-cyan">${activePacket.startState.basis}</span> | OI: {activePacket.startState.oi}B
                  </div>
                </div>

                <div className="space-y-1 border-l border-[#232736]/40 pl-3">
                  <span className="text-slate-400 text-[8px] font-bold block flex items-center gap-1">
                    <ArrowDownRight className="w-3 h-3 text-sleek-cyan" /> ANCHOR END
                  </span>
                  <div className="text-xs font-bold text-white">${activePacket.endState.spot.toLocaleString()}</div>
                  <div className="text-[8.5px] text-sleek-muted">
                    Basis: <span className="text-sleek-cyan">${activePacket.endState.basis}</span> | OI: {activePacket.endState.oi}B
                  </div>
                </div>
              </div>

              {/* Primary Drivers List */}
              <div className="space-y-1">
                <span className="text-[#8A95A5] uppercase text-[8px] tracking-widest font-bold">Primary Winds (Drivers):</span>
                <div className="space-y-1.5 pt-1">
                  {activePacket.primaryDrivers.map((driver, index) => (
                    <div key={index} className="flex items-start space-x-1.5 leading-normal">
                      <ChevronRight className="w-3.5 h-3.5 text-[#E0AF68] shrink-0 mt-0.5" />
                      <span className="text-[#A9B1D6] text-[9.5px]">{driver}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Drift & Convergence logs */}
              <div className="space-y-2 pt-2 border-t border-[#232736]/30">
                <div className="bg-rose-500/5 border border-rose-500/10 rounded p-2 text-[9px] text-[#FF453A]">
                  <span className="font-bold uppercase tracking-wider block">Largest Drift Event:</span>
                  <p className="leading-snug text-slate-300 mt-1">{activePacket.largestDriftEvent}</p>
                </div>

                <div className="bg-[#4CD964]/5 border border-[#4CD964]/10 rounded p-2 text-[9px] text-[#4CD964]">
                  <span className="font-bold uppercase tracking-wider block">Largest Convergence Event:</span>
                  <p className="leading-snug text-slate-300 mt-1">{activePacket.largestConvergenceEvent}</p>
                </div>
              </div>

              {/* Metadatas */}
              <div className="grid grid-cols-2 gap-2 pt-1.5 text-[9px] border-t border-[#232736]/20">
                <div>
                  <span className="text-sleek-muted block text-[8px] uppercase">Background Noise:</span>
                  <span className="text-white font-bold">{activePacket.backgroundNoiseLevel}</span>
                </div>
                <div>
                  <span className="text-sleek-muted block text-[8px] uppercase">Field Stability Score:</span>
                  <span className="text-[#4CD964] font-bold">{activePacket.fieldStabilityScore}%</span>
                </div>
              </div>
            </div>
          </div>

          {/* AI Coprocessor Command Section */}
          <div className="bg-[#141824] border border-[#a855f7]/20 rounded-xl p-4 space-y-3 flex flex-col justify-between text-left">
            <div className="space-y-1.5">
              <div className="flex items-center space-x-2">
                <BrainCircuit className="text-purple-400 w-4 h-4 animate-pulse" />
                <span className="text-[10px] font-mono font-bold text-white uppercase tracking-wider">
                  Trace Coprocessor Opinion
                </span>
              </div>
              <p className="text-[9.5px] text-slate-300 font-mono leading-relaxed leading-normal">
                Command Gemini to evaluate target **{activeScale.toUpperCase()} Scale** metrics inside our isolated governance sandbox environment.
              </p>
            </div>

            {isAiLoading ? (
              <div className="py-4 flex flex-col items-center justify-center space-y-2 text-xs text-sleek-muted font-mono bg-[#0D1017] border border-white/5 rounded-lg h-32">
                <RefreshCw className="w-5 h-5 animate-spin text-purple-400" />
                <span>Decoding wind vector sequences...</span>
              </div>
            ) : aiAnalysis ? (
              <div className="space-y-3">
                <div className="bg-[#090A0E] border border-purple-500/10 p-3 rounded-lg h-32 overflow-y-auto select-all text-[10px] font-sans leading-normal text-slate-300 space-y-2">
                  <div className="text-[8px] font-mono text-purple-400 font-bold uppercase tracking-widest border-b border-white/5 pb-1 flex justify-between">
                    <span>Gemini Voice: Flight Leader</span>
                    <span>DEC-CO-001</span>
                  </div>
                  <p className="whitespace-pre-wrap leading-relaxed">{aiAnalysis}</p>
                </div>

                {aiEvidenceChain && aiEvidenceChain.length > 0 && (
                  <div className="bg-[#090A0E] border border-purple-500/10 p-3 rounded-lg space-y-2">
                    <div className="text-[8px] font-mono text-[#8A95A5] font-bold uppercase tracking-widest border-b border-white/5 pb-1 flex justify-between items-center">
                      <span>🔬 SYSTEM APERTURE EVIDENCE LEDGER</span>
                      <span className="text-[#a855f7] bg-[#a855f7]/10 px-1 rounded font-bold uppercase font-mono text-[7px]">Trace Link Active</span>
                    </div>
                    <div className="max-h-[180px] overflow-y-auto space-y-2 pr-0.5">
                      {aiEvidenceChain.map((item, index) => (
                        <div key={index} className="bg-[#141824]/60 p-2 rounded border border-white/5 text-[9.5px] space-y-1">
                          <div className="flex justify-between items-center font-mono">
                            <span className="text-white font-bold">{item.metric}</span>
                            <span className="text-sleek-cyan bg-sleek-cyan/10 px-1 rounded font-bold text-[9px]">{item.value}</span>
                          </div>
                          <div className="text-[9px] text-[#8692A6]">
                            Limit Interval: <span className="text-slate-300 italic">{item.referenceRange}</span>
                          </div>
                          <p className="text-slate-400 font-sans leading-relaxed text-[9px] pt-1 border-t border-white/5 mt-1">
                            {item.impact}
                          </p>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <div className="bg-[#0D1017] border border-dashed border-[#232736] p-4 rounded-lg h-32 flex items-center justify-center text-center text-sleek-muted text-[10px] font-mono">
                Awaiting Operator Command Trigger...
              </div>
            )}

            {hasPriceDomainMismatch && (
              <div className="bg-rose-500/10 border border-rose-500/25 p-3 rounded-lg space-y-2 text-rose-400">
                <div className="text-[9px] font-mono font-bold uppercase tracking-widest border-b border-rose-500/15 pb-1 flex justify-between items-center">
                  <span>🚨 PRICE_DOMAIN_MISMATCH BLOCK</span>
                  <span className="bg-rose-500/20 px-1 rounded text-[7px] font-bold">Friction Gate Active</span>
                </div>
                <p className="text-[9.5px] font-sans leading-normal">
                  The selected coordinate price universe (<strong className="text-white font-bold">${anchorPrice.toLocaleString()}</strong>) belongs to a different domain than the live feed price (<strong className="font-bold text-white">${activeSpot.toLocaleString()}</strong>).
                </p>
                <div className="text-[9px] font-mono bg-[#0D1017]/50 p-2 rounded space-y-1 border border-rose-500/10">
                  <div>Price Offset Delta: <span className="font-bold text-white">${priceDifference.toLocaleString()} USD</span></div>
                  <div>Maximum Allowed Drift: <span className="font-bold text-slate-300">${allowedDrift.toLocaleString()} USD</span></div>
                  <div className="text-[#8A95A5] pt-1 mt-1 border-t border-rose-500/10 leading-relaxed">
                    Source Mode: <span className="text-slate-200">{activePacket.sourceMode}</span> | Price Domain: <span className="text-slate-200">{activePacket.priceDomain}</span>
                  </div>
                </div>
              </div>
            )}

            <button
              onClick={triggerAiForcesAnalysis}
              disabled={isAiLoading || hasPriceDomainMismatch}
              className={`w-full font-mono text-xs font-bold py-2 rounded-lg flex items-center justify-center space-x-1.5 shadow-md border ${
                hasPriceDomainMismatch
                  ? "bg-slate-800/40 text-slate-500 border-slate-700/30 cursor-not-allowed"
                  : "bg-[#a855f7] hover:bg-[#b06cf8] text-white border-[#bf7ffc]/20 cursor-pointer transition-colors"
              }`}
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>{isAiLoading ? "EVALUATING WINDS..." : hasPriceDomainMismatch ? "COPROCESSOR ACCESS BLOCKED" : `GENERATE ${activeScale.toUpperCase()} SCALE DIAGNOSTIC`}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
