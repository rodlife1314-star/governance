export interface RustFile {
  path: string;
  name: string;
  layer: 'systems' | 'agents' | 'core' | 'doctrine' | 'build' | 'tests' | 'documentation';
  code: string;
  description: string;
  latencyImpact: string;
  sizeBytes: number;
}

export type CompilationState =
  | 'idle'
  | 'parsing'
  | 'codegen'
  | 'optimizing'
  | 'verification'
  | 'linking'
  | 'success'
  | 'failed_contract'
  | 'failed_cache_miss';

export interface CompilationReport {
  state: CompilationState;
  binaryName: string;
  instructionCount: number;
  sizeBytes: number;
  compileTimeMs: number;
  warnings: string[];
  logs: string[];
}

export interface SystemSignal {
  id: string;
  timestamp: string;
  action: 'BUY' | 'SELL' | 'HOLD' | 'REJECT';
  price: number;
  size: number;
  latencyNs: number;
  inspectDurationNs: number;
  allowedByGate: boolean;
  rejectReason?: string;
}

export interface TelecomTelemetry {
  timestamp: number;
  latencyNs: number;
  throughputKps: number;
  feedbackGain: number;
  cacheHitRef: number;
}

export interface SovereignAudit {
  id: string;
  authority: string;
  asset: string;
  price: string;
  packetId: string;
  operatorEmail: string;
  logs: string[];
  signature: string;
  createdAt: string;
  verified: boolean;
  operatorDecision?: string;
  divergenceDelta?: number;
}

export interface RealitySlice {
  spotPrice: number;
  futuresPrice: number;
  btcDominance: number;
  volume: number;
  spreadSpot: number;
  spreadFutures: number;
  depthBidsSpot: number;
  depthAsksSpot: number;
  depthBidsFutures: number;
  depthAsksFutures: number;
  openInterest: number;
  futuresBasis: number;
  timestampA: string;
  timestampB: string;
  latencyA_ms: number;
  latencyB_ms: number;
  source: string;
  pingMs: number;
}

export interface SliceIntent {
  slice_id: string;
  asset: string;
  field: string;
  reason_for_capture: string;
  expected_frequency: string;
  authorities_used: string;
  aperture_rule: string;
  validation_question: string;
  operator_mode: string;
}

export interface CanonicalMarketPacket {
  asset: "BTCUSD";
  mode: "LIVE" | "HISTORICAL" | "SIMULATED";
  sourceMode: "LIVE" | "HISTORICAL" | "SIMULATED";
  priceDomain: string;
  timestamp: string;
  liveSpot: number;
  liveFuture: number;
  midPrice: number;
  basisDelta: number;
  volume24h: number;
  openInterest: number;
  dominance: number;
  dxy: number;
  vix: number;
  fundingRate: number;

  // Alternate convention fields for absolute downstream-invariant 10D validation
  spotPrice: number;
  futuresPrice: number;
  priceDelta: number;
  basisPremium: number;
  authorityA: string;
  authorityB: string;
}



