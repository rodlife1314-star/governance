/**
 * Utility to convert relative API paths to absolute URLs.
 * This is crucial to prevent "SyntaxError: The string did not match the expected pattern"
 * in sandboxed iframes (especially in WebKit/Safari) where relative fetch paths fail.
 */
export function getAbsoluteUrl(relPath: string): string {
  try {
    const origin = window.location.origin;
    if (origin && origin !== "null") {
      const cleanOrigin = origin.endsWith("/") ? origin.slice(0, -1) : origin;
      const cleanPath = relPath.startsWith("/") ? relPath : "/" + relPath;
      return `${cleanOrigin}${cleanPath}`;
    }
    const protocol = window.location.protocol;
    const host = window.location.host;
    if (protocol && host) {
      const cleanPath = relPath.startsWith("/") ? relPath : "/" + relPath;
      return `${protocol}//${host}${cleanPath}`;
    }
  } catch (e) {
    // Fall back to relative path if window or location objects are restricted
  }
  return relPath;
}
